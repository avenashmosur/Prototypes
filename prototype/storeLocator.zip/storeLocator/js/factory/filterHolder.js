pharmacyLocatorFactory.service('pharmacyFilterHolder', function () {
    var obj = {};

    obj.filters = {};
    obj.getFilters = function () {
        return obj.filters;
    }
    obj.setFilters = function (val) {
        obj.filters = val;
    }

    return obj;
})