/**
 * Created by Katepally on 3/2/2015.
 */
'use strict';
pharmacyLocatorFactory.service('mapService', ['activeModel', function (activeModel) {

    this.loadMap = function () {
        var map = null;

        map = new Microsoft.Maps.Map(document.getElementById("map"), {
            credentials: "Ar42eevYl2S4wXRGoXZYp-pnv7vmWO6y2-bZwce9UV6df7M3qPMRZEzEg4lfdxSj",
            center: new Microsoft.Maps.Location(47.5, -122.3),
            zoom: 9
        });
        Microsoft.Maps.loadModule('Microsoft.Maps.Search', {
            callback: searchModuleLoaded
        });

        function searchModuleLoaded() {
            var searchManager = new Microsoft.Maps.Search.SearchManager(map);
            var geocodeRequest = {
                where: activeModel.pharmacySelectDefault.address,
                count: 10,
                callback: geocodeCallback,
                errorCallback: errCallback
            };
            searchManager.geocode(geocodeRequest);
        }

        function geocodeCallback() {
            var lati = activeModel.pharmacySelectDefault.latitude;
            var longi = activeModel.pharmacySelectDefault.longitude;
            //map.center = new Microsoft.Maps.Location(lati, longi);
            map.setView({
                center: new Microsoft.Maps.Location(lati, longi)
            });
            var pushpin = new Microsoft.Maps.Pushpin(map.getCenter());
            map.entities.push(pushpin);
            pushpin.setLocation(new Microsoft.Maps.Location(lati, longi));
        }

        function errCallback(geocodeRequest) {
            alert("An error occurred.");

        }
    }
}]);