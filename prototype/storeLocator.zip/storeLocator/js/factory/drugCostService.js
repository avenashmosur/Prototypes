'use strict'

//checkDrugCost Service Factory
pharmacyLocatorFactory.factory('drugCostService', ['$rootScope', '$resource', 'serviceFactory', 'activeModel', function ($rootScope, $resource, sf, activeModel) {

    function getUserAgent(userAgentPickedUp) {
        // Other
        var userAgent = 'DESKTOP';

        // ANDROID
        if (/Android/i.test(userAgentPickedUp)) {
            // ANDROID MOBILE
            if (/Mobile/i.test(userAgentPickedUp)) {
                userAgent = 'AND_MOBILE';

                // ANDROID GLASS
            } else if (/Glass/i.test(userAgentPickedUp)) {
                userAgent = 'AND_GLASS';

                // ANDROID TABLET
            } else {
                userAgent = 'AND_TABLET';
            }


            // iOS Mobile
        } else if (/iPhone|iPod/i.test(userAgentPickedUp)) {
            userAgent = 'IOS_MOBILE';


            // iOS Tablet
        } else if (/iPad/i.test(userAgentPickedUp)) {
            userAgent = 'IOS_TABLET';


            // Windows
        } else if (/IEMobile/i.test(userAgentPickedUp)) {
            userAgent = 'WIN_MOBILE';

            // Other identified vendor
        } else if (/webOS|BlackBerry|Opera Mini/i.test(userAgentPickedUp)) {
            userAgent = 'OTH_MOBILE';

        }
        return userAgent;
    }
    var userAgentFASTValue = getUserAgent(navigator.userAgent);



    return $resource('https://sitservices.caremark.com:444/' + ':folder' + '/' + ':id', {
            version: '1.0',
            appName: 'CMK_WEB',
            deviceID: 'device12345',
            deviceToken: 'device12345',
            lineOfBusiness: 'PBM',
            channelName: 'WEB',
            deviceType: userAgentFASTValue,
            apiKey: "1008347202313004A50F01F33D27EAB1",
            apiSecret: "E228F4CF4BE33EA5A20FE5FF9D5573F8"


        }, {
            pharmacyLocator: {
                //url: 'json/pharmacyLocator-mock.xml',
                method: 'POST',
                //method:'GET',
                headers: {
                    'Content-Type': 'text/plain'
                },
                params: {
                    folder: 'pharmacy',
                    id: 'pharmacyLocator',
                    serviceName: 'pharmacyLocator',
                    pharmacyResult: '400',
                    includeDirections: 'No',
                    serviceCORS: 'TRUE'

                },
                transformRequest: sf.requestTranform,
                transformResponse: sf.responseTransform
            },

            getZipFromCords: {
                url: 'http://maps.googleapis.com/maps/api/geocode/json',
                method: 'GET',
                headers: {
                    'Content-Type': 'text/plain'
                },
                params: {
                    sensor: 'false'
                }
            }
        }

    );
}]);