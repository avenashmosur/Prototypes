'use strict'

// making a central factory for errors, easier to handle error messages
pharmacyLocatorFactory.factory('errors', [function () {
    var errors = [
        {
            "errorCode": "0",
            "errorMessage": "Operation Timed Out, Please Try again Later"
      },
        {
            "errorCode": "500",
            "errorMessage": "We are sorry. We are unable to process your request."
      },
        {
            "errorCode": "401",
            "errorMessage": "Operation Not Allowed. Please Try Again Later."
      },
        {
            "errorCode": "001",
            "errorMessage": "Your member information is not authenticated"
      },
        {
            "errorCode": "002",
            "errorMessage": "Service Error"
      },
        {
            "errorCode": "003",
            "errorMessage": "Please select any drug and its strength"
      },
        {
            "errorCode": "004",
            "errorMessage": "Zip code or city and state is required"
      },
        {
            "errorCode": "005",
            "errorMessage": "Invalid Zip Code"
      },
        {
            "errorCode": "006",
            "errorMessage": "Distance is required"
      },
        {
            "errorCode": "007",
            "errorMessage": "Please select the drug dosage"
      },
        {
            "errorCode": "008",
            "errorMessage": "No drugs were found using the information that you provided. Please check the search criteria and try again"
      },
        {
            "errorCode": "009",
            "errorMessage": "We’re sorry. This service is unavailable right now. Please try again later."
      },
        {
            "errorCode": "010",
            "errorMessage": "We could not find a pharmacy that matched your search criteria. Please check your spelling and/or make sure the zip code is accurate, then try again."
      },
        {
            "errorCode": "011",
            "errorMessage": "This medication/supply is not covered under your Benefit Plan."
      },
        {
            "errorCode": "012",
            "errorMessage": "Member Not Found"
      },
        {
            "errorCode": "013",
            "errorMessage": "The dosage field requires a number greater than zero. Please make corrections and try again"
      },
        {
            "errorCode": "014",
            "errorMessage": "Please input the dosage amount that you take."
      },
        {
            "errorCode": "015",
            "errorMessage": "Remove any spaces and/or letters before or after the numeric entered. Please make corrections below."
      },
        {
            "errorCode": "016",
            "errorMessage": "The days field requires a number greater than zero. Please make corrections below"
      },
        {
            "errorCode": "017",
            "errorMessage": "Days supply cannot be more than 365. Please make corrections below"
      },
        {
            "errorCode": "018",
            "errorMessage": "You must enter a number for the days field. Please make corrections below."
      },
        {
            "errorCode": "019",
            "errorMessage": ""
      },
        {
            "errorCode": "020",
            "errorMessage": ""
      },
        {
            "errorCode": "021",
            "errorMessage": "Please log in to manage your prescriptions."
      },
        {
            "errorCode": "022",
            "errorMessage": "Pharmacy Not Found."
        },

        {
            "errorCode": "023",
            "errorMessage": "Unknown Error - Please contact the system administrator."
        }
    ];

    errors.getErrorMessage = function (errorNumber) {
        var message = "";
        angular.forEach(errors, function (value, key) {
            if (errorNumber == value.errorCode)
                message = value.errorMessage;
        });
        return message;
    }

    return errors;

}]);