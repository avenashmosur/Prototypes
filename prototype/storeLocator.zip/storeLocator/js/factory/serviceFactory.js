'use strict'

// Service Request Response Factory

/* This factory will handle Request Tranformation if required after the request has been initiated by User.
   Also this will handle the response before delivering to the user. If in case we get some error or non succesfull 
   response we will directly provide error info to error module 
*/

pharmacyLocatorFactory.factory('serviceFactory', [function () {
    return {
        // Request Tranformations
        requestTranform: function (data, headersGetter) {
            // console.log(data, headersGetter);
            try {
                native.showLoading();
            } catch (e) {}
        },
        //response Transformations
        responseTransform: function (data, headersGetter) {
            // console.log(data, headersGetter);
            try {
                native.hideLoading();
            } catch (e) {}

            var x2js = new X2JS();
            return x2js.xml_str2json(data);
            // return parser.xml2Json(data);
        }
    }
}]);