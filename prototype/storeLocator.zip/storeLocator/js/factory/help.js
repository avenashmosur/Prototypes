'use strict'

// This file has a function called matchRX to find an RX from within the service response and return it

pharmacyLocatorFactory.factory('help', ['activeModel', function (activeModel) {
    var help = {};

    help.matchRX = function (rx) {
        var refill = activeModel.refill;
        var drug;
        for (var i = 0; i < refill.length; i++) {
            if (rx == refill[i].rxNumber) {

                drug = {
                    name: refill[i].drug.drugName,
                    strength: refill[i].drug.drugStrength,
                    form: refill[i].drug.drugForm,
                    rxNumber: refill[i].rxNumber,
                    cost: refill[i].estimatedCost
                }
            }
        }

        return drug;
    }

    // Takes an OBJECT or STRING and wraps it in an array
    help.convertToArray = function (input) {
        var arr;

        if (Object.prototype.toString.call(input) === '[object Object]') {
            arr = [input];
        } else if (Object.prototype.toString.call(input) === '[object Array]') {
            arr = input
        } else if (Object.prototype.toString.call(input) === '[object String]') {
            arr = [input]
        }

        return arr;
    }

    help.returnUniqueArray = function (arrInput) {
        var arr = [];

        arrInput.forEach(function (element) {
            if (arr.indexOf(element) === -1) {
                arr.push(element);
            }
        });

        return arr;
    }

    help.removeAllDrugStrengths = function (drugInputArray) {
        var arr = [];

        drugInputArray.forEach(function (element, index) {
            // regex find all digits followed by 'mg' in the element
            var found = /\d+mg|\d+units|\d+%/.exec(element); // sample ["400mg", index: 7, input: "Avelox 400mg ABC Pack"]

            if (found) {
                element = element.slice(0, found.index - 1);
                // i.e. "Avelox 400mg ABC Pack" becomes "Avelox"
            }

            arr.push(element);

        });

        // after the trimming out of strnegth (i.e 400mg), uniquify the array
        arr = help.returnUniqueArray(arr);
        return arr;

    }

    return help;
}]);