/**
 * Created by Katepally on 3/9/2015.
 */

'use strict'

pharmacyLocatorFactory.factory('loginFactory', ['$resource', function ($resource) {

    function getUserAgent(userAgentPickedUp) {
        // Other
        var userAgent = 'DESKTOP';

        // ANDROID
        if (/Android/i.test(userAgentPickedUp)) {
            // ANDROID MOBILE
            if (/Mobile/i.test(userAgentPickedUp)) {
                userAgent = 'AND_MOBILE';

                // ANDROID GLASS
            } else if (/Glass/i.test(userAgentPickedUp)) {
                userAgent = 'AND_GLASS';

                // ANDROID TABLET
            } else {
                userAgent = 'AND_TABLET';
            }

            // iOS Mobile
        } else if (/iPhone|iPod/i.test(userAgentPickedUp)) {
            userAgent = 'IOS_MOBILE';

            // iOS Tablet
        } else if (/iPad/i.test(userAgentPickedUp)) {
            userAgent = 'IOS_TABLET';

            // Windows
        } else if (/IEMobile/i.test(userAgentPickedUp)) {
            userAgent = 'WIN_MOBILE';

            // Other identified vendor
        } else if (/webOS|BlackBerry|Opera Mini/i.test(userAgentPickedUp)) {
            userAgent = 'OTH_MOBILE';

        }
        return userAgent;
    }

    var userAgentFASTValue = getUserAgent(navigator.userAgent);
    return $resource("https://sitservices.caremark.com:444/login/:id", {
        version: '1.0',
        appName: 'CMK_APP',
        deviceID: 'device12345',
        lineOfBusiness: 'PBM',
        channelName: 'WEB',
        deviceType: 'AND_MOBILE',
        deviceToken: 'DEVICE12345',
        apiKey: '1008347202313004A50F01F33D27EAB1',
        apiSecret: 'E228F4CF4BE33EA5A20FE5FF9D5573F8',
        serviceCORS: 'TRUE'
    }, {
        //Service Methods
        authenticateMember: {
            method: 'POST',
            headers: {
                'Content-Type': 'text/plain'
            },
            params: {
                id: 'authenticateMember',
                serviceName: 'authenticateMember',
                encryptKey: '-6453546145590410580-682',
                username: 'carn@sit1.com',
                password: 'Common1'
            },
            transformRequest: function () {
                try {
                    native.showLoading();
                } catch (e) {}
            },
            transformResponse: function (data, headersGetter) {
                try {
                    native.hideLoading();
                } catch (e) {}

                var x2js = new X2JS();
                var response = x2js.xml_str2json(data);
                return response;
            }
        }
    });
    }]);