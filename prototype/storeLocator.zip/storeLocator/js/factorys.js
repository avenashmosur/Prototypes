'use strict';

/* Factory */

var pharmacyLocatorFactory = angular.module('pharmacyLocator.factorys', []);