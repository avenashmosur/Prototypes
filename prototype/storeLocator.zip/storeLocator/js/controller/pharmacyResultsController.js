'use strict'

pharmacyLocatorController.controller('pharmacyResultsController', ['$scope', '$rootScope','$location', '$modal', '$window', 'activeModel', 'drugCostService', 'help', 'errors', 'pharmacyFilterHolder', 'mapService', '$http', function ($scope, $rootScope,$location, $modal, $window, activeModel, drugCostService, help, errors, pharmacyFilterHolder, mapService, $http) {

    // INITIALIZATION
    $scope.pageClass = "pharmacyResultPage";
    $scope.submitted = false;
    $scope.drugItemSelect = activeModel.drugItemSelect;
    $scope.pharmacySearchList = [];
    $scope.defaultPharmacy = {};
    $scope.distanceUpdatePharmacyArray = [];
    $scope.distanceUpdatePharmacy = {};

    $scope.filters = pharmacyFilterHolder.getFilters();

    // Error Handling
    $scope.error = {};
    $scope.error.message = '';
    $scope.searchResults = 0;


    // PharmacyForm initial values
    $scope.filterPharmacy = {};
    $scope.filterPharmacy.zipCode = activeModel.filterPharmacy.zipCode;
    $scope.filterPharmacy.city = activeModel.filterPharmacy.city;
    $scope.filterPharmacy.state = activeModel.filterPharmacy.state;
    $scope.filterPharmacy.hourService = $scope.filters.hourService;
    $scope.filterPharmacy.driveThru = $scope.filters.driveThru;
    $scope.filterPharmacy.onsiteMedicalClinic = $scope.filters.onSitemedicalclinic;
    $scope.filterPharmacy.bestPharmaciesforSavings = $scope.filters.bestPharmaciesforSavings;
    $scope.filterPharmacy.bloodPressureScreening = $scope.filters.bloodPressureScreenings;
    $scope.filterPharmacy.compoundMedications = $scope.filters.compoundMedications;
    $scope.filterPharmacy.distanceInMiles = $scope.filters.distanceInMiles;
    $scope.filterPharmacy.driveThru = $scope.filters.driveThru;
    $scope.filterPharmacy.flushots = $scope.filters.flushots;
    $scope.filterPharmacy.languageSelected = $scope.filters.languageSelected;
    $scope.filterPharmacy.openSevendaysweek = $scope.filters.openSevendaysweek;
    $scope.filterPharmacy.prescriptiondelivery = $scope.filters.prescriptiondelivery;
    $scope.filterPharmacy.pharamcyName = activeModel.filterPharmacy.pharmacyName;

    $scope.$on('$viewContentLoaded', function () {
        callPharmacyLocator($scope.filterPharmacy);
        $scope.setDisplaySearch();
        try {
            activeModel.pharmacySelect = JSON.parse(native.getPreferredPharmacy());
        }
        catch(e){

        }
    })

    $scope.setDisplaySearch = function()
    {
        $scope.displayAdvanceSearch = '';
        if(activeModel.filterPharmacy) {
            var displayArray = [];
            (activeModel.filterPharmacy.hourService == '1') ? (displayArray.push('"24-hour services"')) : '';
            (activeModel.filterPharmacy.onSitemedicalclinic == '1') ? (displayArray.push('"On-site medical clinic"')) : '';
            (activeModel.filterPharmacy.bestPharmaciesforSavings == '1') ? (displayArray.push('"Best pharmacies for savings"')) : '';
            (activeModel.filterPharmacy.bloodPressureScreenings == '1') ? (displayArray.push('"Blood-pressure screenings"')) : '';
            (activeModel.filterPharmacy.compoundMedications == '1') ? (displayArray.push('"Compound medications"')) : '';
            (activeModel.filterPharmacy.driveThru == '1') ? (displayArray.push('"Drive-Thru Pharmacy"')) : '';
            (activeModel.filterPharmacy.flushots == '1') ? (displayArray.push('"Flu shots"')) : '';
            (activeModel.filterPharmacy.openSevendaysweek == '1') ? (displayArray.push('"Open 7 days a week"')) : '';
            (activeModel.filterPharmacy.prescriptiondelivery == '1') ? (displayArray.push('"Prescription delivery"')) : '';
        }

        if(displayArray.length>0)
        {
            var str1 = ' and ';
                for( var i = 0 ; i<displayArray.length ; i++)
                {
                    $scope.displayAdvanceSearch += str1.concat(displayArray[i]);
                }
        }
   }

    //activeModel.distance = $scope.filters.distanceInMiles;
    $rootScope.$watch(function () {return $location.path()}, function (newLocation, oldLocation) {
        if (newLocation == '/preferredPharmacyConfirmation' && oldLocation == '/pharmacyResults' && activeModel.preferredPharmacyConfiramtionVisited == true) {
            $scope.go("/pharmacy");
        }
        else if(newLocation == '/preferredPharmacyConfirmation' && oldLocation == '/pharmacy' && activeModel.preferredPharmacyConfiramtionVisited == false)

            try {
                native.showMenu();
            }
        catch(e){}

        })



        // Default values for Pharmacy Results
        $scope.currentPage = 0;
        $scope.pageSize = 10;
        $scope.inputPharmacy = (activeModel.searchPharmacy || activeModel.filterPharmacy.zipCode || activeModel.filterPharmacy.flushots);
        $scope.defaultPharmacy = activeModel.pharmacySelect;

        $scope.pharmacySelect = '';
        $scope.$watch('pharmacySelect', function () {
            $scope.submitted = false;
        });


        $scope.previousPage = function () { //pagination
            $scope.currentPage = $scope.currentPage - 1;
        };


        $scope.nextPage = function () { //pagination
            $scope.currentPage = $scope.currentPage + 1;
        };


        // Number of pages with the data
        $scope.numberOfPages = function () {
            return Math.ceil($scope.pharmacySearchList.length / $scope.pageSize);
        };


        // Function that sets pharmacy filters and calls pharmacyLocator Service
        function callPharmacyLocator(filters) {
            // Prepare pharmacyLocator service parameters
            var pharmacyLocatorParams = {};
            ($scope.filterPharmacy.zipCode) ? (pharmacyLocatorParams.zipCode = $scope.filterPharmacy.zipCode) : (delete pharmacyLocatorParams.zipCode);
            pharmacyLocatorParams.tokenID = activeModel.tokenID;
            pharmacyLocatorParams.city = $scope.filterPharmacy.city;
            pharmacyLocatorParams.state = $scope.filterPharmacy.state;
            pharmacyLocatorParams.open24HrsADay = filters.hourService;
            pharmacyLocatorParams.driveThru = filters.driveThru;
            pharmacyLocatorParams.distance = filters.distanceInMiles;
            pharmacyLocatorParams.pharmacyName = activeModel.filterPharmacy.pharmacyName;
            pharmacyLocatorParams.onsiteMedicalClinic = filters.onSitemedicalclinic;
            pharmacyLocatorParams.open7DaysAWeek = filters.openSevendaysweek;
            pharmacyLocatorParams.providesFluShots = filters.flushots;
            pharmacyLocatorParams.prescriptionDeliveryService = filters.prescriptiondelivery;
            pharmacyLocatorParams.bloodPressureScreening = filters.bloodPressureScreenings;
            pharmacyLocatorParams.preparesCompounds = filters.compoundMedications;
            pharmacyLocatorParams.bestPharmaciesforSavings = filters.bestPharmaciesforSavings;
            pharmacyLocatorParams.languageSelected = filters.languageSelected;

            // Call searchPharmacy Service
            drugCostService.pharmacyLocator(pharmacyLocatorParams, '', successPharmacySearch, errorPharmacySearch);

        }

        // Calling the function callPharmacyLocator()
        /*callPharmacyLocator({
         hourService: 'No',
         driveThru: 'No',
         distanceInMiles: 10,
         pharmacyName: '',
         onSitemedicalclinic: 'No',
         openSevendaysweek: 'No',
         flushots: 'No',
         prescriptiondelivery: 'No',
         bloodPressureScreenings: 'No',
         compoundMedications: 'No',
         bestPharmaciesforSavings: 'No',
         languageSelected: 'English'
         });
         */


        function successPharmacySearch(data) {


            if (data.response.header.statusCode === '1201' || data.response.header.statusCode === '1003' || data.response.header.statusCode === '3004') {
                activeModel.errorMessage = 'true';
                $scope.go("/pharmacy");

            }
            if (data.response.header.statusCode === '0000') {

                $scope.pharmacySearchList = help.convertToArray(data.response.details.pharmacyList.pharmacy).slice(0, 1000);
                $scope.distanceUpdatePharmacyArray = help.convertToArray(data.response.details.pharmacyList.pharmacy).slice(0, 1);
                $scope.distanceUpdatePharmacy = $scope.distanceUpdatePharmacyArray[0];
                if($scope.defaultPharmacy && !($scope.defaultPharmacy.pharmacyNumber == $scope.distanceUpdatePharmacy.pharmacyNumber) && !($scope.defaultPharmacy.zipCode == $scope.distanceUpdatePharmacy.zipCode)) {

                    getDistance(activeModel.pharmacySelect.latitude, activeModel.pharmacySelect.longitude, $scope.distanceUpdatePharmacy.latitude, $scope.distanceUpdatePharmacy.longitude);
                }
                $scope.searchResults = $scope.pharmacySearchList.length;
                activeModel.searchResult = $scope.searchResults;

                activeModel.pharmacySearchList = $scope.pharmacySearchList;
            } else {
                errorPharmacySearch(data);
            }
        }

    function getDistance(lat1, lon1, lat2, lon2) {

        var radlat1 = Math.PI * lat1/180;
        var radlat2 = Math.PI * lat2/180;
        var radlon1 = Math.PI * lon1/180;
        var radlon2 = Math.PI * lon2/180;
        var theta = lon1-lon2;
        var radtheta = Math.PI * theta/180;
        var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
        dist = Math.acos(dist);
        dist = dist * 180/Math.PI;
        dist = dist * 60 * 1.1515;
        $scope.defaultPharmacy.distance = dist;
    }

        function errorPharmacySearch(data) {

            if (data.response.header.statusCode == "1201") {
                updateErrorMessage(errors.getErrorMessage('022'));
            } else {
                updateErrorMessage(errors.getErrorMessage('009'));
            }
        }

        $scope.getPharmacySelect = function (pharmacy) {

            activeModel.pharmacySelectDefault = pharmacy;
            activeModel.preferredPharmacyConfiramtionVisited = false;
        }

        $scope.go = function (path) {
            $location.path(path);
        };

        $scope.callPharmacy = function (pharmacy) {

            native.showDialer(pharmacy.phoneNumber);

        }
        $scope.continueBtn = function (isValid, path) {
            $scope.submitted = true;

            if (isValid) {
                // Selecting pharmacy
                activeModel.pharmacySelect = $scope.pharmacySelect;
                $scope.go('/cost');
            }
        }

        $scope.ifPreferredPharmacy = function () {
            return activeModel.pharmacySelect.preferred;

        }

        $scope.loadCDCNative = function (pharmacy) {
            var uNetCdc = ("https://qa-caremark-angjs.udev1a.net/ws/site/v1/pharmacyLocator?search=" + pharmacy.zipCode);
            native.loadCDCComponent(uNetCdc, JSON.stringify(pharmacy));

        }



    function updateErrorMessage(errorMessage) {
            if (errorMessage) {
                $scope.error.message = errorMessage;
            } else {
                $scope.error.message = '';
            }
        }

}]);