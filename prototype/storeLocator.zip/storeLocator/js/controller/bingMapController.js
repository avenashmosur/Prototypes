/**
 * Created by Katepally on 3/9/2015.
 */
pharmacyLocatorController.controller('bingMapCtrl', ['$scope', 'pharmacyFilterHolder', 'activeModel', '$location', 'mapService', function ($scope, pharmacyFilterHolder, activeModel, $location, mapService) {

    $scope.$on('$viewContentLoaded', function () {
        mapService.loadMap();

    })

    $scope.go = function (path) {
        $location.path(path);
    };
}]);