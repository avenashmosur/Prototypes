pharmacyLocatorController.controller('preferredPharmacyConfirmationController', ['$scope', 'pharmacyFilterHolder', 'activeModel', '$location', function ($scope, pharmacyFilterHolder, activeModel, $location) {

    /*Default value of the pharmacy selected*/
    $scope.selectedPharmacy = {};
    $scope.selectedPharmacy.pharmacyName = activeModel.pharmacySelectDefault.pharmacyName;
    $scope.selectedPharmacy.distance = activeModel.pharmacySelectDefault.distance;
    $scope.selectedPharmacy.state = activeModel.pharmacySelectDefault.state;
    $scope.selectedPharmacy.zipCode = activeModel.pharmacySelectDefault.zipCode;
    $scope.selectedPharmacy.city = activeModel.pharmacySelectDefault.city;
    $scope.selectedPharmacy.phoneNumber = activeModel.pharmacySelectDefault.phoneNumber;
    $scope.selectedPharmacy = activeModel.pharmacySelectDefault;


    $scope.go = function (path) {
        $location.path(path);
    };

    $scope.setPreferredPharmacy = function () {
        activeModel.pharmacySelect.preferred = true;
        $scope.selectedPharmacy.preferred = true;
        activeModel.pharmacySelect = $scope.selectedPharmacy;
        activeModel.preferredPharmacyConfiramtionVisited = true;

    }
    $scope.cancelConfirmationClick = function(){

        if(activeModel.pharmacySelect.pharmacyNumber == activeModel.pharmacySelectDefault.pharmacyNumber) {
            activeModel.pharmacySelect.preferred = true;

   }
        activeModel.preferredPharmacyConfiramtionVisited = true;
        $scope.go('/pharmacyResults');
    }

    $scope.defaultPharmacy = function() {
        try {
            native.setPreferredPharmacy(JSON.stringify($scope.selectedPharmacy));
        }
        catch(e){

        }
    }
}]);