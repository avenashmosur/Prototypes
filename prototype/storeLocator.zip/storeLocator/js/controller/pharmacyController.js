'use strict'

pharmacyLocatorController.controller('pharmacyCtrl', ['$scope', 'pharmacyFilterHolder', 'activeModel', '$location', 'drugCostService', '$modal', function ($scope,pharmacyFilterHolder, activeModel, $location, drugCostService, $modal) {



    // Default filter dropdown values
    $scope.pharmacyFilters = {};
    $scope.pharmacyFilters.hourService = 'No';
    $scope.pharmacyFilters.driveThru = 'No';
    $scope.pharmacyFilters.distanceInMiles = 10;
    $scope.pharmacyFilters.pharmacyName = '';
    $scope.pharmacyFilters.onSitemedicalclinic = 'No';
    $scope.pharmacyFilters.openSevendaysweek = 'No';
    $scope.pharmacyFilters.flushots = 'No';
    $scope.pharmacyFilters.prescriptiondelivery = 'No';
    $scope.pharmacyFilters.bloodPressureScreenings = 'No';
    $scope.pharmacyFilters.compoundMedications = 'No';
    $scope.pharmacyFilters.bestPharmaciesforSavings = 'No';
    $scope.pharmacyFilters.languageSelected = "English";
    /*Added*/
    $scope.pageClass = "pharmacyPage";
    $scope.drugItemSelect = activeModel.drugItemSelect;
    $scope.preferredPharmacy = activeModel.preferredPharmacy;
    $scope.submitted = false;
    $scope.zipAddressError = false;
    $scope.showGeoLocation = false;
    $scope.geoDisabled = false;
    $scope.error = {};
    $scope.error.message = '';
    $scope.errorMessage = false;




    $scope.$on('$viewContentLoaded', function () {
        if(activeModel.count == 1) {
            $scope.retainCheckBoxValues();
        }
        $scope.noPharmacyFound();
        activeModel.preferredPharmacyConfiramtionVisited = false;
        try{
        activeModel.pharmacySelect = JSON.parse(native.getPreferredPharmacy());

    } catch (e){
    }})


    $scope.retainCheckBoxValues = function()
    {
        if(activeModel.filterPharmacy.zipCode){
        $scope.locationInput = activeModel.filterPharmacy.zipCode;}
        else {
            $scope.locationInput = (activeModel.filterPharmacy.city) + ',' + activeModel.filterPharmacy.state;
        }
        $scope.pharmacyFilters.hourService = activeModel.filterPharmacy.hourService;
        $scope.pharmacyFilters.driveThru = activeModel.filterPharmacy.driveThru;
        $scope.pharmacyFilters.distanceInMiles = activeModel.filterPharmacy.distanceInMiles;
        $scope.pharmacyFilters.pharmacyName = activeModel.filterPharmacy.pharmacyName;
        $scope.pharmacyFilters.onSitemedicalclinic = activeModel.filterPharmacy.onSitemedicalclinic;
        $scope.pharmacyFilters.openSevendaysweek = activeModel.filterPharmacy.openSevendaysweek;
        $scope.pharmacyFilters.flushots = activeModel.filterPharmacy.flushots;
        $scope.pharmacyFilters.prescriptiondelivery = activeModel.filterPharmacy.prescriptiondelivery;
        $scope.pharmacyFilters.bloodPressureScreenings = activeModel.filterPharmacy.bloodPressureScreenings;
        $scope.pharmacyFilters.compoundMedications = activeModel.filterPharmacy.compoundMedications;
        $scope.pharmacyFilters.bestPharmaciesforSavings = activeModel.filterPharmacy.bestPharmaciesforSavings;
        $scope.pharmacyFilters.languageSelected = activeModel.filterPharmacy.languageSelected;

    }


    $scope.noPharmacyFound = function()
    {
        $scope.errorMessage = activeModel.errorMessage;
    }
    $scope.goBack = function () {
        if (activeModel.drugCost) {
            $scope.go('/pharmacy');
        } else {
            $scope.go('/pharmacyResults');
        }
    };

    $scope.go = function (path) {

        $location.path(path);
    };

    $scope.setPharmacyTypeSelect = function (e) {
        $scope.pharmacyTypeSelect = 'geoLocation';
        $scope.searchZipOrCity();
    }

    $scope.$watch('pharmacyTypeSelect', function (value) {
        if (value == 'geoLocation') {
            getGeoLocation(function () {
                $scope.continueBtn(true)
            });
        }
    });


    // is the Geo Location Feature Available in Agent?
    function isGeoLocationAvailable() {
        var isGeo = false

        if (Modernizr.geolocation) {
            $scope.showGeoLocation = true;
            isGeo = true;
        } else {
            $scope.showGeoLocation = false;
        }

        return isGeo;
    }
    isGeoLocationAvailable();


    // Get Geo Location of user
    var geoReturnedZip = false;

    function getGeoLocation(cb) {
        navigator.geolocation.getCurrentPosition(function (pos) {
            postitionSuccess(pos, cb)
        }, positionError);

    }

    function postitionSuccess(position, cb) {

        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        activeModel.position.latitude = latitude;
        activeModel.position.longitude = longitude;
        // call getZipFromCords
        drugCostService.getZipFromCords({
            'latlng': (latitude + ',' + longitude)
        }, function (data) {
            successGetZipFromCords(data, cb);
        }, errorGetZipFromCords);
    }

    function positionError(err) {
        // TODO: Jquery error message showing, angular one has a display delay,
        $('.positionerror').html('User location could not be retrieved');
        // Angular one not working, it has a delay. removed the {{positionError}} from template for now.
        // $scope.positionError = 'User location could not be retrieved';
    }


    // Set Pharamcy Radio Selection
    function setPharmacyRadioSelect() {
        // If preferred pharmacy is there select it
        if (activeModel.preferredPharmacy) {
            $scope.pharmacyTypeSelect = 'defaultPharmacy';

            // // Else is Geo Location Feature Available
            // }else if(isGeoLocationAvailable()){
            //   $scope.pharmacyTypeSelect = 'geoLocation';
            //   getGeoLocation();

            // Else select ZipCode option
        } else {
            $scope.pharmacyTypeSelect = 'zipPharmacy';
        }
    }
    setPharmacyRadioSelect();



    function successGetZipFromCords(data, cb) {
        // returns array with an object of ZipCode value
        var zipElement = getDataWithZip(data.results);

        // putting the zipcode value in global variable
        geoReturnedZip = zipElement[0].address_components[0].short_name;
        if ($scope.validateUseMyCurrentLocationZip(geoReturnedZip)) {

            $scope.locationInput = geoReturnedZip;
            cb();
            $scope.continueBtn(true, '/pharmacyResults');
        }
    }

    function errorGetZipFromCords(data) {
        updateErrorMessage('Location ZipCode Could not be found');
    }


    function getDataWithZip(resultsInput) {
        var zipElement = [];

        zipElement = resultsInput.filter(function (element) {
            return element.types[0] == 'postal_code';
        });

        return zipElement;
    }

    $scope.checkLength =function(locationInput){
        if(locationInput.length == 0){
            return false;
        }

    }
    // Function for pharmacy address validation
    $scope.validateLocationInput = function (e) {
        $scope.zipAddressError = !(isValidAddress($scope.locationInput));
        $scope.geoLocate = false;
        if($scope.zipAddressError || activeModel.errorMessage) {
            $scope.errorMessage = true;
        }
    }

    $scope.validateUseMyCurrentLocationZip= function(geoReturnedZipValidation) {

        $scope.zipAddressError = !(isValidAddress(geoReturnedZipValidation));
        $scope.geoLocate = false;
        $scope.pharmacyTypeSelect = 'zipPharmacy';

        if ($scope.zipAddressError) {
            $scope.errorMessage = true;
            return false
        }
        return true;
    }



    // Pharmacy Address validation Zipcode or city, state validator
    function isValidAddress(address) {
        // postalCodeRegex = /^([0-9]{5})(?:[-\s]*([0-9]{4}))?$/;
        // Zip    or City State compenition (city,st  |  city, st  | city,st)
        var validateAddress = /(^\d{5}$)|(^[\w\s]+(,\s|,|\s)\w{2}$)/.test(address);
        return validateAddress;
    }


    // Returns address object with city state and zip
    function getCityStateZip(address) {
        var city = '',
            state = '',
            zip = '',
            addressLength = address.length;

        // If zipcode numbers are added
        if (!isNaN(address.substring(addressLength - 1))) {
            // contains a zipcode - just a sanity check
            // get last 10 characters for testing easily
            var lastTen = address.substring(addressLength - 10);
            if (lastTen.indexOf('-') > 0 && (lastTen.indexOf(' ') == -1)) {
                // found a hyphen and no space (matches our complex rule for zipcodes)
                zip = lastTen;
            } else {
                zip = address.substring(addressLength - 5); // assume a basic 5 zip code
            }

            return {
                'city': 'BLNK',
                'state': 'BLNK',
                'zip': zip
            };

            // if city and state are entered
        } else {
            var addressCityStateRemoveWhiteSpace = address.replace(/\s+/g, '');
            var addressCityStateSplit = addressCityStateRemoveWhiteSpace.split(/[,]/),
                city = addressCityStateSplit[0];
            state = addressCityStateSplit[1];

            // var lastComma = address.lastIndexOf(',');
            // city  = address.substring(0,lastComma).trim(); // skip the comma itself, yes?
            // state = address.substring(lastComma + 1).trim();

            return {
                'city': city,
                'state': state,
                'zip': ''
            };
        }
    }


    function updateErrorMessage(errorMessage) {
        if (errorMessage) {
            $scope.error.message = errorMessage;
        } else {
            $scope.error.message    }
    }


    /*endded*/
    $scope.savePharmacyFilter = function () {
        // pass these new values to the view that called this modal (In our case pharmacyResultsController)
        //$modalInstance.close(     $scope.pharmacyFilters);
        pharmacyFilterHolder.setFilters($scope.pharmacyFilters);

        $scope.filters = pharmacyFilterHolder.getFilters();

        activeModel.filterPharmacy = $scope.filters;
        activeModel.count = 1;

        // PharmacyForm initial values

        $scope.filterPharmacy = {};

        if ($scope.pharmacyTypeSelect == 'geoLocation') {
            if (geoReturnedZip) {
                var pharmacyAddress = getCityStateZip(geoReturnedZip);
                $scope.filterPharmacy.city = pharmacyAddress.city;
                $scope.filterPharmacy.state = pharmacyAddress.state;
                $scope.filterPharmacy.zipCode = pharmacyAddress.zip;
                $scope.searchPharmacy = $scope.locationInput;

                $scope.callPharmacyLocator($scope.filters)
            }
        }
        else if ($scope.pharmacyTypeSelect == 'zipPharmacy' && !$scope.zipAddressError) {
            var pharmacyAddress = getCityStateZip($scope.locationInput);

            $scope.filterPharmacy.city = pharmacyAddress.city;
            $scope.filterPharmacy.state = pharmacyAddress.state;
            $scope.filterPharmacy.zipCode = pharmacyAddress.zip;
            $scope.searchPharmacy = $scope.locationInput;

            /*$scope.filterPharmacy.zipCode = activeModel.filterPharmacy.zipCode;*/
            $scope.callPharmacyLocator($scope.filters);

        }

    }
       $scope.callPharmacyLocator =  function (filters) {
            // Prepare pharmacyLocator service parameters
           $scope.errorMessage = 'false';
            var pharmacyLocatorParams = {};
            ($scope.filterPharmacy.zipCode) ? (pharmacyLocatorParams.zipCode = $scope.filterPharmacy.zipCode) : (delete pharmacyLocatorParams.zipCode);
            pharmacyLocatorParams.tokenID = activeModel.tokenID;
            pharmacyLocatorParams.city = $scope.filterPharmacy.city;
            pharmacyLocatorParams.state = $scope.filterPharmacy.state;
            pharmacyLocatorParams.open24HrsADay = filters.hourService;
            pharmacyLocatorParams.driveThru = filters.driveThru;
            pharmacyLocatorParams.distance = filters.distanceInMiles;
            pharmacyLocatorParams.pharmacyName = filters.pharmacyName;
            pharmacyLocatorParams.onsiteMedicalClinic = filters.onSitemedicalclinic;
            pharmacyLocatorParams.open7DaysAWeek = filters.openSevendaysweek;
            pharmacyLocatorParams.providesFluShots = filters.flushots;
            pharmacyLocatorParams.prescriptionDeliveryService = filters.prescriptiondelivery;
            pharmacyLocatorParams.bloodPressureScreening = filters.bloodPressureScreenings;
            pharmacyLocatorParams.preparesCompounds = filters.compoundMedications;
            pharmacyLocatorParams.bestPharmaciesforSavings = filters.bestPharmaciesforSavings;
            pharmacyLocatorParams.languageSelected = filters.languageSelected;
            activeModel.filterPharmacy.pharmacyName = filters.pharmacyName;

            // Call searchPharmacy Service
            drugCostService.pharmacyLocator(pharmacyLocatorParams, '', successPharmacySearch );

        //$scope.applyPharmacyFilters();
        //$location.path('/pharmacyResults');

    };

    function successPharmacySearch(data) {


        if (data.response.header.statusCode === '1201' || data.response.header.statusCode === '1003' ||  data.response.header.statusCode === '2003' ||  data.response.header.statusCode === '9999') {
            $scope.errorMessage = 'true';
        }
        else
        {
            $scope.continueBtn(true, '/pharmacyResults');
        }
    }
    $scope.keyPressEnterZipSearch = function ($event, pharmacyFilters) {

        if ($event.charCode == 13) {
            $scope.validateLocationInput($scope.locationInput);
        }
        $scope.searchZipOrCity(pharmacyFilters);
        $scope.filters = pharmacyFilterHolder.getFilters();

        activeModel.filterPharmacy = $scope.filters;
        activeModel.count = 1;
        $scope.continueBtn(pharmacyForm.$valid, '/pharmacyResults')
    }
    $scope.searchZipOrCity = function () {
        pharmacyFilterHolder.setFilters($scope.pharmacyFilters);

    }

    $scope.continueBtn = function (isValid, path) {
        $scope.submitted = true;
        if (isValid) {

            // If preferred pharmacy was selected
            if ($scope.pharmacyTypeSelect == 'geoLocation') {
                if (geoReturnedZip) {
                    var pharmacyAddress = getCityStateZip(geoReturnedZip);
                    activeModel.filterPharmacy.city = pharmacyAddress.city;
                    activeModel.filterPharmacy.state = pharmacyAddress.state;
                    activeModel.filterPharmacy.zipCode = pharmacyAddress.zip;
                    activeModel.searchPharmacy = $scope.locationInput;
                    $scope.go(path);
                }

                // If pharmacy location input option was selected
            } else if ($scope.pharmacyTypeSelect == 'zipPharmacy' && !$scope.zipAddressError) {
                var pharmacyAddress = getCityStateZip($scope.locationInput);

                activeModel.filterPharmacy.city = pharmacyAddress.city;
                activeModel.filterPharmacy.state = pharmacyAddress.state;
                activeModel.filterPharmacy.zipCode = pharmacyAddress.zip;
                activeModel.searchPharmacy = $scope.locationInput;
                $scope.go(path);
            }
        }
    };

    var ModalInstanceCtrl = function ($scope, $modalInstance) {
        $scope.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    };

    $scope.openModal = function () {

        var modalInstance = $modal.open({
            templateUrl: 'myModalContent.html',
            controller: ModalInstanceCtrl
        });

        modalInstance.result.then(function () {

        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };
}]);