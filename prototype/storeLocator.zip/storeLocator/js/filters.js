'use strict';

/* Filters */

angular.module('pharmacyLocator.filters', []).
filter('interpolate', ['version', function (version) {
        return function (text) {
            return String(text).replace(/\%VERSION\%/mg, version);
        };
  }])
    .filter('cost', ['$filter', function ($filter) {
        return function (input) {
            var output = input;
            if (input) {
                input = input.toString();
                output = input.replace(/,/g, '');
            }

            if (output === '') {
                output = 'N/A';
            }
            var out = $filter('currency')(output);
            return out ? out : 'N/A';
        };
  }])
    .filter('pagination', function () //pharmacy list
        {
            return function (input, start) {
                var start = +start;
                return input.slice(start);
            }
        });