'use strict';

angular.module('pharmacyLocator', [
    'ngRoute',
    'ngAnimate',
    'ngResource',
    'ngSanitize',
    'pharmacyLocator.filters',
    'pharmacyLocator.factorys',
    'pharmacyLocator.directives',
    'pharmacyLocator.controllers',
    'ui.bootstrap',
    'ng.httpLoader'
]).
config(['$routeProvider', '$httpProvider', 'httpMethodInterceptorProvider', function ($routeProvider, $httpProvider, httpMethodInterceptorProvider) {
        $routeProvider.when('/pharmacy', {
            templateUrl: 'partials/pharmacy.html',
            controller: 'pharmacyCtrl'
        });
        $routeProvider.when('/pharmacyResults', {
            templateUrl: 'partials/pharmacyResults.html',
            controller: 'pharmacyResultsController'
        });
        $routeProvider.when('/preferredPharmacyConfirmation', {
            templateUrl: 'partials/preferredPharmacyConfirmation.html',
            controller: 'preferredPharmacyConfirmationController'
        });
        $routeProvider.when('/bingMap', {
            templateUrl: 'partials/bingMaps.html',
            controller: 'bingMapCtrl'
        });
        $routeProvider.otherwise({
            redirectTo: '/pharmacy'
        });

        //Enable cross domain calls
        $httpProvider.defaults.useXDomain = true;

        //Remove the header used to identify ajax call  that would prevent CORS from working
        delete $httpProvider.defaults.headers.common['X-Requested-With'];


        // http Loader
        httpMethodInterceptorProvider.whitelistDomain('caremark.com');
        httpMethodInterceptorProvider.whitelistDomain('http://127.0.0.1/');
        httpMethodInterceptorProvider.whitelistDomain('http://localhost');
}])
    .run(['$rootScope', '$location', 'activeModel', 'loginFactory', function ($rootScope, $location, activeModel, login) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {
            if (!activeModel.authenticated) {
                event.preventDefault();
                try {
                    activeModel.tokenID = native.getToken();
                    activeModel.authenticated = true;
                    $rootScope.actualLocation = $location.path();
                    $location.path("/pharmacy");
                } catch (e) {

                    login.authenticateMember('', '', function (data) {
                        if (data.response.header.statusCode == '0000') {
                            activeModel.tokenID = data.response.header.tokenID;
                            activeModel.authenticated = true;
                            $rootScope.actualLocation = $location.path();
                            $location.path("/pharmacy");
                        }
                    }, function (err) {});
                }
            }
        });
}]);