'use strict';

/* Controllers */

var pharmacyLocatorController = angular.module('pharmacyLocator.controllers', []);