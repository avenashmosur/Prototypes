'use strict';

var checkDrugCost = angular.module('checkDrugCost', [
    'ngRoute',
    'ngAnimate',
    'ngResource',
    'ngSanitize',
    'checkDrugCost.filters',
    'checkDrugCost.factorys',
    'checkDrugCost.directives',
    'checkDrugCost.controllers',
    'checkDrugCost.services',
    'pharmacyLocator',
    'ui.bootstrap',
    'ng.httpLoader'
]).
    config(['$routeProvider', '$httpProvider', 'httpMethodInterceptorProvider', '$sceProvider', '$provide',
        function ($routeProvider, $httpProvider, httpMethodInterceptorProvider, $sceProvider, $provide) {
            $provide.provider('portalJson', [function () {
                return {
                    $get: function () {
                        var portalJson = {};
                        if (window.parent[config.portalJSONVarName]) {
                            portalJson = window.parent[config.portalJSONVarName];
                        }
                        return portalJson;
                    }
                }
            }]);
            $routeProvider.otherwise({
                redirectTo: '/'
            });

            var routes = [];

            routes.push({
                name: '/',
                params: {
                    templateUrl: 'modules/drugsearch/views/drug-search.html'
                }
            });

            routes.push({
                name: '/result',
                params: {
                    templateUrl: 'modules/searchresult/views/search-results.html',
                    controller: 'drugSearchCostController'
                }
            });

            routes.push({
                name: '/pharmacy',
                params: {
                    templateUrl: 'bower_components/pharmacy/views/pharmacy-search.html',
                    controller: 'pharmacyCtrl'
                }
            });

            routes.push({
                name: '/pharmacyResults',
                params: {
                    templateUrl: 'bower_components/pharmacy/views/pharmacy-results.html',
                    controller: 'pharmacyResultsController'
                }
            });

            routes.push({
                name: '/bingMap',
                params: {
                    templateUrl: 'bower_components/pharmacy/views/bing-map.html',
                    controller: 'bingMapController'
                }
            });

            routes.forEach(function (route) {
                $routeProvider.when(route.name, route.params);
            });

            //Enable cross domain calls
            $httpProvider.defaults.useXDomain = true;
            $sceProvider.enabled(false);

            //Remove the header used to identify ajax call  that would prevent CORS from working
            delete $httpProvider.defaults.headers.common['X-Requested-With'];


            // http Loader
            httpMethodInterceptorProvider.whitelistDomain('caremark.com');
            httpMethodInterceptorProvider.whitelistDomain('http://127.0.0.1/');
            httpMethodInterceptorProvider.whitelistDomain('http://localhost');
        }])
    .run(['$rootScope', '$location', 'activeModel', 'webAnalytics', 'portalJson', 'userSessionData', 'help', 'cookieService',
        function ($rootScope, $location, activeModel, webAnalytics, portalJson, userSessionData, help, cookieService) {

            if (portalJson && portalJson.API_PARAM_DATA) {
                //webanalytics code - do not delete
                if(portalJson && portalJson.APP_PARAM_DATA && portalJson.APP_PARAM_DATA.CartUrl) {
                    activeModel.tealiumUrl = config.tealiumUrl[help.getEnvFromURL(portalJson.APP_PARAM_DATA.CartUrl)].url;
                    webAnalytics.loadScript(activeModel.tealiumUrl, function () {
                        $rootScope.$broadcast('tealiumLoaded');
                    });
                }else{
                    config.webAnalyticsFlag =false;
                }

                activeModel.portalJson = portalJson;
                if (activeModel.portalJson && activeModel.portalJson.API_PARAM_DATA && activeModel.portalJson.API_PARAM_DATA.tokenId) {
                    activeModel.tokenId = activeModel.portalJson.API_PARAM_DATA.tokenId;
                    activeModel.authenticated = true;
                }
            }
            else if($location.search()){
                var queryString = $location.search();
                activeModel.portalJson={
                    "API_PARAM_DATA":{
                        'tokenId': queryString['tokenID'],
                        'apiBaseUrl': (queryString['env'] && config[queryString['env']])?config[queryString['env']].baseUrl :''
                    }
                };
                if(queryString['tokenID']){
                    activeModel.tokenId = queryString['tokenID'];
                    activeModel.authenticated = true;
                }
            }
            if (help.getUserAgent() !== 'DESKTOP' && !activeModel.authenticated) {
                activeModel.tokenId = cookieService.readCookie("token_ID");
                activeModel.portalJson={
                    'API_PARAM_DATA':{
                        'tokenId':activeModel.tokenId
                    }
                }
                if (activeModel.tokenId) {
                    activeModel.authenticated = true;
                }
            }
activeModel.authenticated = true;
            $rootScope.$on('$routeChangeStart', function (event) {
                //if the user is not authenticated, redirect to default route
                if (!activeModel.authenticated) {
                    event.preventDefault();
                    $location.path("/");
                } else {
                    var sessionStoredData = help.getSessionStorage(activeModel.tokenId);
                    if (sessionStoredData) {
                        var currentSearch = sessionStoredData['currentSearch'];
                        if (currentSearch) {
                            userSessionData.setSelectedUserName(currentSearch.userName);
                            userSessionData.setSelectedPharmacy(currentSearch.pharmacy);
                            userSessionData.setSelectedDrugName(currentSearch.drugName);
                            userSessionData.setSelectedDrugDetails(currentSearch.drugDetails);
                            userSessionData.setSelectedDosage(currentSearch.drugDetails);
                            userSessionData.setAdditionalPharmacies(currentSearch.additionalPharmacies);
                            activeModel.memberList = sessionStoredData['memberList'];

                            if (sessionStoredData['loggedInUserInfo']) {
                                userSessionData.setLoggedInUserInfo(sessionStoredData['loggedInUserInfo']);
                            }
                            if (sessionStoredData['memberList']) {
                                activeModel.memberList = sessionStoredData['memberList'];
                            }
                            $location.path("/result");
                        }
                    }
                }
            });

            // Disclaimer Tray Logic
            $rootScope.disclaimerState;
            $rootScope.toggleDisclaimer = function (value) {
                $rootScope.disclaimerState = !$rootScope.disclaimerState;
                return $rootScope.disclaimerState;
            };

            $rootScope.$on('TealiumWebAnalytic', function (event, json) {
                webAnalytics.callHandler(event, json);
            });

        }]);
