'use strict';

checkDrugCostController.controller('drugSearchCostController', ['$scope', 'activeModel', 'userSessionData', '$q', 'drugCostHelper','CoreCommonsModal', '$rootScope',
    '$location', 'help','CommonDrugService','costResultDataService','costResultDataServices','pharmacyLocatorHelper','drugSearchHelper','personalization',
    function($scope, activeModel, userSessionData, $q, drugCostHelper, CoreCommonsModal, $rootScope,
             $location, help,CommonDrugService,costResultDataService,costResultDataServices,pharmacyLocatorHelper,drugSearchHelper,personalization) {
        /**
         * Showing Error message
         * @param header
         * @param message
         * @param showIcon
         */
        function showErrorMessage(header, message, showIcon,environment) {

            var error = {};
            error.Ind = true;
            error.errorHeader = header;
            error.errorMessage = message;
            error.environment = environment;
            $scope.error = error;

        }
         $scope.$on('clickTad',function(event,args){

            $scope.firstClick=true;
        });
        /**
         * Hiding the error message
         */
        function hideErrorMessage() {
            var error = {};
            error.Ind = false;
            error.errorHeader = "";
            error.errorMessage = "";
            error.environment = '';
            $scope.error = error;
        }

        var selectedState='current';
        $scope.$on('changeAdditonalPharmacy', function (event, args) {
            selectedState=args && args.message;
            hideErrorMessage();
            pharmacyLocatorHelper.openPharmacyLocator($scope.selectedPharmacy);

        });
        $scope.$on('viewCostDetailsPop', function (event, args) {

            $scope.viewCostDetails(args.message);

        });

        $scope.hideResultPage=true;
        $scope.showEdit=false;
        $scope.selectedIndex=0;
        $scope.isExpanded=false;

        $scope.printStateOn=help.printStateOn;

        $scope.myValue=true;
        $scope.mobileData={};
        var platform = help.getUserAgent(navigator.userAgent);
        if(platform =='IOS_MOBILE' || platform == 'AND_MOBILE'){
            $scope.myValue=false;
        }
        else
        {
            $scope.myValue=true;
        }

        $scope.FastContentService = help.readFASTContent();

        $scope.searchDrugDetailsArray = [];
        var currentDrugSearchInput = {};

        // Error Handling
        $scope.error = {};
        $scope.notify = {};
        $scope.error.message = '';
        $scope.currentDrugSearchInput = currentDrugSearchInput;
        $scope.costDetailsList;
        $scope.costDetailsBreakDown = {};
        $scope.costDetailsListArray = [];
        $scope.additionalPharmacyDetails = [];
        $scope.currentDrugDetails;
        $scope.selectAdditionalPharmacyMode = true;
        $scope.additonalCostResultDataModel = {};
        var isDuplicateDrug=true;
        $scope.pastSearchData = {
            generic: [],
            additionalPharmacy: [],
            TAD: []
        };
        var sessionStoredData = help.getSessionStorage(activeModel.tokenId);
        if (sessionStoredData) {
            var pastSearch = sessionStoredData['pastSearch'];
            if (pastSearch) {
                $scope.pastSearchData = pastSearch;
                angular.forEach($scope.pastSearchData.generic, function (eachResponseArray) {
                    eachResponseArray.expandedView = false;
                });
            }

            currentDrugSearchInput.tad= sessionStoredData['currentSearch']?sessionStoredData['currentSearch'].tad :undefined;
        }
        $scope.costResultDataModel = {};
        $scope.costResultDataModel.additionalPharmacies = [];

        $scope.pastCostResultDataModel = {};

        $scope.extranetUser = userSessionData.getLoggedInUserInfo().extranetUsr;

        /**
         * Modifying best value drug from searched/generic list of drugs
         * @param currentModel
         * @param resultToCompare
         */
        $scope.modifyBestValueIndicator = function(currentModel,resultToCompare) {
            if(currentModel) {
                var currentBestVal=userSessionData.getBestValue();
                //we cannot compare past drug cost old bestvalue since we maintain bestvalue object in session only for current state
                //param resultToCompare can be undefined for past searches.
                if(currentBestVal && currentBestVal.price!='' && resultToCompare && resultToCompare.costDetails.best.price!='' && currentModel.state=="current") {
                    if (currentBestVal.price > resultToCompare.costDetails.best.price) {
                        var currentBestValObj = resultToCompare.costDetails.best;
                        if(currentBestValObj&& currentBestValObj.ind){
                            var bestValueDrugDetails = {
                                "drugType": currentBestValObj.type === "brandMail" || currentBestValObj.type === "brandRetail" ? "for Brand Name" : "for Generic Equivalent",
                                "purchaseType": currentBestValObj.type === "brandMail" ? "(Mail service)" : "(Store pickup)"
                            };
                        }else{
                            var bestValueDrugDetails = {};
                        }
                        var bestValueDetails = angular.extend(bestValueDrugDetails, currentBestValObj);
                        userSessionData.setBestValue(bestValueDetails);

                        resetPreviousIndicator(currentModel);
                        resetAdditionalPharmaciesBestIndicator(currentModel);
                        if(resultToCompare.costDetails.best.ind) {
                            angular.forEach(resultToCompare.newCostDetails.Costs.additionalPharmacy.retail, function (eachArray, index) {

                                if (currentBestValObj.type === "brandRetail" && resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].drugType==="brand") {
                                    resultToCompare.newCostDetails.Costs.additionalPharmacy.retail[index].bestValueInd = true;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].bestValueInd = true;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].heading = $scope.FastContentService.searchResults.cost.label.brandHeader;
                                }
                                else if (currentBestValObj.type === "genericRetail" && resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].drugType==="generic Equivalent") {
                                    resultToCompare.newCostDetails.Costs.additionalPharmacy.retail[index].bestValueInd = true;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].bestValueInd = true;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].heading = $scope.FastContentService.searchResults.cost.label.genericHeader;
                                }

                            });
                        }

                    }
                    else{
                        if(currentBestVal.price == resultToCompare.costDetails.best.price){
                            resetPreviousIndicator(currentModel);
                            resetAdditionalPharmaciesBestIndicator(currentModel);
                        }
                        else if(resultToCompare.costDetails.best.ind) {
                            angular.forEach(resultToCompare.newCostDetails.Costs.additionalPharmacy.retail, function (eachArray, index) {
                                    resultToCompare.newCostDetails.Costs.additionalPharmacy.retail[index].bestValueInd = false;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].bestValueInd = false;
                                    resultToCompare.newCostDetails.drugNames.additionalPharmacy[index].heading = '';
                            });
                        }
                    }

                }
                else if(currentModel) {
                    var bestValueObj=currentModel.bestValue;
                    var bestValueHeadObj=null;
                    var bestValuePriceObj=null;
                    var duplicatePriceCount=0;

                    if(bestValueObj.ind){

                                angular.forEach(currentModel.Costs.generic.mail, function (eachArray, index) {

                                    if(parseFloat(bestValueObj.price)===parseFloat(eachArray.PricePerDay,10)){
                                        bestValueHeadObj=currentModel.drugNames.generic[index];
                                        bestValuePriceObj=currentModel.Costs.generic.mail[index];
                                        duplicatePriceCount++;
                                    }
                                });
                                angular.forEach(currentModel.Costs.generic.retail, function (eachArray, index) {

                                    if(parseFloat(bestValueObj.price)===parseFloat(eachArray.PricePerDay,10)){
                                        bestValueHeadObj=currentModel.drugNames.generic[index];
                                        bestValuePriceObj=currentModel.Costs.generic.retail[index];
                                        duplicatePriceCount++;
                                    }
                                });
                    }
                    angular.forEach(currentModel.additionalPharmacies, function(valueArray, newindex) {
                        angular.forEach(valueArray.newCostDetails.Costs.additionalPharmacy.retail, function (eachArray, index) {

                            if(parseFloat(bestValueObj.price)>parseFloat(eachArray.PricePerDay)){
                                bestValueObj=currentModel.additionalPharmacies[newindex].costDetails.best;
                                bestValueHeadObj=currentModel.additionalPharmacies[newindex].newCostDetails.drugNames.additionalPharmacy[index];
                                bestValuePriceObj=currentModel.additionalPharmacies[newindex].newCostDetails.Costs.additionalPharmacy.retail[index];
                                duplicatePriceCount=1;
                            }
                            else if(parseFloat(bestValueObj.price)==parseFloat(eachArray.PricePerDay)){
                                duplicatePriceCount++;
                            }
                        });
                    });

                    //need to save old best value only for current drug details
                    if(currentModel.state=="current") {
                        var bestValueDrugDetails = {
                            "drugType": bestValueObj.type == "brandMail" || bestValueObj.type == "brandRetail" ? "for Brand Name" : "for Generic Equivalent",
                            "purchaseType": bestValueObj.type == "brandMail" ? "(Mail service)" : "(Store pickup)"
                        };
                        var bestValueDetails = angular.extend(bestValueDrugDetails, bestValueObj);
                        userSessionData.setBestValue(bestValueDetails);
                    }

                    resetPreviousIndicator(currentModel);
                    resetAdditionalPharmaciesBestIndicator(currentModel);

                    if(bestValueObj.ind && duplicatePriceCount<=1) {
                    if(bestValuePriceObj && bestValueHeadObj) {
                        bestValuePriceObj.bestValueInd = true;
                        bestValueHeadObj.bestValueInd = true;
                        if (bestValueObj.type == "genericRetail") {
                            bestValueHeadObj.heading = $scope.FastContentService.searchResults.cost.label.genericHeader;
                        }
                        else {
                            bestValueHeadObj.heading = $scope.FastContentService.searchResults.cost.label.brandHeader;
                        }
                    }
                    }
                }
            }
        };

        /**
         * Reseting Previous Drug Indicator
         * @param previousBestValue
         * @param type
         */
        var resetPreviousIndicator = function(currentModel) {

           // if (previousBestValue.type.indexOf('mail') > -1) {
                angular.forEach(currentModel.Costs.generic.mail, function (eachArray, index) {
                    currentModel.Costs.generic.mail[index].bestValueInd = false;
                    currentModel.drugNames.generic[index].bestValueInd = false;
                    currentModel.drugNames.generic[index].heading = '';
                });
           // } else {
                angular.forEach(currentModel.Costs.generic.retail, function (eachArray, index) {
                    currentModel.Costs.generic.retail[index].bestValueInd = false;
                    currentModel.drugNames.generic[index].bestValueInd = false;
                    currentModel.drugNames.generic[index].heading = '';
                });
             //  };
        };
        /**
         * Reseting Additional Pharmacy Best Value Indicator
         */
        var resetAdditionalPharmaciesBestIndicator = function(currentModel) {

            angular.forEach(currentModel.additionalPharmacies, function(valueArray, newindex) {
                //console.log(valueArray);
                angular.forEach(valueArray.newCostDetails.Costs.additionalPharmacy.retail, function (value, index) {
                    currentModel.additionalPharmacies[newindex].newCostDetails.Costs.additionalPharmacy.retail[index].bestValueInd = false;
                    currentModel.additionalPharmacies[newindex].newCostDetails.drugNames.additionalPharmacy[index].bestValueInd = false;
                    currentModel.additionalPharmacies[newindex].newCostDetails.drugNames.additionalPharmacy[index].heading = '';
                });
            });
        };
        //Initialize values
        $scope.memberList = activeModel.memberList;
        $scope.memberSelect = activeModel.memberSelect;
        //$scope.memberSelect = $scope.memberList[0];

        //End Initializing values


        //  $scope.currentResultValue=currentResultValue;

        ///Display Employer Primary Plan Cost for ST-COB Member plans.
        // The ability to display the Employer Primary Plan Cost is a personalization////
        $scope.isStCobMember = true;

        /*
         * function used to take print from print popup
         */
        $scope.printPopup = function() {
            if(help.IEVersion() == 8) {
                $("#cdc_result_print_button").css('display', 'none');
            }
            var printcontent=document.getElementById("printer_data_1").innerHTML;
            var printdiv=document.createElement('div');
            $(printdiv).attr('id', 'uniqid');
            $(printdiv).html(printcontent);
            $('body').before(printdiv);
            $('body').css('display', 'none');
            window.print();
            if(help.IEVersion() == 8){
                setTimeout(function() {
                    $scope.$$nextSibling.dismissModal();
                    $scope.printCostDetails();
                    $("#uniqid").remove();
                    $('body').css('display', 'block');
                },0);
            } else {
                $("#uniqid").remove();
                $('body').css('display', 'block');
            }
            
        };

        /**
         * Removing the additional Pharmacies/Pharmacy
         * @param additionalPhar
         * @param arrayValues
         */
        $scope.removeAdditionalPharmacies = function(additionalPhar, arrayValues) {
            hideErrorMessage();
            angular.forEach($scope.costResultDataModel.additionalPharmacies, function(eachResponseArray, key) {
                if (additionalPhar.pharmacy.pharmacyNumber === eachResponseArray.pharmacy.pharmacyNumber) {
                    $scope.costResultDataModel.additionalPharmacies.splice(key, 1);
                    $scope.costResultDataModel.additionPharmacyLimitError = false;
                }
            });
        };
        /**
         *  Cancelling the new search
         */
        $scope.cancelNewSearch = function() {
            removeDuplicateDrugArray(currentDrugSearchInput);
            $scope.newSearch = false;
        };
        /**
         * Removing Drug searched
         * @param removePastSearch
         * @param index
         */

        $scope.removeSearchedDrug = function (removePastSearch, index) {
            $scope.pastSearchData.generic[index].expandedView = false;
            $scope.isExpanded=false;
            hideErrorMessage();
            $scope.pastSearchData.generic.splice(index, 1);
            if (typeof(Storage) !== "undefined") {
                var sessionStoredData = help.getSessionStorage(activeModel.tokenId);
                if (sessionStoredData && sessionStoredData['pastSearch']) {
                    sessionStoredData['pastSearch'] = $scope.pastSearchData;
                    help.setSessionStorage(activeModel.tokenId, sessionStoredData);
                }
            }
        };
        /**
         * Expanding the drug list to see more details
         * @param drugDetailsSel
         * @param index
         */
        $scope.expandDrugList = function(drugDetailsSel, index) {
            //hideErrorMessage();
        $scope.selectedIndex=index;

            this.execute = function () {
                angular.forEach($scope.pastSearchData.generic, function (eachResponseArray, key) {
                    if (index === key) {
                        var deferred = $q.defer();

                        var pastSearchedData=$scope.pastSearchData.generic[index],isMailLessError=false;
                        var pastDrugSerchDetails = {
                            'userName': pastSearchedData.userName,
                            'drugName': pastSearchedData.drugName,
                            'pharmacy': pastSearchedData.pharmacy,
                            'dosage': pastSearchedData.dosage,
                            'drugDetails': pastSearchedData.drugDetails
                        };
                        isMailLessError=hasMailLessError(pastDrugSerchDetails.drugDetails);
                        CommonDrugService.currentDrugPriceDetails(pastDrugSerchDetails).then(function (response) {
                            hideErrorMessage();

                            if(isDuplicateDrug){
                                showErrorMessage($scope.FastContentService.drugSearch.errorMsgs.drugSearchedAlready, "", true);
                            }
                            $scope.pastSearchData.generic[index].expandedView = true;
                            $scope.isExpanded=true;

                            var modelResponseData = costResultDataService.formDataModel(response, "generic");
                            for (var i in modelResponseData.drugNames.generic) {
                                if(!isNaN(parseInt(i))) {
                                    if (modelResponseData.drugNames.generic[i].drugType == "brand") {
                                        modelResponseData.drugNames.generic[i].drugType = $scope.FastContentService.searchResults.cost.label.brand;
                                        //responsedata.drugDetails[i].name.heading = "You Searched For:";
                                    }
                                    else modelResponseData.drugNames.generic[i].drugType = $scope.FastContentService.searchResults.cost.label.generic;
                                }
                            }
                            activeModel.pastCostResultDataModel = modelResponseData;
                           //
                            $scope.pastCostResultDataModel = activeModel.pastCostResultDataModel;
                            $scope.pastCostResultDataModel.tad = angular.copy(eachResponseArray.tad);
                            $scope.pastCostResultDataModel.memberSelect = eachResponseArray.userName;
                            $scope.pastCostResultDataModel.pharmacy = eachResponseArray.pharmacy;
                            $scope.pastCostResultDataModel.additionalPharmaciesArray = pastSearchedData.additionalPharmacies;
                            $scope.pastCostResultDataModel.drugDetails = pastSearchedData.drugDetails;
                            $scope.pastCostResultDataModel.bestValue = response.best;
                            $scope.pastCostResultDataModel.state = "past";

                             if(!$scope.pastSearchData.generic[index].bestValue){
                                 $scope.pastSearchData.generic[index].bestValue={};
                             }
                             if(response.best && response.best.ind && response.best.bestValuePrice !=undefined){
                                 $scope.pastSearchData.generic[index].bestValue.bestValuePrice="$"+(parseFloat(response.best.bestValuePrice).toFixed(2));
                                 $scope.pastSearchData.generic[index].bestValue.drugType=response.best.type == "brandMail" || response.best.type == "brandRetail" ? "for Brand Name" : "for Generic Equivalent";
                                 $scope.pastSearchData.generic[index].bestValue.purchaseType=response.best.type == "brandMail" ? "(Mail service)" : "(Store pickup)";
                             }else{
                                 if(!$scope.pastSearchData.generic[index].bestValue){
                                     $scope.pastSearchData.generic[index].bestValue={};
                                 }
                                 $scope.pastSearchData.generic[index].bestValue.bestValuePrice="N/A";
                                 $scope.pastSearchData.generic[index].bestValue.drugType="";
                                 $scope.pastSearchData.generic[index].bestValue.purchaseType="";
                             }
                            if(response.best && response.best.ind && response.best.bestValuePrice !=undefined){
                                var bestValueDrugDetails = {
                                    "drugType": response.best.type == "brandMail" || response.best.type == "brandRetail" ? "for Brand Name" : "for Generic Equivalent",
                                    "purchaseType": response.best.type == "brandMail" ? "(Mail service)" : "(Store pickup)"
                                };
                                angular.extend($scope.pastSearchData.generic[index].bestValue,bestValueDrugDetails);
                            }
                            angular.extend($scope.pastCostResultDataModel.bestValue, response.best);
                            //angular.extend($scope.pastCostResultDataModel.tad, eachResponseArray.tad);
                            $scope.pastCostResultDataModel.tad.tadVisibility.tadExpanded=angular.copy(eachResponseArray.tad.tadVisibility.tadExpanded);
                            angular.forEach(pastSearchedData.additionalPharmacies, function (pastAdditionalPham) {
                                searchForPastAdditionalPharmacy(pastAdditionalPham,true);
                            });

                            setCostModalPriceType(response,$scope.pastCostResultDataModel);
                            if($scope.pastCostResultDataModel.isMail && isMailLessError){
                                pastDrugSerchDetails.drugDetails.isMailLessError=isMailLessError;
                            }
                            if (eachResponseArray.drugDetails.mailDrug) {
                                $scope.pastCostResultDataModel.mailDrug = eachResponseArray.drugDetails.mailDrug;
                            }
                            if (eachResponseArray.drugDetails.retailDrug) {
                                $scope.pastCostResultDataModel.retailDrug = eachResponseArray.drugDetails.retailDrug;
                            }
                            makeTADCurrentState($scope.pastSearchData.generic[index]);

                        }, function (error) {
                            if (typeof error=="object" && error.header) {
                                var header = error.header.statusCode ? error.header.statusCode : "Service Unavailable";
                                var msg = error.header.statusDesc ? error.header.statusDesc : "Please contact administrator.";
                                showErrorMessage(header, msg, true,FastContentService.drugSearch.errorMsgs.pastSearch);
                                $scope.hideResultPage=false;
                            } else {
                                showErrorMessage($scope.FastContentService.common.service_unavailable,$scope.FastContentService.common.service_unavailable, true,$scope.FastContentService.drugSearch.errorMsgs.pastSearch);
                                $scope.hideResultPage=false;
                            }
                        });

                    } else {
                        $scope.pastSearchData.generic[key].expandedView = false;
                        $scope.isExpanded=false;
                    }
                }, this);

            };
            this.execute();
        };
        /**
         * Collapsing the drug details from drug List
         * @param drugDetailsSel
         * @param index
         */
        $scope.collapseDrugList = function(drugDetailsSel, index) {
            $scope.pastSearchData.generic[index].expandedView = false;
            $scope.isExpanded=false;
        };
        /**
         * Getting cost of drug for he current drug
         */

        function getCurrentDrugCost() {
            //hideErrorMessage();
            personalization.getPersonlizationContent().then(function(personlizationContent){
                if (personlizationContent  && personlizationContent[1001]) {
                    activeModel.bestPharmaciesPzn=personlizationContent["1001"]['resourceVisibleIndicator'] ;
                }
            });
            $scope.mobileData={};
            currentDrugSearchInput.userName = userSessionData.getSelectedUserName();
            currentDrugSearchInput.pharmacy = angular.extend({}, userSessionData.getSelectedPharmacy());
            currentDrugSearchInput.drugName = userSessionData.getSelectedDrugName();
            currentDrugSearchInput.drugDetails = userSessionData.getSelectedDrugDetails();
            if(currentDrugSearchInput.additionalPharmacies){
                currentDrugSearchInput.additionalPharmacies = angular.extend(currentDrugSearchInput.additionalPharmacies, userSessionData.getAdditionalPharmacies());
            }
            else {
            currentDrugSearchInput.additionalPharmacies = userSessionData.getAdditionalPharmacies();
            }
            currentDrugSearchInput.dosage = userSessionData.getSelectedDosage();
            currentDrugSearchInput.state = "current";
            var request = currentDrugSearchInput,isMailLessError=false;;
            var deferred = $q.defer();

            isMailLessError=hasMailLessError(currentDrugSearchInput.drugDetails);
            CommonDrugService.currentDrugPriceDetails(request).then(function (response) {
                hideErrorMessage();
                if ($scope.myValue) {

                    var responsedata = costResultDataService.formDataModel(response, "generic");

                    activeModel.costResultDataModel = responsedata;
                    $scope.costResultDataModel = activeModel.costResultDataModel;
                    $scope.costResultDataModel.resultFlag = true;
                    $scope.costResultDataModel.bestValue = response.best;
                    $scope.costResultDataModel.bestValue.bestValueSource = "current";
                    $scope.costResultDataModel.pharmacy = currentDrugSearchInput.pharmacy;

                    var bestValueDrugDetails = {
                        "drugType": response.best.type == "brandMail" || response.best.type == "brandRetail" ? "for Brand Name" : "for Generic Equivalent",
                        "purchaseType": response.best.type == "brandMail" ? "(Mail service)" : "(Store pickup)"
                    };
                    var bestValueDetails = angular.extend(bestValueDrugDetails, response.best);
                    userSessionData.setBestValue(bestValueDetails);
                    for (var i in activeModel.costResultDataModel.drugNames.generic) {
                        activeModel.costResultDataModel.drugNames.generic[i].drugType = (activeModel.costResultDataModel.drugNames.generic[i].drugType == "brand" ? $scope.FastContentService.searchResults.cost.label.brand : $scope.FastContentService.searchResults.cost.label.generic);
                    }

                    setCostModalPriceType(response,$scope.costResultDataModel);
                    if($scope.costResultDataModel.isMail && isMailLessError){
                        currentDrugSearchInput.drugDetails.isMailLessError=isMailLessError;
                    }

                    if (currentDrugSearchInput.drugDetails.mailDrug) {
                        $scope.costResultDataModel.mailDrug = currentDrugSearchInput.drugDetails.mailDrug;
                    }
                    if (currentDrugSearchInput.drugDetails.retailDrug) {
                        $scope.costResultDataModel.retailDrug = currentDrugSearchInput.drugDetails.retailDrug;
                    }

                    $scope.costResultDataModel.state = "current";
                    $scope.costResultDataModel.tad = {"tadVisibility": $scope.tadVisibility};

                    angular.forEach(currentDrugSearchInput.additionalPharmacies, function (additionalPharmacies) {
                        searchForAdditionalPharmacy(additionalPharmacies, true);
                    });
                    if(currentDrugSearchInput.tad){
                        $scope.costResultDataModel.tad=angular.copy(currentDrugSearchInput.tad);
                    }


                    drugCostHelper.setSessionData(currentDrugSearchInput);
                }
                else {
                    costDetailForMobile(response);
                }

                $scope.hideResultPage=false;
            }, function (error) {
                if (typeof error=="object" && error.header) {
                    var header = error.header.statusCode ? error.header.statusCode : "Service Unavailable";
                    var msg = error.header.statusDesc ? error.header.statusDesc : "Please contact administrator.";
                    showErrorMessage(header, msg, true,FastContentService.drugSearch.errorMsgs.currentSearch);
                    $scope.hideResultPage=false;
                } else {
                    showErrorMessage($scope.FastContentService.common.service_unavailable,$scope.FastContentService.common.service_unavailable, true,$scope.FastContentService.drugSearch.errorMsgs.currentSearch);
                    $scope.hideResultPage=false;
                }
            });
        }

        getCurrentDrugCost();
        /**
         * Function to locate pharmacy in Bing map
         * @param result
         * @param mode
         */
        $scope.pharmacyLocator = function (result, mode) {
            hideErrorMessage();
            if (result.state !== "current") {
                if (result.additionalPharmacies.length > 3) {
                    $scope.pastCostResultDataModel.additionPharmacyLimitError = true;
                    //showErrorMessage($scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy,$scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy, true);
                } else {
                    pharmacyLocatorHelper.openPharmacyLocator(searchForPastAdditionalPharmacy);
                }
            } else {
                $scope.wtEventHandler('ADDPHARM1');
                if (result.additionalPharmacies.length > 3) {
                    $scope.costResultDataModel.additionPharmacyLimitError = true;
                    //showErrorMessage($scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy,$scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy, true);
                } else {
                    pharmacyLocatorHelper.openPharmacyLocator(searchForAdditionalPharmacy);
                }
            }
        };
        /**
         * Getting details of the selected pharmacy
         * @param data
         */
        $scope.selectedPharmacy = function(data) {
            var pharmacyData={};
            pharmacyData={'pharmacy':''};

            drugSearchHelper.getPharmacyDetails(data).then(function(success){
                pharmacyData.pharmacy =success;
                if(selectedState==='past'){
                    updateSearchCriteria(pharmacyData);
                }
                else{
                    userSessionData.setSelectedPharmacy(pharmacyData.pharmacy);
                    updateSearchCriteria();
                }
            });

            //$scope.modifyBestValueIndicator($scope.costResultDataModel);
        };
        /**
         * Searching additional pharmacy
         * @param pharmacyDetails
         */


            ///launch new pharmacy locator

        $scope.changeAdditonalPharmacy= function(pharmacyNumber){
            hideErrorMessage();
            pharmacyLocatorHelper.openPharmacyLocator($scope.selectedPharmacy);
        };

        var searchForAdditionalPharmacy = function (pharmacyDetails, savedData) {

            var drugSearchCriteria =
            {
                "userName": userSessionData.getSelectedUserName(),
                "pharmacy": pharmacyDetails,
                "drugName": userSessionData.getSelectedDrugName(),
                "drugDetails": userSessionData.getSelectedDrugDetails(),
                "dosage": userSessionData.getSelectedDosage(),
                "visibility": true,
                "expandedView": true
            };

            getAdditionalPharmacy($scope.costResultDataModel, pharmacyDetails, drugSearchCriteria,savedData).then(function (additionalPharmacies) {
                if (additionalPharmacies) {
                    $scope.costResultDataModel.additionalPharmacies.push(additionalPharmacies);
                    $scope.modifyBestValueIndicator($scope.costResultDataModel,additionalPharmacies);
                    if ($scope.costResultDataModel.additionalPharmacies.length > 3) {
                        $scope.costResultDataModel.additionPharmacyLimitError = true;
                        //showErrorMessage($scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy,$scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy, true);
                    }


                    if (!savedData) {
                        if (!currentDrugSearchInput.additionalPharmacies) {
                            currentDrugSearchInput.additionalPharmacies = [];
                        }
                        currentDrugSearchInput.additionalPharmacies.push(additionalPharmacies.pharmacy);
                        drugCostHelper.setSessionData(currentDrugSearchInput);
                    }
                }
            });
        };
        /**
         *  Searching the previous additional pharmacy
         * @param pharmacyDetails
         */
        var searchForPastAdditionalPharmacy = function (pharmacyDetails, savedData) {
            var pastCostResultDataModel = $scope.pastCostResultDataModel;
            var drugSearchCriteria =
            {
                "userName": pastCostResultDataModel.memberSelect,
                "pharmacy": pharmacyDetails,
                "drugName": pastCostResultDataModel.drugNames,
                "drugDetails": pastCostResultDataModel.drugDetails,
                "dosage": pastCostResultDataModel.dosage,
                "visibility": true,
                "expandedView": true
            };
            getAdditionalPharmacy(pastCostResultDataModel, pharmacyDetails, drugSearchCriteria).then(function (additionalPharmacies) {
                if (additionalPharmacies) {
                    pastCostResultDataModel.additionalPharmacies.push(additionalPharmacies);
                    $scope.modifyBestValueIndicator($scope.pastCostResultDataModel);
                    if (!savedData) {
                        $scope.pastSearchData.generic[$scope.selectedIndex].additionalPharmacies.push(additionalPharmacies.pharmacy);
                        drugCostHelper.setSessionData($scope.pastSearchData, true);
                    }
                }
            });
        };

        function getAdditionalPharmacy(costDataModel, pharmacyDetails, drugSearchCriteira,savedData) {

            if(!savedData) {
                angular.forEach(costDataModel.additionalPharmacies, function (tmpArray) {
                    if (tmpArray.pharmacy.pharmacyNumber === pharmacyDetails.pharmacyNumber) {
                        showErrorMessage($scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy, true);
                    }
                });

                if (currentDrugSearchInput.pharmacy.pharmacyId === pharmacyDetails.pharmacyNumber) {
                    showErrorMessage($scope.FastContentService.searchResults.cost.btn.duplicateAddPharmacy, true);
                }
            }
            var deferred =$q.defer();
            if (!$scope.error.Ind) {

                CommonDrugService.currentDrugPriceDetails(drugSearchCriteira, 'additionalPharmacies').then(function (response) {
                    var modelResponseData = costResultDataService.formDataModel(response, "additionalPharmacy");
                    var additionalPharmaciesDetails = {};
                    additionalPharmaciesDetails.pharmacy = pharmacyDetails;
                    additionalPharmaciesDetails.costDetails = response;
                    additionalPharmaciesDetails.newCostDetails = modelResponseData;
                    deferred.resolve(additionalPharmaciesDetails);
                }, function (error) {
                    deferred.reject();
                });
            } else {
                window.scrollTo(0, 0);
                deferred.reject();
            }
            return deferred.promise;
        }

        /**
         * Updating Error message
         * @param errorMessage
         */
        function updateErrorMessage(errorMessage) {
            if (errorMessage) {
                $scope.error.message = errorMessage;
            } else {
                $scope.error.message = '';
            }
        }

        /**
         * Duplicated drug from list is to be deleted(spliced)
         * @param drugArray
         */
        var removeDuplicateDrugArray = function(drugArray) {
            angular.forEach($scope.searchDrugDetailsArray, function(tmpArray, key) {
                if (drugArray.drugName === tmpArray.drugName) {
                    $scope.searchDrugDetailsArray.splice(key, 1);
                }
            });
        };
        /**
         * Checks for the duplicate drug in the list
         * @param drugname
         * @returns {number}
         */
        function checkDuplicateDrug(pastSearchData, drugname) {

            if ((!('generic' in pastSearchData)) || pastSearchData.generic.length <= 0) {
                return -1;

            }
            else
            {
                for (var pos = 0; pos < pastSearchData.generic.length; pos++) {
                    if (drugname.toUpperCase() == pastSearchData.generic[pos].drugName.toUpperCase()) {
                        return pos;
                    }
                }

            }

        }

        /**
         * New Search -Start
         */
        $scope.loadNewSearchPopup = function(isMobile) {
            hideErrorMessage();
            //WebAnalytics code : Do not Delete
            $scope.$emit('TealiumWebAnalytic', {"key": "Scenario1a"});

            var modalProperties = {
                "callback": newSearchCallback,
                "templateUrl": 'modules/drugsearch/views/drug-search.html',
                "windowClass": "drugSearchModal",
                "size": 'full',
                "data":{"newSearch":true}
            };
            if (isMobile) {
                modalProperties = {
                    "callback": getCurrentDrugCost,
                    "templateUrl": 'modules/drugsearch/views/drug-search.html',
                    "windowClass": "drugSearchModal",
                    "size": "full",
                    "data": {
                        "editCriteriaData": {
                            "userInfoEdit": currentDrugSearchInput
                        }
                    }
                };
            }
            CoreCommonsModal.generalModal(modalProperties);
        };
        /**
         *  New Search -End
         */

        function newSearchCallback() {
            isDuplicateDrug=false;
            $scope.mobileData={};
            //check if the past Search data is same as the current search data, then simply close the modal
            var newDrugSerchDetails = {
                'userName': userSessionData.getSelectedUserName(),
                'drugName': userSessionData.getSelectedDrugName(),
                'pharmacy': userSessionData.getSelectedPharmacy(),
                'dosage': userSessionData.getSelectedDrugDetails(),
                'drugDetails': userSessionData.getSelectedDrugDetails()
            };

            if ('generic' in $scope.pastSearchData) {
                angular.forEach($scope.pastSearchData.generic, function (eachResponseArray, key) {
                    eachResponseArray.expandedView = false;
                });
            }
            if (currentDrugSearchInput.drugName.toUpperCase() == newDrugSerchDetails.drugName.toUpperCase()) {
                if ($scope.closeModel){
                    $scope.closeModel();    //simply close the new Search pop up as the results are already shown in the current drug search results page
                }
                showErrorMessage($scope.FastContentService.drugSearch.errorMsgs.drugSearchedAlready, "", true);
                //$scope.notify.presentInPat = true;//  error msg for "You have already searched for this drug. Check your results below."
                return;
            }

            var pos = checkDuplicateDrug($scope.pastSearchData, newDrugSerchDetails.drugName);
            if (pos >= 0) {
                isDuplicateDrug=true;
                $scope.expandDrugList($scope.pastSearchData.generic[pos], pos);
                if ($scope.closeModel)
                    $scope.closeModel();    //simply close the new Search pop up as the results are already shown in the current drug search results page
                return;
            }
            else {
                //showErrorMessage($scope.FastContentService.drugSearch.errorMsgs.drugSearchedAlready, "", true,$scope.FastContentService.drugSearch.errorMsgs.pastSearch);
                hideErrorMessage();
                //$scope.notify.presentInPat = false;
            }

            //check in the pastSearchData if any past search is expanded , collapse
            var currentSearchedValues = {};
            currentSearchedValues.userName = currentDrugSearchInput.userName;
            currentSearchedValues.pharmacy = currentDrugSearchInput.pharmacy;
            currentSearchedValues.dosage = currentDrugSearchInput.dosage;
            currentSearchedValues.drugName = currentDrugSearchInput.drugName;
            currentSearchedValues.drugDetails = currentDrugSearchInput.drugDetails;
            currentSearchedValues.bestValue = userSessionData.getBestValue();
            currentSearchedValues.expandedView = false;
            currentSearchedValues.additionalPharmacies = [];
            currentSearchedValues.tad = angular.copy($scope.costResultDataModel.tad);
            if(currentSearchedValues.bestValue && currentSearchedValues.bestValue.ind && currentSearchedValues.bestValue.bestValuePrice !=undefined){
                if(isNaN(parseFloat(currentSearchedValues.bestValue.bestValuePrice))){
                    currentSearchedValues.bestValue.bestValuePrice=currentSearchedValues.bestValue.bestValuePrice;
                }else{
                    currentSearchedValues.bestValue.bestValuePrice="$"+(parseFloat(currentSearchedValues.bestValue.bestValuePrice).toFixed(2));
                }

            }else{
                if(!currentSearchedValues.bestValue){
                    currentSearchedValues.bestValue={

                    };
                }
                currentSearchedValues.bestValue.drugType="";
                currentSearchedValues.bestValue.purchaseType="";
                currentSearchedValues.bestValue.bestValuePrice="N/A";
            }

            angular.forEach($scope.costResultDataModel.additionalPharmacies, function (eachArray) {
                currentSearchedValues.additionalPharmacies.push(eachArray.pharmacy);
            });

            $scope.costResultDataModel.state = "past";

            resetTADVisibilityToInitial();
            var isMailLessError=false;
            isMailLessError=hasMailLessError(newDrugSerchDetails.drugDetails);
            CommonDrugService.currentDrugPriceDetails(newDrugSerchDetails).then(function (response) {
                currentDrugSearchInput.userName = newDrugSerchDetails.userName;
                currentDrugSearchInput.pharmacy = newDrugSerchDetails.pharmacy;
                currentDrugSearchInput.dosage = newDrugSerchDetails.dosage;
                currentDrugSearchInput.drugName = newDrugSerchDetails.drugName;
                currentDrugSearchInput.drugDetails = newDrugSerchDetails.drugDetails;
                currentDrugSearchInput.additionalPharmacies = [];
                currentDrugSearchInput.state = "current";

                if ($scope.myValue) {
                    var responsedata = costResultDataService.formDataModel(response, "generic");

                    for (var i in responsedata.drugNames.generic) {
                        if (!isNaN(parseInt(i))) {
                            if (responsedata.drugNames.generic[i].drugType == "brand") {
                                responsedata.drugNames.generic[i].drugType = $scope.FastContentService.searchResults.cost.label.brand;
                                //responsedata.drugDetails[i].name.heading = "You Searched For:";
                            }
                            else responsedata.drugNames.generic[i].drugType = $scope.FastContentService.searchResults.cost.label.generic;
                        }
                    }

                    $scope.costResultDataModel = responsedata;
                    activeModel.costResultDataModel = responsedata;
                    $scope.costResultDataModel.state = "current";
                    $scope.costResultDataModel.tad = {"tadVisibility": $scope.tadVisibility};
                    $scope.costResultDataModel.additionalPharmacies = [];
                    $scope.costResultDataModel.pharmacy = newDrugSerchDetails.pharmacy;
                    $scope.costResultDataModel.bestValue = response.best;
                    $scope.costResultDataModel.bestValue.bestValueSource = "current";
                    $scope.costResultDataModel.isRetail=$scope.costResultDataModel.Costs.generic.retail.length>0 ? true : false;

                    setCostModalPriceType(response,$scope.costResultDataModel);
                    if($scope.costResultDataModel.isMail && isMailLessError){
                        currentDrugSearchInput.drugDetails.isMailLessError=isMailLessError;
                    }
                    resetTADVisibilityToInitial();
                    if (response.best && response.best.ind) {
                        var bestValueDrugDetails = {
                            "drugType": response.best.type == "brandMail" || response.best.type == "brandRetail" ? "for Brand Name" : "for Generic Equivalent",
                            "purchaseType": response.best.type == "brandMail" ? "(Mail service)" : "(Store pickup)"
                        };
                    } else {
                        var bestValueDrugDetails = {}
                    }

                    var bestValueDetails = angular.extend(bestValueDrugDetails, response.best);
                    userSessionData.setBestValue(bestValueDetails);

                    //check for the array length, if it is 20 then pop the 20th element
                    if ($scope.pastSearchData.generic.length == 20)  //20 can be moved to customizable data
                        $scope.pastSearchData.generic.pop();

                    $scope.pastSearchData.generic.unshift(currentSearchedValues);
                    activeModel.pastSearchData = $scope.pastSearchData;

                    /*Update session storage*/
                    drugCostHelper.setSessionData($scope.pastSearchData, true);
                    drugCostHelper.setSessionData(newDrugSerchDetails);
                    /*Update session storage*/

                    if (currentDrugSearchInput.drugDetails.mailDrug) {
                        $scope.costResultDataModel.mailDrug = currentDrugSearchInput.drugDetails.mailDrug;
                    }
                    if (currentDrugSearchInput.drugDetails.retailDrug) {
                        $scope.costResultDataModel.retailDrug = currentDrugSearchInput.drugDetails.retailDrug;
                    }
                }else{
                    costDetailForMobile(response);
                }
            }, function (error) {
                if (typeof error == "object" && error.header) {
                    var header = error.header.statusCode ? error.header.statusCode : "Service Unavailable";
                    var msg = error.header.statusDesc ? error.header.statusDesc : "Please contact administrator.";
                    showErrorMessage(header, msg, true,'');
                } else {
                    showErrorMessage($scope.FastContentService.common.service_unavailable,$scope.FastContentService.common.service_unavailable, true,"");
                }
            });
        }

        /**
         * Viewing Cost details
         * @param costDetails
         */
            //should initialize this $scope.drugtype
        $scope.viewCostDetails = function(costDetails) {

            hideErrorMessage();
            var employerCostArray=["N/A","N/A"];
            var totalCostArray=["N/A","N/A"];
            var drugChannel=null;
            var yourCostDecimal='';


            if(costDetails.costDetail.PricetotalObject && costDetails.costDetail.PricetotalObject.decimal) {
                    yourCostDecimal=costDetails.costDetail.PricetotalObject.decimal;
            }

            if(costDetails.costDetail.Price.costEmployer.indexOf(".")>0) {
                var fixedEmployerCost=parseFloat(costDetails.costDetail.Price.costEmployer).toFixed(2);
                employerCostArray = fixedEmployerCost.split(".");
            }
            if(costDetails.costDetail.Price.totalDrugCost.indexOf(".")>0) {
                var fixedTotalDrugCostt=parseFloat(costDetails.costDetail.Price.totalDrugCost).toFixed(2);
                totalCostArray = fixedTotalDrugCostt.split(".");
            }

            $scope.costDetailsBreakDown = {};
            var request = currentDrugSearchInput;
            var deferred = $q.defer();
            var cliamDetails = {};
            if (costDetails) {
                var costPopupDetails = costDetails;
                if(costDetails.costDetail.drugCostType) {
                    if(costDetails.costDetail.drugCostType=="mail") {
                        drugChannel = $scope.FastContentService.searchResults.costBreakDown.mailDrugChannel;
                    }
                    else if(costDetails.costDetail.drugCostType=="retail") {
                        drugChannel = costPopupDetails.costDetail.Pharmacy;
                    }
                }

            }


            if (help.getUserAgent(navigator.userAgent) == 'DESKTOP') {
                var costAnnual;
                if(costPopupDetails.costDetail && costPopupDetails.costDetail.Price && costPopupDetails.costDetail.Price.costAnnual){
                    costAnnual=costPopupDetails.costDetail.Price.costAnnual;
                    if(costAnnual && (typeof costAnnual=== 'object' ||costAnnual instanceof Object)){
                        costAnnual=costAnnual.__text;
                    }
                    costAnnual = costAnnual.replace('-',"");
                }else{
                    costAnnual="N/A";
                }
                $scope.costDetailsBreakDown = {
                    'drug': costPopupDetails.drugDetails.drugName.__cdata || '',
                    'strength': costPopupDetails.drugDetails.drugStrength.__cdata,
                    'form': costPopupDetails.drugDetails.drugForm.__cdata,
                    'pharmacy':costPopupDetails.costDetail.Pharmacy,
                    //'pharmacy': "CVS/caremark Mail Service Pharmacy", //TODO
                    'daySupply': costPopupDetails.dosageDetail.DosageSupply,
                    'totalQuantity': costPopupDetails.dosageDetail.DosageQuantity,
                    'ndc': costPopupDetails.costDetail.Price.ndcId,
                    'cost': costPopupDetails.costDetail.PricetotalObject ? costPopupDetails.costDetail.PricetotalObject.integer : '',
                    //'costDecimal': costPopupDetails.costDetail.PricetotalObject ? costPopupDetails.costDetail.PricetotalObject.decimal : '',
                    'costDecimal': yourCostDecimal,
                    'costAnnual': costAnnual,
                    'employerCost': employerCostArray[0],
                    'employerCostDecimal': employerCostArray[1],
                    //'purchaseType': costPopupDetails.dosageDetail.purchaseType,
                    'purchaseType': drugChannel,
                    'empAnnual': costPopupDetails.costDetail.Price.costEmployerAnnual,
                    'totalCost': totalCostArray[0],
                    'totalCostDecimal': totalCostArray[1],
                    'totalAnnual': costPopupDetails.costDetail.Price.totalDrugCostAnnual,
                    'coPay': costPopupDetails.costDetail.Price.memberCopayAmount,
                    'deductible': costPopupDetails.costDetail.Price.deductible,
                    'additional': 0.00,
                    'hra': 0.00,
                    'medicare':costPopupDetails.drugDetails.medicare,
                    "costToday":costPopupDetails.costDetail.Price.costToday
                };

                /*console.log(drugType);
                 console.log(costDetails);*/
                //console.log($scope.costDetailsBreakDown, '');


                var modalProperties = {
                    data: {
                        modalData: $scope.costDetailsBreakDown,
                        fastContentService: $scope.FastContentService
                    },
                    //data: $scope.costDetailsBreakDown,
                    onReady: $scope.costPopupReady,
                    templateUrl: 'modules/searchresult/views/viewCost-popup.html',
                    windowClass: "drug-cost-details",
                    size: 'medium'
                };
                $scope.costDetailsBreakDown = angular.extend($scope.costDetailsBreakDown, $scope.FastContentService.common);

                CoreCommonsModal.viewDrugCostDetails(modalProperties);

            }
            else {
                var PricetotalObject=null;
                $scope.costDetailsBreakDown = {
                    'drug': costPopupDetails.drugDetails.name.drugName.__cdata || '',
                    'strength': costPopupDetails.drugDetails.name.drugStrength.__cdata,
                    'form': costPopupDetails.drugDetails.name.drugForm.__cdata,
                    'pharmacy':costPopupDetails.costDetail.Pharmacy,
                    //'pharmacy': "not done",
                    'daySupply': costPopupDetails.dosageDetail.DosageSupply,
                    'totalQuantity': costPopupDetails.dosageDetail.DosageQuantity,
                    'ndc': costPopupDetails.costDetail.Price.ndcId,
                    //'cost': costPopupDetails.costDetail.PricetotalObject ? costPopupDetails.costDetail.PricetotalObject.integer : '',
                    //'costDecimal': costPopupDetails.costDetail.PricetotalObject ? costPopupDetails.costDetail.PricetotalObject.decimal : '',
                    //'costDecimal': yourCostDecimal,
                    'costAnnual': costPopupDetails.costDetail.Price.costAnnual,
                    'employerCost': employerCostArray[0],
                    'employerCostDecimal': employerCostArray[1],
                    //'purchaseType': costPopupDetails.dosageDetail.purchaseType,
                    'purchaseType': drugChannel,
                    'empAnnual': costPopupDetails.costDetail.Price.costEmployerAnnual,
                    'totalCost': totalCostArray[0],
                    'totalCostDecimal': totalCostArray[1],
                    'totalAnnual': costPopupDetails.costDetail.Price.totalDrugCostAnnual,
                    'coPay': costPopupDetails.costDetail.Price.copayEmployer,
                    'deductible': costPopupDetails.costDetail.Price.deductible,
                    'additional': 0.00,
                    'hra': 0.00
                };


                if(costPopupDetails.costType==="mail"){
                    if (costPopupDetails.costDetail.PricetotalObject && (costPopupDetails.costDetail.PricetotalObject.decimal || costPopupDetails.costDetail.PricetotalObject.integer)) {
                            PricetotalObject = {
                                'cost': costPopupDetails.costDetail.PricetotalObject.integer,
                                'costDecimal': costPopupDetails.costDetail.PricetotalObject.decimal

                            }
                    }
                }
                else if(costPopupDetails.costType==="retail"){
                    if (costPopupDetails.costDetail.Price.copayEmployerObject && (costPopupDetails.costDetail.Price.copayEmployerObject.decimal || costPopupDetails.costDetail.Price.copayEmployerObject.integer)) {
                            PricetotalObject = {
                                'cost': costPopupDetails.costDetail.Price.copayEmployerObject.integer,
                                'costDecimal': costPopupDetails.costDetail.Price.copayEmployerObject.decimal
                            }
                    }
                }

                if(PricetotalObject !=null){
                    $scope.costDetailsBreakDown=angular.extend(PricetotalObject,$scope.costDetailsBreakDown);
                }

                $scope.$broadcast('ModalDataPop',$scope.costDetailsBreakDown);

            }


            if (costPopupDetails.drugDetails.isStCob || (costPopupDetails.drugDetails.name && costPopupDetails.drugDetails.name.isStCob)) {//(costPopupDetails.drugDetails.isStCob || (costPopupDetails.drugDetails.name && costPopupDetails.drugDetails.name.isStCob
                CommonDrugService.getSTCOBClaimDetails(request,costDetails).then(function (response) {
                    var primarystCobDetails;
                    var secondarystCobDetails;
                    if(response.primary && response.primary.response && response.primary.response.header && response.primary.response.header.statusCode  && response.primary.response.header.statusCode==='0000'){
                      primarystCobDetails = response.primary.response && response.primary.response.detail && response.primary.response.detail.claimDetailAmounts? response.primary.response.detail.claimDetailAmounts : undefined ;
                    }
                    if(response.secondary && response.secondary.response && response.secondary.response.header && response.secondary.response.header.statusCode==='0000'){
                        secondarystCobDetails = response.secondary.response.detail && response.secondary.response.detail.claimDetailAmounts? response.secondary.response.detail.claimDetailAmounts : undefined ;
                    }
                    if (primarystCobDetails && secondarystCobDetails) {

                         var deductible = 0;
                        var penalties = 0;
                        var copayEmployer = 0;
                        if (costDetails && costDetails.costDetail && costDetails.costDetail.Price) {
                            deductible = costDetails.costDetail.Price.deductible ? parseInt(costDetails.costDetail.Price.deductible) : 0;
                            penalties = costDetails.costDetail.Price.penalties !="N/A" ? parseInt(costDetails.costDetail.Price.penalties) : 0;
                            copayEmployer = costDetails.costDetail.Price.copayEmployer ? parseInt(costDetails.costDetail.Price.copayEmployer) : 0;
                        }

                        var cliamDetails = {
                            "PrimaryPaymentCurrentCost": primarystCobDetails.clientPayAmount ? parseInt(primarystCobDetails.clientPayAmount) + deductible + penalties : "NIL",
                            "SecondaryPaymentCurrentCost": secondarystCobDetails.clientPayAmount ? parseInt(secondarystCobDetails.clientPayAmount) + deductible + penalties : "NIL",
                           // "TotalAmountPaymentCurrentCost": stCobDetails.copayment ? parseInt(stCobDetails.copayment) + copayEmployer : "NIL",
                            "PrimaryCopayCurrentCost": primarystCobDetails.copayment ? parseInt(primarystCobDetails.copayment) : "NIL",
                            "SecondaryCopayCurrentCost": secondarystCobDetails.copayment ? parseInt(secondarystCobDetails.copayment) : "NIL",
                            //"TotalAmountCopayCurrentCost": stCobDetails.copayment ? parseInt(stCobDetails.copayment) * 2 : "NIL",
                            "PrimaryCoinsuranceCurrentCost": "NIL",
                            "SecondaryCoinsuranceCurrentCost": "NIL",
                            "TotalAmountCoinsuranceCurrentCost": "NIL",
                            "PrimaryPaymentAnnualCost": primarystCobDetails.clientPayAmount ? (parseInt(primarystCobDetails.clientPayAmount) + deductible + penalties) * 12 : "NIL",
                            "SecondaryPaymentAnnualCost": secondarystCobDetails.clientPayAmount ? (parseInt(secondarystCobDetails.clientPayAmount) + deductible + penalties) * 12 : "NIL",
                            //"TotalAmountPaymentAnnualCost": stCobDetails.clientPayAmount ? (parseInt(stCobDetails.clientPayAmount) + deductible + penalties) * 24 : "NIL",
                            "PrimaryCopayAnnualCost": primarystCobDetails.copayment ? parseInt(primarystCobDetails.copayment) * 12 : "NIL",
                            "SecondaryCopayAnnualCost": secondarystCobDetails.copayment ? parseInt(secondarystCobDetails.copayment) * 12 : "NIL",
                           // "TotalAmountCopayAnnualCost": stCobDetails.copayment ? parseInt(stCobDetails.copayment) * 24 : "NIL",
                            "PrimaryCoinsuranceAnnualCost": "NIL",
                            "SecondaryCoinsuranceAnnualCost": "NIL",
                            "TotalAmountCoinsuranceAnnualCost": "NIL",
                            "stcobdata": true
                        };
                        cliamDetails.TotalAmountPaymentCurrentCost= cliamDetails.PrimaryPaymentCurrentCost !="NIL" && cliamDetails.SecondaryPaymentCurrentCost!="NIL" ?parseInt(cliamDetails.PrimaryPaymentCurrentCost) + parseInt(cliamDetails.SecondaryPaymentCurrentCost) : 'NIL';
                        cliamDetails.TotalAmountCopayCurrentCost= cliamDetails.PrimaryCopayCurrentCost!="NIL" && cliamDetails.SecondaryCopayCurrentCost!="NIL" ? parseInt(cliamDetails.PrimaryCopayCurrentCost) + parseInt(cliamDetails.SecondaryCopayCurrentCost) :'NIL';
                        cliamDetails.TotalAmountPaymentAnnualCost= cliamDetails.PrimaryPaymentAnnualCost!="NIL" && cliamDetails.SecondaryPaymentAnnualCost!="NIL" ? parseInt(cliamDetails.PrimaryPaymentAnnualCost) +parseInt(cliamDetails.SecondaryPaymentAnnualCost) :"NIL";
                        cliamDetails.TotalAmountCopayAnnualCost= cliamDetails.PrimaryCopayAnnualCost!="NIL" && cliamDetails.SecondaryCopayAnnualCost!="NIL" ? parseInt(cliamDetails.PrimaryCopayAnnualCost) +parseInt(cliamDetails.PrimaryCopayAnnualCost) :'NIL';

                        $scope.costDetailsBreakDown = angular.extend($scope.costDetailsBreakDown, cliamDetails);

                        //console.log($scope.costDetailsBreakDown);

                    }

                });


            }

        };

        $scope.costPopupReady = function () {
            $('[data-toggle="popover"]').popover();
        };

        $scope.closePopupPrint=function()
        {
            help.printStateOn=!help.printStateOn;
        }


        $scope.printCostDetails = function () {
        
//          WebAnalytics code : Do not Delete
            $scope.$emit('TealiumWebAnalytic', {"key":"PRINT1"});
//          WebAnalytics code : Do not Delete

           // $('#printer_data_1').print();

            help.printStateOn=!help.printStateOn;
            $scope.printStateOn=help.printStateOn;


             var scopeCopy = {
              editDrugOption: $scope.editDrugOption,
                costResultDataModel: $scope.costResultDataModel,
                 currentDrugSearchInput:currentDrugSearchInput,
                pastCostResultDataModel:$scope.pastCostResultDataModel,
                expandedView:$scope.expandedView,
                FastContentService: $scope.FastContentService,
                tadExpand: $scope.tadExpand,
                checkAlternatives: $scope.checkAlternatives,
                printPopup: $scope.printPopup,
                closePopupPrint:$scope.closePopupPrint,
                 selectedIndex:$scope.selectedIndex,
                 isExpanded:$scope.isExpanded,
                 pastSearchData:$scope.pastSearchData
            };

            var modalProperties = {
                data: scopeCopy,
                templateUrl: 'modules/searchresult/views/print-text.html',
                windowClass: "print-drug-details",
                size: 'full'
            };

            CoreCommonsModal.printDrugDetails(modalProperties);

        };


        //GSM for Mobile
        $scope.loadGSMAlchemyPopUp = function (req) {
            hideErrorMessage();
            drugCostHelper.getGSMAlchemy(req).then(gsmSuccess, gsmError);
        };

        function loadGSMAlchemy(obj) {
            var modalProperties =
            {

                templateUrl: 'modules/searchresult/views/gsmalchemy.html',
                size: 'custom',
                data: obj
            };
            CoreCommonsModal.gsmAlchemyPopPreview(modalProperties);
        }

        function gsmSuccess(data) {
            hideErrorMessage();
            if(data.response && (data.response.detail!='' || data.GSMAlchemyResponse)) {
                var resp = data.response && data.response.detail || data.GSMAlchemyResponse; //.ContentPatientEducation
                var obj = {};
                obj.contentPatientEducation = resp.ContentPatientEducation;
                obj.listProducts = resp.ListProducts;
                if (resp.ListProductImages && resp.ListProductImages.ProductImage && resp.ListProductImages.ProductImage.ImageType) {
                    if (resp.ListProductImages.ProductImage.ImageType === 'drug_item') {
                        obj.imageUrl = "/portal/images/gsm/DrugItem_" + resp.ListProductImages.ProductImage.ImageId + ".JPG";
                    } else if (resp.ListProductImages.ProductImage.ImageType === 'package') {
                        obj.imageUrl = "/portal/images/gsm/AlchemyPackage_" + resp.ListProductImages.ProductImage.ImageId + ".JPG";
                    } else {
                        obj.imageUrl = "";
                    }
                    //location.origin
                }
                loadGSMAlchemy(obj);
            }
            else{
                //console.log("No Alchamy details found");
                showErrorMessage($scope.FastContentService.common.service_unavailable,$scope.FastContentService.common.service_unavailable, true);
            }

            return;
        }

        function gsmError(data) {
            if (data.response.header.statusCode === '2001')
                updateErrorMessage(errors.getErrorMessage('009'));
            else
                updateErrorMessage(errors.getErrorMessage('008'));
            loadGSMAlchemy({});
            return;
        }


        //TAD section to be moved to directives


        $scope.tadVisibility = {
            error: false,
            tadExpanded: false,
            tadList: false,
            alternatives: true,
            tadMain:true
        };
        /**
         * Checking Alternative drug
         * @param request
         * @param index
         * @param usr
         * @param pharmacy
         */
        $scope.checkAlternatives = function(request, index, usr, pharmacy) {
            hideErrorMessage();
            CommonDrugService.getTADDrugInformation(request, usr, pharmacy.pharmacyId).then(function(response) {
                if (request.state === 'current') {
                    $scope.costResultDataModel.tad.tadVisibility.tadList = true;
                    $scope.costResultDataModel.tad.tadVisibility.tadExpanded = true;
                    $scope.costResultDataModel.tad.tadVisibility.alternatives = false;
                    if(response.length>0){
                        $scope.costResultDataModel.tad.tadpriceList = response;
                    }else{
                        $scope.costResultDataModel.tad.tadVisibility.error=true;
                    }
                    currentDrugSearchInput.tad=angular.copy($scope.costResultDataModel.tad);
                    drugCostHelper.setSessionData(currentDrugSearchInput);
                        //TODO remove TAD if response .length is 0
                } else {
                    $scope.pastCostResultDataModel.tad.tadVisibility.tadList = true;
                    $scope.pastCostResultDataModel.tad.tadVisibility.tadExpanded = true;
                    $scope.pastCostResultDataModel.tad.tadVisibility.alternatives = false;
                    if(response.length>0){
                        $scope.pastCostResultDataModel.tad.tadpriceList = response;
                    }else{
                        $scope.pastCostResultDataModel.tad.tadVisibility.error=true;
                    }
                    $scope.pastSearchData.generic[index].tad=angular.copy($scope.pastCostResultDataModel.tad);

                }
            }, function (error) {
                if (request.state === 'current') {
                    $scope.costResultDataModel.tad.tadVisibility.tadErrorInd=true;
                }else{
                    $scope.pastCostResultDataModel.tad.tadVisibility.tadErrorInd=true;
                }
            });
        };
        /**
         * @TO DO
         * @param tad
         */
        /*$scope.tadRadioCheck = function(tad) {
            $scope.tadRad = tad;
        };*/
        /**
         * @TO DO
         * @param request
         * @param index
         */
        $scope.tadExpand = function(request, index) {
            hideErrorMessage();

            if(!$scope.firstClick){
                $scope.costResultDataModel.tad.tadVisibility.tadExpanded = true;
            }
            //WebAnalytics code do not remove
            //webAnalytics.wtEvent("ALTER1");
//            webAnalytics.webTrendsOnEvent("Page_Event", 21, "Navigation_View", "ta", "Page_Name", "Link : Search Successful", "Page_Category", "Check Drug Coverage and Cost", "Scenario_Name", "check_drug_cost", "Scenario_Step", "4");
        	$scope.$emit('TealiumWebAnalytic', {"key":"ALTER1"});
            var req = {};
            if (request.state === 'current') {

                if (! $scope.costResultDataModel.tad.tadRadio) {
                   req.ndcId=request.retailDrug && request.retailDrug.ndcId;

                    drugCostHelper.getDrugIndicationsByNDCId(req).then(function (response) {
                        if(response.response.header.statusCode ==="0000" && response.response.detail && response.response.detail.tadResponse&& response.response.detail.tadResponse.drugIndications){
                            var healthArray=[];
                            if(Array.isArray(response.response.detail.tadResponse.drugIndications)){
                                healthArray=angular.copy(response.response.detail.tadResponse.drugIndications);
                            }else{
                                healthArray.push(angular.copy(response.response.detail.tadResponse.drugIndications));
                            }

                            var defaultIndPresent=false;
                            angular.forEach(healthArray, function (health, index) {
                                if (health["default"] == "true") {
                                    defaultIndPresent=true;
                                    //$scope.costResultDataModel.tad.tadRad = healthArray[index].description;
                                    //$scope.costResultDataModel.tad.tadRadInd=healthArray[index].indicationId;
                                }
                            });
                            if(!defaultIndPresent){
                                var drugIndications =
                                    {
                                        "crossClass": "false",
                                        "phase": {
                                            "_xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
                                            "_xsi:nil": "true"
                                        },
                                        "default": "true",
                                        "description": "Other Reasons",
                                        "indicationId": "other"
                                    };
                                healthArray.push(angular.copy(drugIndications));
                             }
                            $scope.costResultDataModel.tad.tadRadio = healthArray;
                            $scope.costResultDataModel.tad.tadVisibility.tadExpanded = true;
                            $scope.firstClick=false;
                            currentDrugSearchInput.tad=angular.copy($scope.costResultDataModel.tad);
                            drugCostHelper.setSessionData(currentDrugSearchInput);
                        }else{
                            $scope.costResultDataModel.tad.tadVisibility.error=true;
                        }
                    }, function (error) {
                        $scope.costResultDataModel.tad.tadVisibility.error=true;
                    });

                }
            } else {
                $scope.pastCostResultDataModel;
                if(!$scope.pastCostResultDataModel.tad){
                    $scope.pastCostResultDataModel.tad={
                        tadVisibility :{
                            error: false,
                            tadExpanded: false,
                            tadList: false,
                            alternatives: true,
                            tadMain:true
                        }
                    };
                }
                $scope.pastCostResultDataModel.tad.tadVisibility.tadExpanded = true;

                    req.ndcId=request.retailDrug && request.retailDrug.ndcId;
                    drugCostHelper.getDrugIndicationsByNDCId(req).then(function (response) {
                        if(response.response.header.statusCode ==="0000"&& response.response.detail && response.response.detail.tadResponse&& response.response.detail.tadResponse.drugIndications){
                            var healthArray=[];
                            if(Array.isArray(response.response.detail.tadResponse.drugIndications)){
                                healthArray=angular.copy(response.response.detail.tadResponse.drugIndications);
                            }else{
                                healthArray.push(angular.copy(response.response.detail.tadResponse.drugIndications))
                            }
                            var defaultIndPresent=false;

                            angular.forEach(healthArray, function (health, index) {
                                if (health["default"] == "true") {
                                    defaultIndPresent=true;
                                    //$scope.pastCostResultDataModel.tad.tadRad = healthArray[index].description;
                                }
                            });
                            if(!defaultIndPresent){
                                var drugIndications =
                                {
                                    "crossClass": "false",
                                    "phase": {
                                        "_xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
                                        "_xsi:nil": "true"
                                    },
                                    "default": "true",
                                    "description": "Other Reasons",
                                    "indicationId": "other"
                                };
                                healthArray.push(angular.copy(drugIndications));
                            }
                            $scope.pastCostResultDataModel.tad.tadRadio=[];
                            $scope.pastCostResultDataModel.tad.tadRadio = healthArray;
                            if(index !=undefined){
                                $scope.pastSearchData.generic[index].tad=angular.copy($scope.pastCostResultDataModel.tad);
                            }
                        }else{
                            $scope.pastCostResultDataModel.tad.tadVisibility.error=true;
                        }

                    }, function (error) {
                        if (request.state === 'current') {
                            $scope.costResultDataModel.tad.tadVisibility.error=true;
                        }else{
                            $scope.pastCostResultDataModel.tad.tadVisibility.error=true;
                        }
                    });
                }


        };
       /* /!**
         * TODO
         *!/
        $scope.editTadHealthOptions = function() {
            $scope.tadVisibility.tadList = false;
            $scope.tadVisibility.tadExpanded = true;
            $scope.tadVisibility.alternatives = true;
        };*/
        /**
         * TODO
         * @param usedVar
         * @returns {*}
         */
        var setTadValues = function(usedVar) {
            usedVar.tad = {
                "tadVisibility": $scope.tadVisibility,
                "tadRadio": $scope.tadRadio,
                "tadRad": $scope.tadRad
            };
            return usedVar;
        };
        /**
         * TODO
         */
        var resetTADVisibilityToInitial = function() {
            if(!$scope.costResultDataModel.tad){
                $scope.costResultDataModel.tad={};
            }
            $scope.costResultDataModel.tad.tadVisibility = {
                tadMain: true,
                tadExpanded: false,
                tadList: false,
                alternatives: true
            };
            $scope.costResultDataModel.tad.tadRadio = undefined;
            $scope.costResultDataModel.tad.tadRad = undefined;
        };
        /**
         * TODO
         * @param drugDetails
         */
        var resetTADVisibility = function(drugDetails) {

            if (drugDetails.tad.tadRad && drugDetails.tad.tadVisibility.alternatives) {
                $scope.tadRadio = drugDetails.tad.tadRadio;
                $scope.tadRad = drugDetails.tad.tadRad;
            } else if (drugDetails.tad.tadRad && !drugDetails.tad.tadVisibility.alternatives) {
                $scope.tadRadio = drugDetails.tad.tadRadio;
                $scope.tadRad = drugDetails.tad.tadRad;
                $scope.checkAlternatives();
                $scope.tadVisibility.tadExpanded = false;

            } else {
                resetTADVisibilityToInitial();
            }
        };
        /**
         * Viewing help pop-up when help icon is clicked
         */
        $scope.showHelpPopUP = function() {

            var modalProperties =
            {

                templateUrl: 'modules/searchresult/views/help-popup.html',
                size: 'custom',
                data: ''
            };
            CoreCommonsModal.helpPopPreview(modalProperties);
        };

        /**
         * Edit Search Criteria -Start
         */

        var updateSearchCriteria = function (data,pastSearchIndex) {
            if (data) {
                pastSearchIndex=$scope.selectedIndex;
                $scope.pastSearchData.generic[pastSearchIndex] = angular.extend($scope.pastSearchData.generic[pastSearchIndex],data);
                $scope.pastSearchData.generic[pastSearchIndex].tad.tadVisibility={ error: false,
                    tadExpanded: false,
                    tadList: false,
                    alternatives: true,
                    tadMain:true};
                drugCostHelper.setSessionData($scope.pastSearchData, true);
                $scope.expandDrugList($scope.pastSearchData.generic[pastSearchIndex], pastSearchIndex);
            }
            else {
                $scope.tadVisibility = {
                    error: false,
                    tadExpanded: false,
                    tadList: false,
                    alternatives: true,
                    tadMain:true
                };
                currentDrugSearchInput.tad=undefined;
                getCurrentDrugCost();
            }
        };

        $scope.editSearchCriteria = function (userInfoEdit, pastSearchIndex) {
            var modalProperties = {
                "callback": updateSearchCriteria,
                "templateUrl": 'modules/drugsearch/views/drug-search.html',
                "windowClass": "editSearchModal",
                "size": "full",
                "data": {
                    "editCriteriaData": {
                        "userInfoEdit": userInfoEdit,
                        "pastSearchIndex": pastSearchIndex
                    }
                },
                "backdrop": 'static'
            };
            CoreCommonsModal.generalModal(modalProperties);
        };

        /**
         *  Edit Search Criteria -End
         */
        //WebAnalytics code do not remove
        if (typeof($scope.wtEventHandler) !== 'function') {
            $scope.wtEventHandler = function (key) {
//                webAnalytics.wtEvent(key);
                $scope.$emit('TealiumWebAnalytic', {"key":key});
            };
        }

        function costDetailForMobile(response) {
            var responsedata = costResultDataServices.formDataModel(response, "generic");

            for (var i in responsedata.drugDetails) {
                if (!isNaN(parseInt(i))) {
                    if (responsedata.drugDetails[i].name.drugType == "brand") {
                        responsedata.drugDetails[i].name.drugType = $scope.FastContentService.searchResults.cost.label.brand;
                        //responsedata.drugDetails[i].name.heading = "You Searched For:";
                    }
                    else responsedata.drugDetails[i].name.drugType = $scope.FastContentService.searchResults.cost.label.generic;
                }
            }

            $scope.mobileData = responsedata;
            $scope.mobileData.bestValue = response.best;
            $scope.mobileData.bestValue.bestValueSource = "current";
            $scope.mobileData.resultFlag = true;


            //expanding first index cost details by default
            /*if($scope.mobileData.drugDetails[0]) {
                var costBreakDown='';
                for(var c in $scope.mobileData.drugDetails[0].items) {
                    if(c.cost && c.dosage) {
                            costBreakDown = {
                            drugDetails: c,
                            dosageDetail: c.dosage,
                            costDetail: c.cost
                        };
                        break;
                    }
                }
                if (costBreakDown.costDetail) {
                    costBreakDown.costDetail.drugCostType = "mail";
                    $scope.viewCostDetails(costBreakDown);
                }*/
            }

        var makeTADCurrentState=function(resultSet){
            $scope.pastCostResultDataModel.tad={};
           $scope.pastCostResultDataModel.tad.tadVisibility={
               error: false,
                   tadExpanded: false,
                   tadList: false,
                   alternatives: true,
                   tadMain:true
           };
            $scope.pastCostResultDataModel.tad.tadRadio=undefined;
            if(resultSet.tad.tadVisibility.tadExpanded){
                $scope.pastCostResultDataModel.tad.tadVisibility.tadExpanded=true;
                $scope.tadExpand($scope.pastCostResultDataModel);
            }
            if(resultSet.tad.tadVisibility.tadList){
                $scope.pastCostResultDataModel.tad.tadRad=angular.copy(resultSet.tad.tadRad);
                $scope.pastCostResultDataModel.tad.tadRadInd=angular.copy(resultSet.tad.tadRadInd);
                $scope.pastCostResultDataModel.tad.tadVisibility.tadList=true;
                $scope.pastCostResultDataModel.tad.tadVisibility.alternatives = false;
                $scope.pastCostResultDataModel.tad.tadpriceList=angular.copy(resultSet.tad.tadpriceList);
            }
         }

        function checkDosageDayForMail(drugDetails){
            return (drugDetails.dosageSelected && drugDetails.dosageSelected.isCustom
                && drugDetails.dosageSelected.options && drugDetails.dosageSelected.options.days && parseInt(drugDetails.dosageSelected.options.days)<16)
        };


        function hasPriceMailRetail(response , priceType){
            return ((response && response.brand && response.brand[priceType])|| (response && response.generic && response.generic[priceType]));
        };
        function hasMailLessError(drugDetails){
            var isMailLessError=false;
            drugDetails.isMail= drugSearchHelper.isMailOrRetail(drugDetails, "mailDrug");
            drugDetails.isMailLessError=false;

            if(drugDetails.isMail && checkDosageDayForMail(drugDetails)){
                isMailLessError=true;
                drugDetails.isMail= false;
            }
            return isMailLessError;
        }

        function setCostModalPriceType(response,costResultDataModel){
            // check retail
            if(hasPriceMailRetail(response,'retailPrice')){
                costResultDataModel.isRetail= true;
            }
            else{
                costResultDataModel.isRetail= false;
            }

            // check mail
            if(hasPriceMailRetail(response,'mailPrice')){
                costResultDataModel.isMail= true;
            }else{
                costResultDataModel.isMail= false;
            }
        }

       $scope.tadCollapse =function(resultSet,pastSearchIndex){
           if (resultSet.state === 'current') {
               $scope.costResultDataModel.tad.tadVisibility.tadExpanded=false;
           }else{
               $scope.pastCostResultDataModel.tad.tadVisibility.tadExpanded=false;
               $scope.pastSearchData.generic[pastSearchIndex].tad=angular.copy($scope.pastCostResultDataModel.tad);
           }

        };

        $scope.editTadHealthOptions =function(resultSet,pastSearchIndex){
            if (resultSet.state === 'current') {
                $scope.costResultDataModel.tad.tadVisibility.tadList =false;
                $scope.costResultDataModel.tadExpanded =true;
                $scope.costResultDataModel.tad.tadVisibility.alternatives =true;
            }else{
                $scope.pastCostResultDataModel.tad.tadVisibility.tadList =false;
                $scope.pastCostResultDataModel.tadExpanded =true;
                $scope.pastCostResultDataModel.tad.tadVisibility.alternatives =true;
                $scope.pastSearchData.generic[pastSearchIndex].tad=angular.copy($scope.pastCostResultDataModel.tad);
            }

        };
    }
]);