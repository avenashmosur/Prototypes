/**
 * Created by 486485 on 5/23/2015.
 */

checkDrugCostDirectives
    .directive('searchResultWebTemplate', function(drugCostHelper,CoreCommonsModal) {
        return {
            restrict: 'A',
            scope: {
                "responseData": "=",
                "fastContentService" : "=",
                viewcostbreakdown: "&",
                gsmalchemy:"&",
                "displayError":"@"
            },
            templateUrl:'modules/searchresult/views/searchResultWebTemplate.html',
            link: function($scope, element, attrs) {
                $scope.myValue = true;
                $scope.viewCostDetailsPopup = function (drugDetails,dosageDetail,costDetail,costType) {

                   if(costDetail.Price && costDetail.Price && costDetail.Price.costToday !="N/A") {
//                  WebAnalytics code do not remove
                    if (drugDetails.drugType.trim().toLowerCase().indexOf("generic") >= 0 && parseInt(dosageDetail.DosageSupply) == 30) {
                        $scope.$emit('TealiumWebAnalytic', {"key":"30dcvsg"});
                    } else if (drugDetails.drugType.trim().toLowerCase().indexOf("brand") >= 0 && parseInt(dosageDetail.DosageSupply) == 30) {
                        $scope.$emit('TealiumWebAnalytic', {"key":"30dcvsb"});
                    } else if (drugDetails.drugType.trim().toLowerCase().indexOf("generic") >= 0 && parseInt(dosageDetail.DosageSupply) == 90) {
                        $scope.$emit('TealiumWebAnalytic', {"key":"90dcvsg"});
                    } else if (drugDetails.drugType.trim().toLowerCase().indexOf("brand") >= 0 && parseInt(dosageDetail.DosageSupply) == 90) {
                        $scope.$emit('TealiumWebAnalytic', {"key":"90dcvsb"});
                    }
//                  WebAnalytics code do not remove
                       var costBreakDown={drugDetails:drugDetails,dosageDetail:dosageDetail,costDetail:costDetail};
                       if(costBreakDown.costDetail) {
                           costBreakDown.costDetail.drugCostType = costType;
                       }
                       $scope.viewcostbreakdown(costBreakDown);

                       $scope.loadGSM = function(){$scope.gsmalchemy();};
                   }

                    //CoreCommonsModalSrv.openModal.newDrugSearch();
                    //scope.openDrugSearch = true;

                };
                /**
                 * Loading GSM Alchemy Pop-up
                 * @param req
                 */
                $scope.loadGSMAlchemyPopUp = function(req) {

                    drugCostHelper.getGSMAlchemy(req).then(gsmSuccess, gsmError);
                };
                /**
                 * passing the 0bject for which GSM Alchemy is to be loaded
                 * @param obj
                 */
                function loadGSMAlchemy(obj)
                {
                    var modalProperties =
                    {

                        templateUrl: 'modules/searchresult/views/gsmalchemy.html',
                        size:'medium',
                        data:obj
                    };
                    CoreCommonsModal.gsmAlchemyPopPreview(modalProperties);
                }

                /**
                 * If GSM Alchemy call is successfull
                 * @param data
                 */
                function gsmSuccess(data)
                {
                    if(data && data.response && data.response.detail ){
                        var resp = data.response.detail;//data.GSMAlchemyResponse; //.ContentPatientEducation
                        var obj ={};
                        obj.contentPatientEducation=resp.ContentPatientEducation;
                        obj.listProducts=resp.ListProducts;
                        if(resp.ListProductImages && resp.ListProductImages.ProductImage && resp.ListProductImages.ProductImage.ImageType){
                            if(resp.ListProductImages.ProductImage.ImageType==='drug_item'){
                                obj.imageUrl="/portal/images/gsm/DrugItem_"+resp.ListProductImages.ProductImage.ImageId+".JPG";
                            }else if(resp.ListProductImages.ProductImage.ImageType==='package'){
                                obj.imageUrl="/portal/images/gsm/AlchemyPackage_"+resp.ListProductImages.ProductImage.ImageId+".JPG";
                            }else{
                                obj.imageUrl="";
                            }
                        }
                        obj.drugName=data.requestDrugName && data.requestDrugName.__cdata ? data.requestDrugName.__cdata.toUpperCase():obj.contentPatientEducation.SheetName;
                        loadGSMAlchemy(obj);

                        return;
                    }else{
                        var obj={
                            "error":true,
                            "errorMessage":$scope.fastContentService.common.service_unavailable
                        };
                        loadGSMAlchemy(obj);
                        return;
                    }

                }

                /**
                 * If GSM Alchemy call fails and throws error
                 * @param data
                 */
                function gsmError(data)
                {

                    if(data.response.header.statusCode === '2001')
                        updateErrorMessage(errors.getErrorMessage('009'));
                    else
                        updateErrorMessage(errors.getErrorMessage('008'));
                    loadGSMAlchemy({});
                    return;
                }
            }
        };
    });
