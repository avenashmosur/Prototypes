/**
 * Created by 478789 on 6/10/2015.
 */

checkDrugCostDirectives
    .directive('editSearch', function (help) {
        return {
            restrict: 'A',
            scope: {
                "currentDrugSearchInput": "=",
                fastContentService: "=",
                wtEventHandler: "&",
                editSearchCriteria: "&"

            },
            templateUrl: 'modules/searchresult/views/edit-search.html',
            link: function(scope, element, attrs) {
                scope.printStateOn=help.printStateOn;


            }
        };
    });