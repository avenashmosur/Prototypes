/**
 * Created by Z179603 on 5/28/2015.
 */
checkDrugCostDirectives
    .directive('addPharm', ['help','activeModel',function(help,activeModel) {
        return {
            restrict: 'AE',
            templateUrl: 'modules/searchresult/views/additional-pharmacies.html',
            scope: {
                isShow:'=',
                results: '=',
                costResultDataModel: '=',
                responseData: '=',
                fastContentService: "=content",
                pharloc:"&",
                hideErrorMessage:"&",
                gsmalchemy:"&",
                viewcostbreakdown: "&",
                modifyBestValueIndicator: "&"
            },
            link: function ($scope, element, attrs) {
                /*$scope.results=$scope.results;
                $scope.responseData=$scope.results;
                $scope.costResultDataModel=$scope.results;*/
                $scope.help=help;
                $scope.activeModel=activeModel;
                $scope.pharmacyLoc=function(){
                    $scope.hideErrorMessage();
                    $scope.pharloc($scope.results,'add');
                    /*$scope.costResultDataModel=$scope.results;*/
                };
                $scope.removeAdditionalPharmacies = function(additionalPhar) {
                    var sessionResultDataModel=null;
                    var sessionStoredData=null;

                    //deleting additional pharmacy from current scope object
                    angular.forEach($scope.costResultDataModel.additionalPharmacies, function(eachResponseArray, key) {
                        if (additionalPhar.pharmacy.pharmacyNumber === eachResponseArray.pharmacy.pharmacyNumber) {
                            $scope.costResultDataModel.additionalPharmacies.splice(key, 1);
                            $scope.costResultDataModel.additionPharmacyLimitError = false;
                            $scope.results=$scope.costResultDataModel;
                            $scope.hideErrorMessage();
                        }
                    });

                    ///deleting additonal pharmacy from session
                    if (typeof(Storage) !== "undefined") {
                        sessionStoredData = help.getSessionStorage(activeModel.tokenId);
                        if(sessionStoredData) {
                            if ($scope.costResultDataModel.state == "current" && sessionStoredData['currentSearch']) {
                                sessionResultDataModel =sessionStoredData['currentSearch'];
                                angular.forEach(sessionResultDataModel.additionalPharmacies, function(eachResponseArray, key) {
                                    if (additionalPhar.pharmacy.pharmacyNumber === eachResponseArray.pharmacyNumber) {
                                        sessionResultDataModel.additionalPharmacies.splice(key, 1);
                                    }
                                });
                                sessionStoredData['currentSearch']=sessionResultDataModel;
                                help.setSessionStorage(activeModel.tokenId, sessionStoredData);
                            }
                            else if ($scope.costResultDataModel.state == "past" && sessionStoredData['pastSearch']) {
                                sessionResultDataModel =sessionStoredData['pastSearch'];
                                angular.forEach(sessionResultDataModel.generic, function (eachGeneric, genericKey) {
                                    if(angular.uppercase(eachGeneric.drugName)==angular.uppercase($scope.costResultDataModel.drugDetails.displayText)) {
                                        angular.forEach(eachGeneric.additionalPharmacies, function (eachResponseArray, key) {
                                            if (additionalPhar.pharmacy.pharmacyNumber === eachResponseArray.pharmacyNumber) {
                                                sessionResultDataModel.generic[genericKey].additionalPharmacies.splice(key, 1);
                                            }
                                        });
                                    }
                                });
                                sessionStoredData['pastSearch']=sessionResultDataModel;
                                help.setSessionStorage(activeModel.tokenId, sessionStoredData);
                            }
                        }
                    }

                    $scope.modifyBestValueIndicator($scope.costResultDataModel);
                };
                $scope.viewCostDetailsPopup = function (drugDetails,dosageDetail,costDetail,costType) {
                    if(costDetail.PricetotalObject.integer>=0) {

                        var costBreakDown={drugDetails:drugDetails,dosageDetail:dosageDetail,costDetail:costDetail};
                        if(costBreakDown.costDetail) {
                            costBreakDown.costDetail.drugCostType = costType;
                        }
                        $scope.viewcostbreakdown(costBreakDown);

//                  WebAnalytics code do not remove
                    if (drugDetails.drugType.trim().toLowerCase().indexOf("generic") >= 0 && dosageDetail.DosageSupply.trim() == "30") {
                        $scope.$emit('TealiumWebAnalytic', {"key":"30dotherg"});
                    } else if (drugDetails.drugType.trim().toLowerCase().indexOf("brand") >= 0 && dosageDetail.DosageSupply.trim() == "30") {
                        $scope.$emit('TealiumWebAnalytic', {"key":"30dotherb"});
                    }
//                  WebAnalytics code do not remove
                    
                    //$scope.viewcostbreakdown({drugDetails:drugDetails,dosageDetail:dosageDetail,costDetail:costDetail});
                    }
                    //$scope.loadGSM = function(){$scope.gsmalchemy();};
                    //CoreCommonsModalSrv.openModal.newDrugSearch();
                    //scope.openDrugSearch = true;
                };



            }
        }
    }]);
