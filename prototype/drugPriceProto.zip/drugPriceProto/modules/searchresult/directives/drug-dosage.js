/**
 * Created by 486485 on 5/23/2015.
 */

checkDrugCostDirectives
    .directive('drugDosage', ['help',function(help) {
        return {
            restrict: 'A',
            scope:true,
            templateUrl:'modules/searchresult/views/drugDosage.html',
            link: function(scope, element, attrs) {
                scope.printStateOn=help.printStateOn;
                scope.pharmacyLocator=function(state){
                    scope.$emit('changeAdditonalPharmacy', { message: state });
                }

            }
        };
    }]);
