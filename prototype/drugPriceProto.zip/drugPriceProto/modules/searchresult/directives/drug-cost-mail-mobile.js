/**
 * Created by 486485 on 5/23/2015.
 */

checkDrugCostDirectives
    .directive('drugCostMailMobile', function() {
        return {
            restrict: 'A',
            scope:true,
            /*  scope: {

             viewcostdropdownmail: "&",
             viewcostdropdownretail: "&"

             },*/
            templateUrl:'modules/searchresult/views/drugCostMailMobile.html',
            link: function($scope, element, attrs) {

                $scope.viewCostDetailsPopup = function (drugDetails,dosageDetail,costDetail,costType,costDetailId,expandIconId) {
                    var isCostAvail=false;
                    if(costType==="mail") {
                        if (typeof costDetail.PricetotalObject.integer!=="undefined" && costDetail.PricetotalObject.integer >= 0) {
                            isCostAvail=true;
                        }
                    }
                    else if(costType==="retail"){
                        if(typeof costDetail.Price.copayEmployerObject.integer!=="undefined" && costDetail.Price.copayEmployerObject.integer >=0){
                            isCostAvail=true;
                        }
                    }

                    if(isCostAvail){

                        //var toggleElemObj=$(cssSelector);
                        $scope.$emit('viewCostDetailsPop', {
                            message: {
                                drugDetails: drugDetails,
                                dosageDetail: dosageDetail,
                                costDetail: costDetail,
                                costType: costType
                            }
                        });

                        $(".mailCostBreakdown,.retailCostBreakdown").each( function( index, detailItem ) {
                            if (costDetailId && $(detailItem)[0].id==costDetailId) {
                                $('#'+costDetailId).toggle();
                            }
                            else{
                                $(detailItem).hide();
                            }
                        });

                        $(".toggle_drug_details_collapse,.toggle_drug_details_expand").each( function( index, arrowButton ) {
                            if (expandIconId && $(arrowButton)[0].id==expandIconId) {
                                $('#'+expandIconId).toggleClass("toggle_drug_details_collapse");
                            }
                            else{
                                $(arrowButton).addClass("toggle_drug_details_expand").removeClass("toggle_drug_details_collapse");
                            }
                        });
                    }
                };



                $scope.$on('ModalDataPop',function (event, args) {

                    $scope.modalData = args;
                });

            }
        };
    });




