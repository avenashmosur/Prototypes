/**
 * Created by 486485 on 5/23/2015.
 */

checkDrugCostDirectives
    .directive('drugCostRetail', function(help) {
        return {
            restrict: 'AE',
            templateUrl:'modules/searchresult/views/drugCostRetail.html',
            link: function(scope, element, attrs) {
                scope.printStateOn=help.printStateOn;
            }
        };
    });
