/**
 * Created by 486485 on 5/23/2015.
 */

checkDrugCostDirectives
    .directive('drugName', ['help',function(help) {
        return {
            restrict: 'A',
            scope:true,
            transclude:true,
            templateUrl:'modules/searchresult/views/drugNameHeading.html',
            link: function(scope, element, attrs) {
                scope.printStateOn=help.printStateOn;


            }
        };
    }]);
