/**
 * Created by Z179603 on 4/14/2015.
 */

checkDrugCostDirectives
.directive('pie', function() {
        return {
            restrict: 'A',
            scope: {
                percentage: '=percentage',
                chk :'@'
            },
            template: '<canvas id="piechart" width="20" height="20" style="margin-top: 10px; border: 2px solid; border-radius: 50%"></canvas>',
            replace: true,
            link: function(scope, element, attrs) {

                var per=parseFloat(scope.percentage);
                if(!per){
                    per=0;
                }
                var displayData = per * 3.6;
                var data = [];
               /* data.push(displayData);data.push(360-displayData);*/
                data.push(360);data.push(displayData);
                //var colors = [ "#CECACF","#555555"];
                var colors = [ "#FFFFFF","#555555"];
                function drawSegment(canvas, context, i) {
                    context.save();
                    var centerX = Math.floor(canvas.width / 2);
                    var centerY = Math.floor(canvas.height / 2);
                    radius = Math.floor(canvas.width / 2);

                    var startingAngle = 4.71238898038469;
                        //degreesToRadians(sumTo(data, i));
                    var arcSize = degreesToRadians(data[i]);
                    var endingAngle = startingAngle + arcSize;

                    context.beginPath();
                    context.moveTo(centerX, centerY);
                    context.arc(centerX, centerY, radius,
                        startingAngle, endingAngle, false);
                    context.closePath();

                    context.fillStyle = colors[i];
                    context.fill();

                    context.restore();

                    //drawSegmentLabel(canvas, context, i);
                }


                function degreesToRadians(degrees) {
                    return (degrees * Math.PI)/180;
                }
                function sumTo(a, i) {
                    var sum = 0;
                    for (var j = 0; j < i; j++) {
                        sum += a[j];
                    }
                    return sum;
                }

                /*function drawSegmentLabel(canvas, context, i) {
                    context.save();
                    var x = Math.floor(canvas.width / 2);
                    var y = Math.floor(canvas.height / 2);
                    var angle = degreesToRadians(sumTo(data, i));

                    context.translate(x, y);
                    context.rotate(angle);
                    var dx = Math.floor(canvas.width * 0.5) - 10;
                    var dy = Math.floor(canvas.height * 0.05);

                    context.textAlign = "right";
                    var fontSize = Math.floor(canvas.height / 25);
                    context.font = fontSize + "pt Helvetica";

                    context.fillText(labels[i], dx, dy);

                    context.restore();
                }*/


                    var canvas = document.getElementById('piechart');
                    if(canvas){
                        var context = canvas.getContext("2d");

                        for (var i = 0; i < data.length; i++) {
                            drawSegment(canvas, context, i);
                        }
                        canvas.id = scope.chk;
                    }
            }
        };
    });
