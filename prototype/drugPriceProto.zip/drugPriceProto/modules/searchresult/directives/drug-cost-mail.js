/**
 * Created by 486485 on 5/23/2015.
 */
(function () {
    checkDrugCostDirectives.directive('drugCostMail', drugCostMail);

    drugCostMail.$inject = ['activeModel', 'help','errors'];

    function drugCostMail(activeModel, help,errors) {
        return {
            restrict: 'A',
            templateUrl: 'modules/searchresult/views/drugCostMail.html',
            link: function (scope) {
                scope.isAdded = false;
                scope.printStateOn = help.printStateOn;
                scope.cartError='';
                
                var appCartState = activeModel.portalJson.APP_CART_STATE_DATA;
                var appParamData = activeModel.portalJson.APP_PARAM_DATA;

                function checkIfAdded() {
                    if (appCartState && appCartState['Cart_State']) {
                        var cartState = appCartState['Cart_State'];
                        if (cartState && scope.drugCostMail && scope.drugCostMail.Price && scope.drugCostMail.Price.ndcId &&
                             scope.drugDetail && scope.drugDetail.drugDetailForCart && scope.drugDetail.drugDetailForCart.memberId
                            && cartState[scope.drugDetail.drugDetailForCart.memberId]) {
                            angular.forEach(cartState[scope.drugDetail.drugDetailForCart.memberId], function (val) {
                                if (val == scope.drugCostMail.Price.ndcId) {
                                    scope.isAdded = true;
                                }
                            })
                        }
                    }
                }

                checkIfAdded();

                scope.viewOrder = function () {
                    if (appParamData && appParamData["CartUrl"]) {
                        //temporary fix to redirect to Portal Cart
                        var cartUrl = appParamData["CartUrl"].replace('/portal/', '/myportal/');
                        cartUrl = cartUrl.replace('http://', 'https://');
                        window.parent.location.href = cartUrl;
                    }
                };

                scope.reqNewPrescription = function (drugDetails, costDetails,btnId) {
                    scope.cartError='';
                    help.popOverHandler('.request_red_btn', 'hide');
                    //WebAnalytics code : Do not Delete
                    scope.$emit('TealiumWebAnalytic', {"key": "NEWRX"});
                    scope.addToCart = true;
                    var addToCartResponse = function (data) {
                        scope.$apply(function () {
                            scope.addToCart = false;
                            if (data) {
                                scope.isAdded = true;
                                if (appCartState && appCartState['Cart_State']) {
                                    var cartState = appCartState['Cart_State'];
                                    if (cartState && scope.drugCostMail.Price.ndcId) {
                                        cartState[activeModel.memberSelect.internalID] = [];
                                        cartState[activeModel.memberSelect.internalID].push(scope.drugCostMail.Price.ndcId);
                                    }
                                }
                            }else{
                                scope.cartError = errors.getErrorMessage(500);
                                help.popOverHandler('#addBtn'+btnId, 'show');
                            }
                        });
                    };

                    angular.element(document).trigger({
                        type: 'ADD_TO_CART',
                        "costFrom": "mail",
                        "drugItemSelect": {
                            "drugForm": drugDetails.drugForm.__cdata,
                            "drugName": drugDetails.drugName.__cdata,
                            "drugStrength": drugDetails.drugStrength.__cdata,
                            "mailDrug": drugDetails.drugDetailForCart
                        },
                        "drugDetail": {
                            "costToday": costDetails.Price.costToday
                        },
                        "selectedParticipant": activeModel.memberSelect.internalID,
                        "callBack": addToCartResponse
                    });


                }
            }
        };
    }
})();

