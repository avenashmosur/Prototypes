
checkDrugCostDirectives
    .directive('drugCostBreakdown', function() {
        return {
            restrict: 'AE',
            templateUrl:'modules/searchresult/views/viewCost-popup.html',
            link: function(scope, element, attrs) {

            }
        };
    });
