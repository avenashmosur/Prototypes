/**
 * Created by Z179603 on 5/27/2015.
 */
checkDrugCostDirectives
    .directive('tad', function() {
        return {
            restrict: 'AE',
            templateUrl:'modules/searchresult/views/tad.html',
            scope:{
                results: '=',
                FastContentService:"=content",
                tadExpand: "&",
                checkAlternatives:"&",
                ind:"=ind",
                userName:"=",
                tadCollapse:"&",
                editTadHealthOptions:"&"

            },
            link: function($scope, element, attrs) {
                $scope.$emit('clickTad',[true]);
                 $scope.$watch('results', function (results) {
                    $scope.tad=$scope.results.tad;
                    $scope.results=$scope.results;

                });
                $scope.tad=$scope.results.tad;
                if($scope.results.tad){
                    $scope.tad.tadVisibility=$scope.results.tad.tadVisibility;
                }
                $scope.tadPharmacy=$scope.results && $scope.results.pharmacy;
                $scope.tadExpands= function(){
                    $scope.tad=$scope.results.tad;
                     $scope.tadExpand($scope.results,$scope.ind);
                    $scope.tadPharmacy=$scope.results && $scope.results.pharmacy;

                };
                $scope.tadRadioCheck =function(tad){
                    $scope.tad.tadRad=tad.description;
                    $scope.tad.tadRadInd=tad.indicationId;
                };

                $scope.loadGSMAlchemyPopUp=function(tad){
                    $scope.$parent.loadGSMAlchemyPopUp(tad);
                };


                $scope.checkAlternative= function(){
                    $scope.checkAlternatives($scope.results,$scope.ind,$scope.userName,$scope.results.pharmacy);
                };
                $scope.tadCollapsed =function(){
                    $scope.tadCollapse($scope.results,$scope.ind);
                   /* $scope.tad.tadVisibility.tadExpanded=false;*/
                };

                $scope.editTadHealthOption =function(){
                    $scope.editTadHealthOptions($scope.results,$scope.ind);
                   /* $scope.tad.tadVisibility.tadList =false;
                    $scope.tad.tadVisibility.tadExpanded =true;
                    $scope.tad.tadVisibility.alternatives =true;*/
                };

            }
        };
    });
