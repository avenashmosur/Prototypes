checkDrugCostDirectives.directive('loading', function () {

    return {
        restrict: 'A',
        replace:true,
        scope:false,
        //template: '<div ><img src="http://www.nasa.gov/multimedia/videogallery/ajax-loader.gif" width="20" height="20" />LOADING...</div>',
        template:'<i id="spinner" class="loading-spinner glyphicon glyphicon-refresh"></i>',
        link: function (scope, element, attr) {

            //console.log('in directive');
            scope.$on("loader_show",function()
            {

                scope.loadingStatus = true;
            });
            scope.$on("loader_hide",function()
            {

                scope.loadingStatus = false;
            });

           /* scope.$watch('loadingStatus', function (val) {
                //console.log('in loading watch : ' +val);
                if (val)
                    scope.loadingStatus = true;
                else
                    scope.loadingStatus = false;
            }); */
        }

    }
});