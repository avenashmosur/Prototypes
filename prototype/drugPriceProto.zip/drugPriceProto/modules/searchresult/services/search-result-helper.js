/**
 * Created by Z179603 on 4/9/2015.
 */
checkDrugCostFactory.factory('drugCostHelper', ['activeModel', 'cdcServices', '$q','costResultDataService', '$rootScope','userSessionData','help',
    function(activeModel, cdcServices, $q,costResultDataService,$rootScope,userSessionData,helpService) {
    var help = {};

    Array.prototype.contains = function (searchedValue ) {
            for (i in this) {
                if (this[i] == searchedValue) return true;
            }
        return false;
    };
        /**
         * Price details of the drug
         * @param request
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
    var callPriceDetailsByDrug = function(request) {
        var requestData=angular.copy(request.param);
        delete requestData.data;
        var deferred = $q.defer();
        //cdcServices.getTADDrugPrice(requestData).then(//TODO for testing tad
        cdcServices.getDrugPrice(requestData).then(
            function(response) {
                if(response.response.header.statusCode ==='0000' && response.response.detail){
                    deferred.resolve(response);
                }else{
                    deferred.reject(response);
                }

            },
            function(error) {
                deferred.reject('Error');
                //console.log('error')
            }
        );
        return deferred.promise;
    };
        /**
         * Sending GSM Alchemy request
         * @param req
         * @returns {{}}
         * @constructor
         */
    var GSMAlchemyRequest = function(req){
        var ndcId=req.ndcId;
        var innerRequest={};
        var formatNDCIdForNDC9=function(ndcIdValue) {
            var strSize = ndcIdValue.length;
            var alteredNdcId = ndcIdValue.substring(0, ndcIdValue.length - 2);
            var s = "000000000" + alteredNdcId; // 9 zeros prepended
            return s.substring(s.length - strSize); // keep the leftmost 9 chars
        };


            /**
             *
             * @param ndcIdValue
             * @returns {string}
             */
        var formatNDCIdForNDCNotNine=function(ndcIdValue){
            var strSize = 11;
            var s = "00000000000" + ndcIdValue; // 9 zeros prepended
            return s.substring(s.length - strSize); // keep the rightmost 13 chars
        };
         if(ndcId.length == 9) {
            ndcId = formatNDCIdForNDC9(ndcId);
             innerRequest['Product'] = {
                 "IdentifierType":"NDC9",
                 "Identifier":ndcId
             };
         } else {
            ndcId = formatNDCIdForNDCNotNine(ndcId);
             innerRequest['Package'] = {
                 "IdentifierType":"NDC11",
                 "Identifier":ndcId
             };
         }
        var filter={
            "ProductNameFilter":req.drugName.__cdata+' ' +req.drugStrength.__cdata
        };
        var filterRequest={};
        filterRequest["Filter"]=filter;
        var GSMAlchemyRequest={
            "ContentPatientEducationRequest":{
                "LanguageCode":"en-US",
                "Identifier":innerRequest
                },
            "ListProductImagesRequest":{
                "AlchemyProductIdFlag":"True"
            },
            "ListProductsRequest":filterRequest
        };

        var formedRequest={};
        formedRequest['GSMAlchemyRequest'] = GSMAlchemyRequest;
        var request={};
        request.params={
            "operationName":"contentPatientEducation"
        };
        request.body=formedRequest;
        return request;

    };
        /**
         *
         * @param drugDetailsList
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
    var callDrugPricePromiseChaining = function(drugDetailsList) {
        /*Number of times a functions needs to call*/
        var deferred = $q.defer();
        var searchFunctionArray = [];
        angular.forEach(drugDetailsList, function(valueArray) {
            searchFunctionArray.push(callPriceDetailsByDrug(valueArray));
        });
        /*END*/

        /*
         * Combines multiple promises into a single promise
         * that will be resolved when all of the input promises are resolved
         */
        $q.all(searchFunctionArray).then(function(response) {
            // Success callback where value is an array containing the success values
           //deferred.resolve(response);
            if(response.length >1  && response[0].response.header.statusCode ==='0000' && response[0].response.detail && response[0].response.detail.costDetailsList && response[0].response.detail.costDetailsList.costDetails
                && response[1].response.header.statusCode ==='0000' && response[1].response.detail && response[1].response.detail.costDetailsList && response[1].response.detail.costDetailsList.costDetails
                && response[0].response.detail.costDetailsList.costDetails.length===response[1].response.detail.costDetailsList.costDetails.length){
                var finalResponse=angular.copy(response[0]);
                angular.forEach(response[1].response.detail.costDetailsList.costDetails,function(value,index){
                    if(value.retailPrice){
                        response[0].response.detail.costDetailsList.costDetails[index].retailPrice=angular.copy(value.retailPrice);
                    }
                });
                deferred.resolve(finalResponse);
            }else if(response.length == 1 && response[0].response.header.statusCode ==='0000' && response[0].response.detail && response[0].response.detail.costDetailsList && response[0].response.detail.costDetailsList.costDetails ){
                deferred.resolve(response[0]);
            }else{
                deferred.reject(response);
            }
        }, function(reason) {
            // Error callback where reason is the value of the first rejected promise
           deferred.reject('Error');
        });
        return deferred.promise;
    };
        /**
         * request to fetch price is created
         * @param reqArray
         * @returns {{doseForm: (*|Document.doseForm), drugName: *, brandName: *, ndcId: *, mailMostCommonlyDispensedQty: (*|formedRequest.drugDetails.mailDrug|{commonDaysSupply, commonDispensedQuantity, ndcId}), drugNDCID: *, memberID: (*|string|formedRequest.userName|{internalID, stCob}|string|string), pharmacyId: *, serviceName: string, operation: (*|string), tadRequest: (*|boolean)}}
         */
    var createPriceRequest = function(reqArray) {
        var request = {
            "doseForm": reqArray.doseForm,
            "drugName": reqArray.drugName,
            "brandName": reqArray.brandName,
            "ndcId": (reqArray.repDrug && reqArray.repDrug.ndcId),
            "mailMostCommonlyDispensedQty": reqArray.mailMostCommonlyDispensedQty || (reqArray.repDrug && reqArray.repDrug.mailDrug &&  reqArray.repDrug.mailDrug.mailMostCommonlyDispensedQty),
            "drugNDCID":reqArray.drugNDCID,
            "memberID":reqArray.memberID,
            "pharmacyId":reqArray.pharmacyId,
            "serviceName":"drugPrice",
            "operation":reqArray.operation,
            "tadRequest":reqArray.tadRequest
        };
        return request;
    };
        /**
         * Getting per day price
         * @param perUnitAnnual
         * @returns {Number}
         */
    var getPerDayPrice=function(perUnitAnnual){
       // var perunit= perUnitAnnual.replace('/day','');
        return parseFloat(perUnitAnnual);
    };
        /**
         * getting lowest price and its type from list of drugs
         * @param fromRequest
         * @param mailPrice
         * @param RetailPrice
         * @param data
         * @returns {{lowestPrice: *, lowestPriceType: *, showBestValue: boolean}}
         */
        var getLowestPriceAndType=function(fromRequest,mailPrice,RetailPrice,data,type,mailPriceCost,retailPriceCost){
            var lowestTmp,lowestPriceTypeTmp,bestValuePrice;
            var showBestValue= false;
            if(fromRequest==='additionalPharmacies' || !data.isMail){
                lowestTmp=RetailPrice;
                lowestPriceTypeTmp=type+"Retail";
                bestValuePrice=retailPriceCost;
                if(RetailPrice!=="N/A"/* && fromRequest!='additionalPharmacies'*/){
                    showBestValue=true;
                }
            }else if(!data.isRetail){
                lowestTmp=mailPrice;
                lowestPriceTypeTmp=type+"Mail";
                bestValuePrice=mailPriceCost;
                if(mailPrice && mailPrice!=="N/A"){
                    showBestValue=true;
                }
            }else{
                if(mailPrice && mailPrice==='N/A' && RetailPrice && RetailPrice=='N/A'){
                    lowestTmp="N/A";
                    lowestPriceTypeTmp="N/A";
                    showBestValue=false;
                    bestValuePrice="N/A";
                }else if(mailPrice && mailPrice==='N/A') {
                    lowestTmp=RetailPrice;
                    lowestPriceTypeTmp=type+"Retail";
                    bestValuePrice=retailPriceCost;
                    if(RetailPrice!=="N/A"){
                        showBestValue=true;
                    }
                }else if(RetailPrice && RetailPrice=='N/A'){
                    lowestTmp=mailPrice;
                    lowestPriceTypeTmp=type+"Mail";
                    bestValuePrice=mailPriceCost;
                    if(mailPrice!=="N/A"){
                        showBestValue=true;
                    }
                }else{
                    if(mailPrice!=undefined && RetailPrice!=undefined){
                        if(mailPrice === RetailPrice){
                            lowestTmp=RetailPrice;
                            lowestPriceTypeTmp=type+"Retail";
                            bestValuePrice=retailPriceCost;
                        }else if(Math.min(mailPrice,RetailPrice) ===mailPrice){
                            lowestTmp=mailPrice;
                            lowestPriceTypeTmp=type+"Mail";
                            bestValuePrice=mailPriceCost;
                            showBestValue=true;
                        }else{
                            lowestTmp=RetailPrice;
                            lowestPriceTypeTmp=type+"Retail";
                            bestValuePrice=retailPriceCost;
                            showBestValue=true;
                        }
                    }else{
                        if((mailPrice==undefined)){
                            lowestTmp=RetailPrice;
                            lowestPriceTypeTmp=type+"Retail";
                            bestValuePrice=retailPriceCost;
                            showBestValue=true;
                        }else{
                            lowestTmp=mailPrice;
                            lowestPriceTypeTmp=type+"Mail";
                            bestValuePrice=mailPriceCost;
                            showBestValue=true
                        }
                    }

                }

            }
            var returnValue ={
                lowestPrice:lowestTmp,
                lowestPriceType:lowestPriceTypeTmp,
                showBestValue:showBestValue,
                bestValuePrice:bestValuePrice
            };

            return returnValue;

        };

    var isNotEmptyNullNA=function(number){
        if(number!='' && number !='N/A' && number !='NaN'){
            return true;
        }else{
            false;
        }
      };

    var isNotZero =function(number){
       if(number && number!=="N/A" && number.trim()!=="" && parseFloat(number)==0){
           return false;
       }else{
           return true;
       }
    };
        /**
         *
         * @param response
         * @param request
         * @param fromRequest
         * @returns {{}}
         */
        help.formatDrugCostResponse = function(response, request, fromRequest) {
            //console.log(activeModel.portalJson);
            var drugCost = {};
            var bestValuesArray=[];
            drugCost.mailDosageSupply = request.data && request.data.mailDaysSupply || request.daysSupply || request.data &&
            request.data.daysSupply || (request.dosage.mailDrug && request.dosage.mailDrug.commonDaysSupply) || 0;
            drugCost.mailDosageQuantity = request.data && request.data.mailQuantity || request.quantity || request.data &&
            request.data.quantity || (request.dosage && request.dosage.mailDrug && request.dosage.mailDrug.commonDispensedQuantity) ||
            0;
            drugCost.retailDosageSupply = request.data && request.data.retailDaysSupply || request.daysSupply ||
            request.data && request.data.daysSupply || (request.dosage && request.dosage.retailDrug && request.dosage
                .retailDrug.commonDaysSupply) || 0;
            drugCost.retailDosageQuantity = request.data && request.data.retailQuantity || request.quantity ||
            request.data && request.data.quantity || (request.dosage && request.dosage.retailDrug && request.dosage
                .retailDrug.commonDispensedQuantity) || 0;
            drugCost.pharmacySelected = request.pharmacyId || request.pharmacySelected;
            drugCost.hasCommon = request.hasCommon || (request.drugDetails && request.drugDetails.dosageSelected &&
            request.drugDetails.dosageSelected.hasCommon) || false;
            drugCost.dataInd = angular.copy(request.data);
            drugCost.isStCob = request.data && request.data.isStCob ? true : false;
            var lowestPrice;
            var lowestPriceType;
            var showBestValue = false;
            var bestValuePrice;
            var multiPriceAvail=0;
            //To be redefined
            var responseArray = [];
            if (Array.isArray(response)) {
                responseArray = angular.copy(response);
            } else {
                responseArray.push(angular.copy(response))
            }
            var wt90Brand = false;
            var wt30Brand = false;
            var wt90Generic = false;
            var wt30Generic = false;
            var wtSettlementCode = "";
            drugCost.mail={};
            drugCost.retail={};

            if(((parseInt(drugCost.mailDosageSupply) % 30) == 0 && drugCost.mailDosageSupply != 0 && (parseInt(drugCost.mailDosageSupply) / 30) == 3)&&
                (parseInt(drugCost.retailDosageSupply) % 30) == 0 && drugCost.retailDosageSupply != 0 && (parseInt(drugCost.retailDosageSupply) / 30) == 1) {
                if ((parseInt(drugCost.mailDosageSupply) / 30) == 1) {
                    drugCost.mail.textpercent = false;
                    drugCost.mail.month_day = "month";


                } else {
                    drugCost.mail.textpercent = true;
                    drugCost.mail.month_day = "months";
                }
                drugCost.mail.mailMonths = parseInt(drugCost.mailDosageSupply) / 30;
            } else if (drugCost.mailDosageSupply != 0) {
                // drugCost.brand.dispmnthmail="for"+drugCost.mailDosageSupply;
                drugCost.mail.mailMonths = drugCost.mailDosageSupply;
                drugCost.mail.textpercent = false;
                if(parseInt(drugCost.mail.mailMonths)==1){
                    drugCost.mail.month_day = "day";
                }else{
                    drugCost.mail.month_day = "days";
                }

            } else {
                drugCost.mail.mailMonths = 0;
            }
            if (((parseInt(drugCost.mailDosageSupply) % 30) == 0 && drugCost.mailDosageSupply != 0 && (parseInt(drugCost.mailDosageSupply) / 30) == 3)&&
                (parseInt(drugCost.retailDosageSupply) % 30) == 0 && drugCost.retailDosageSupply != 0 && (parseInt(drugCost.retailDosageSupply) / 30) == 1) {
                if ((parseInt(drugCost.retailDosageSupply) / 30) == 1) {
                    drugCost.retail.textpercent = true;
                    drugCost.retail.month_day = "month";
                } else {
                    drugCost.retail.textpercent = true;
                    drugCost.retail.month_day = "months";
                }
                drugCost.retail.retailMonths = parseInt(drugCost.retailDosageSupply) / 30;
            } else if (drugCost.retailDosageSupply != 0) {
                // drugCost.brand.dispmnthmail="for"+drugCost.mailDosageSupply;
                drugCost.retail.retailMonths = drugCost.retailDosageSupply;
                drugCost.retail.textpercent = false;
                if (parseInt(drugCost.retailDosageSupply)===1){
                    drugCost.retail.month_day = "day";
                }else{
                    drugCost.retail.month_day = "days";
                }
            } else {
                drugCost.retail.retailMonths = 0;
            }
            angular.forEach(responseArray, function(value) {
                if (value.brand === 'true') {
                    drugCost.mailDosageQuantity = value.mailPrice && isNotEmptyNullNA(value.mailPrice.totalQuantity) ?
                        parseInt(value.mailPrice.totalQuantity) : drugCost.mailDosageQuantity;
                    drugCost.retailDosageQuantity = value.retailPrice && isNotEmptyNullNA(value.retailPrice.totalQuantity) ?
                        parseInt(value.retailPrice.totalQuantity) : drugCost.retailDosageQuantity;
                    drugCost.brand = value;
                    drugCost.brand.ndcId = (value.retailPrice && value.retailPrice.ndcId) || (value.mailPrice &&
                    value.mailPrice.ndcId);
                    drugCost.brand.coveredByPlanInd = true;
                    drugCost.brand.settlementDesc = [];
                    if (value.mailPrice  && drugCost.dataInd && drugCost.dataInd.isMail) {
                        if (value.mailPrice.settlementCode && isNotEmptyNullNA(value.mailPrice.settlementCode) &&
                            parseInt(value.mailPrice.settlementCode, 10) !== 0) {
                            wtSettlementCode = wtSettlementCode + ";" + value.mailPrice.settlementCode;
                            if(value.mailPrice.settlementDesc){
                                if(value.mailPrice.settlementDesc.indexOf(":")>-1){
                                    var settlement=value.mailPrice.settlementDesc.split(":");
                                    if(settlement[0] && settlement[0].toUpperCase().indexOf("COVERED")>-1){
                                        drugCost.brand.coveredByPlanInd = false;
                                    }
                                    drugCost.brand.mailSettlementDescHeader=settlement[0]+":";
                                    drugCost.brand.mailSettlementDescMsg=settlement[1];
                                }else{
                                    drugCost.brand.mailSettlementDescHeader="";
                                    drugCost.brand.mailSettlementDescMsg=value.mailPrice.settlementDesc;
                                }
                                drugCost.brand.mailSettlementInd=true;
                            }else{
                                drugCost.brand.mailSettlementInd=false;
                            }
                        }
                        drugCost.brand.mailPriceAnually = value.mailPrice.totalDrugCostAnnual;
                        multiPriceAvail++;
                    } else {
                        //drugCost.dataInd.isMail = false;
                    }
                    if (value.retailPrice && drugCost.dataInd && drugCost.dataInd.isRetail) {
                        if (value.retailPrice.settlementCode && isNotEmptyNullNA(value.retailPrice.settlementCode) &&
                            parseInt(value.retailPrice.settlementCode, 10) !== 0) {
                            wtSettlementCode = wtSettlementCode + ";" + value.retailPrice.settlementCode;
                            if(value.retailPrice.settlementDesc){
                                if(value.retailPrice.settlementDesc.indexOf(":")>-1){
                                    var settlement=value.retailPrice.settlementDesc.split(":");
                                    if(settlement[0] && settlement[0].toUpperCase().indexOf("COVERED")>-1){
                                        drugCost.brand.coveredByPlanInd = false;
                                    }
                                    drugCost.brand.retailSettlementDescHeader=settlement[0]+":";
                                    drugCost.brand.retailSettlementDescMsg=settlement[1];
                                }else{
                                    drugCost.brand.retailSettlementDescHeader="";
                                    drugCost.brand.retailSettlementDescMsg=value.retailPrice.settlementDesc;
                                }
                                drugCost.brand.retailSettlementInd=true;
                            }else{
                                drugCost.brand.retailSettlementInd=false;
                            }
                        }
                        multiPriceAvail++;
                    }else{
                        //drugCost.dataInd.isRetail = false;
                    }
                    /*MAIL */
                    drugCost.brand.glovarmail = false;
                    drugCost.brand.month_day = "months";
                    drugCost.brand.glovarretail = false;
                    drugCost.brand.textpercent = false;
                    drugCost.brand.dispmnthmail = "for month";
                    drugCost.brand.showretailprice = true;
                    if (value.retailPrice) {
                        if (value.retailPrice.copayEmployer == "N/A") {
                            drugCost.brand.retailPrice.copayEmployerObject = "N/A";
                            drugCost.brand.showretailprice = false;
                        } else {
                            drugCost.brand.retailPrice.copayEmployerObject = help.createPriceObject(value.retailPrice.copayEmployer);
                            drugCost.brand.showretailprice = true;
                        }
                    } else {
                        //drugCost.dataInd.isRetail = false;
                    }
                    /*if ((parseInt(drugCost.mailDosageSupply) % 30) == 0 && drugCost.mailDosageSupply != 0) {
                        //drugCost.brand.dispmnthmail="for month";
                        if ((parseInt(drugCost.mailDosageSupply) / 30) == 1) {
                            drugCost.brand.textpercent = false;
                            drugCost.brand.month_day = "month";
                        } else {
                            drugCost.brand.textpercent = true;
                            drugCost.brand.month_day = "months";
                        }
                        drugCost.brand.mailMonths = parseInt(drugCost.mailDosageSupply) / 30;
                        drugCost.brand.retailMonths = parseInt(drugCost.retailDosageSupply) / 30;
                    } else if (drugCost.mailDosageSupply % 30 != 0 && drugCost.mailDosageSupply != 0) {
                        // drugCost.brand.dispmnthmail="for"+drugCost.mailDosageSupply;
                        drugCost.brand.mailMonths = drugCost.mailDosageSupply;
                        drugCost.brand.retailMonths = drugCost.retailDosageSupply;
                        drugCost.brand.textpercent = false
                        drugCost.brand.month_day = "days";
                    } else {
                        drugCost.brand.mailMonths = 0;
                        drugCost.brand.retailMonths = 0;
                    }*/
                    //  drugCost.brand.mailMonths = drugCost.mailDosageSupply!=0 ?parseInt(drugCost.mailDosageSupply) / 30 : 0  ;
                    // drugCost.brand.retailMonths = drugCost.retailDosageSupply!=0 ?parseInt(drugCost.retailDosageSupply) / 30 : 0;
                    drugCost.brand.showprice = true;
                    if (value.mailPrice) {
                        drugCost.brand.mailPriceAnually = value.mailPrice.totalDrugCostAnnual;
                        if (value.mailPrice.costToday == "N/A") {
                            drugCost.brand.mailPriceTotal = "N/A";
                            drugCost.brand.mailPricetotalObject = "N/A";
                            drugCost.brand.showprice = false;
                        } else {
                            drugCost.brand.mailPriceTotal = (drugCost.brand.mailMonths * parseFloat(value.mailPrice.copayEmployer))
                                .toFixed(2);
                            drugCost.brand.mailPricetotalObject = help.createPriceObject(parseFloat(value.mailPrice.costToday));

                        
                           /* if( parseInt(value.mailPrice.costToday.split(".")[0])==0&&parseInt(value.mailPrice.costToday.split(".")[1])==0)
                            {
                                drugCost.brand.showprice = false;
                                drugCost.brand.mailPricetotalObject=0;


                            }
                            else {
                                drugCost.brand.showprice = true;
                            }*/
                        }
                        drugCost.brand.mailEmployerPriceTotal = parseFloat(value.mailPrice.costEmployer).toFixed(2);
                    }
                    if (value.retailPrice) {
                        if (value.retailPrice.costToday == "N/A") {
                            drugCost.brand.retailPrice.copayEmployerObject = "N/A";
                            drugCost.brand.showretailprice = false;
                        } else {
                            drugCost.brand.retailPrice.copayEmployerObject = help.createPriceObject(value.retailPrice.costToday);
                            drugCost.brand.showretailprice = true;
                        }
                    } else {
                        //drugCost.dataInd.isRetail = false;
                    }
                    //console.log( drugCost.brand.mailPricetotalObject);
                    drugCost.brand.glovar = true;
                    if (value.mailPrice) {
                        if (value.mailPrice.costToday == "N/A" || value.mailPrice.totalDrugCost == "N/A") {
                            drugCost.brand.glovarmail = false;
                        } else {
                            drugCost.brand.glovarmail = true;
                        }
                        drugCost.brand.mailPercentage = value.mailPrice.costToday != 'N/A' && value.mailPrice.costToday !=
                        '' && value.mailPrice.costToday != '0' && value.mailPrice.totalDrugCost != 'N/A' && value.mailPrice
                            .totalDrugCost != '0' && value.mailPrice.totalDrugCost != '0' ? Math.round((parseFloat(value.mailPrice
                            .costToday) / parseFloat(value.mailPrice.totalDrugCost)) * 100) : 'N/A';
                        drugCost.brand.mailprimaryClaimNumber = value.mailPrice.primaryClaimNumber;
                        drugCost.brand.mailprimaryClaimSequence = value.mailPrice.primaryClaimSequenceNumber;
                        drugCost.brand.mailSecondaryClaimNumber = value.mailPrice.secondaryClaimNumber;
                        drugCost.brand.mailSecondaryClaimSequence = value.mailPrice.secondaryClaimSequenceNumber;
                    }
                    if (value.retailPrice) {
                        if (value.retailPrice.costToday == "N/A" || value.retailPrice.totalDrugCost == "N/A") {
                            drugCost.brand.glovarretail = false;
                        } else {
                            drugCost.brand.glovarretail = true;
                        }
                        drugCost.brand.retailprimaryClaimNumber = value.retailPrice.primaryClaimNumber;
                        drugCost.brand.retailprimaryClaimSequence = value.retailPrice.primaryClaimSequenceNumber;
                        drugCost.brand.retailSecondaryClaimSequence = value.retailPrice.secondaryClaimSequenceNumber;
                        drugCost.brand.retailSecondaryClaimNumber = value.retailPrice.secondaryClaimNumber;
                    }
                    /*RETAIL*/
                    if (value.retailPrice) {
                        var val = parseFloat(value.retailPrice.totalDrugCost);
                        if (isNaN(val) || (val === 0)) {
                            //drugCost.brand.mailPercentage = "0";
                            drugCost.brand.retailPercentage = "0";
                        } else {
                            //drugCost.brand.mailPercentage = Math.round((parseFloat(value.mailPrice.copayEmployer) / parseFloat(value.mailPrice.totalDrugCost)) * 100);
                            drugCost.brand.retailPercentage = Math.round((parseFloat(value.retailPrice.costToday) /
                            parseFloat(value.retailPrice.totalDrugCost)) * 100);
                        }
                        if (isNotEmptyNullNA(value.retailPrice.costToday) && isNotZero(value.retailPrice.costToday)) {
                            drugCost.brand.retailPricePerDay = parseFloat(value.retailPrice.costToday) / drugCost.retailDosageSupply;
                            drugCost.brand.retailPricePerMonth = parseFloat(drugCost.brand.retailPricePerDay * 30).toFixed(
                                2);
                        } else if (!isNotZero(value.retailPrice.costToday)) {
                            drugCost.brand.retailPricePerDay = 0;
                            drugCost.brand.retailPricePerMonth = 0;
                        } else {
                            drugCost.brand.retailPricePerDay = 'N/A';
                            drugCost.brand.retailPricePerMonth = 0;
                        }
                    }
                    if (value.mailPrice) {
                        var val = parseFloat(value.mailPrice.totalDrugCost);
                        if (isNaN(val) || (val === 0)) {
                            drugCost.brand.mailPercentage = "0";
                            //drugCost.brand.retailPercentage = "0";
                        } else {
                            drugCost.brand.mailPercentage = Math.round(
                                (parseFloat(value.mailPrice.costToday) / parseFloat(value.mailPrice.totalDrugCost)) * 100
                            );
                            //drugCost.brand.retailPercentage = Math.round((parseFloat(value.retailPrice.copayEmployer) / parseFloat(value.retailPrice.totalDrugCost)) * 100);
                        }
                        if (isNotEmptyNullNA(value.mailPrice.costToday) && isNotZero(value.mailPrice.costToday)) {
                            drugCost.brand.mailPricePerDay = parseFloat(value.mailPrice.costToday) / drugCost.mailDosageSupply;
                            drugCost.brand.mailPricePerMonth = parseFloat(drugCost.brand.mailPricePerDay * 30).toFixed(2);
                        } else if (!isNotZero(value.mailPrice.costToday)) {
                            drugCost.brand.mailPricePerDay = 0;
                            drugCost.brand.mailPricePerMonth = 0;
                        } else {
                            drugCost.brand.mailPricePerDay = 'N/A';
                            drugCost.brand.mailPricePerMonth = 'N/A';
                        }
                    }
                    if (drugCost.mailDosageSupply == '90' || drugCost.retailDosageSupply == '90') wt90Brand = true;
                    if (drugCost.mailDosageSupply == '30' || drugCost.retailDosageSupply == '30') wt30Brand = true;
                    //(a % 2).toFixed(2).slice(-2);
                    if (fromRequest != 'TAD') {
                        //console.log(drugCost.brand.mailPricePerDay,drugCost.brand.retailPricePerDay);
                        if(value.mailPrice && drugCost.dataInd && drugCost.dataInd.isMail){
                            bestValuesArray.push(value.mailPrice.costToday);
                        };
                        if(value.retailPrice && drugCost.dataInd && drugCost.dataInd.isRetail){
                            bestValuesArray.push(value.retailPrice.costToday)
                        };
                        var bestInd = getLowestPriceAndType(fromRequest, drugCost.brand.mailPricePerDay, drugCost.brand
                            .retailPricePerDay, request.data, 'brand',value.mailPrice && value.mailPrice.costToday,value.retailPrice && value.retailPrice.costToday);
                        if (lowestPrice && (lowestPrice && lowestPrice == bestInd.lowestPrice)) {
                            lowestPrice = bestInd.lowestPrice;
                            lowestPriceType = bestInd.lowestPriceType;
                            bestValuePrice = bestInd.bestValuePrice;
                            showBestValue = false;
                        } else if(lowestPrice=="N/A" && bestInd.showBestValue){
                            lowestPrice = bestInd.lowestPrice;
                            lowestPriceType = bestInd.lowestPriceType;
                            showBestValue = bestInd.showBestValue;
                            bestValuePrice = bestInd.bestValuePrice;
                        }
                        else  if (!lowestPrice || (lowestPrice && lowestPrice > bestInd.lowestPrice)) {
                            if (lowestPrice === 0) {
                                if (lowestPrice === bestInd.lowestPrice) {
                                    showBestValue = false;
                                }
                            } else {
                                lowestPrice = bestInd.lowestPrice;
                                lowestPriceType = bestInd.lowestPriceType;
                                showBestValue = bestInd.showBestValue;
                                bestValuePrice = bestInd.bestValuePrice;
                            }
                        }else if(lowestPriceType ){
                            if((lowestPriceType==="genericMail" && !drugCost.dataInd.isMail && bestInd.lowestPriceType==="brandRetail")
                                || (lowestPriceType==="genericRetail" && !drugCost.dataInd.isRetail && bestInd.lowestPriceType==="brandMail")){
                                lowestPrice = bestInd.lowestPrice;
                                lowestPriceType = bestInd.lowestPriceType;
                                bestValuePrice = bestInd.bestValuePrice;
                                showBestValue = bestInd.showBestValue;
                            }
                        };
                    }
                    drugCost.best = {
                        price: lowestPrice,
                        type: lowestPriceType,
                        ind: showBestValue,
                        bestValuePrice :bestValuePrice
                    };
                } else {
                    drugCost.mailDosageQuantity = value.mailPrice && isNotEmptyNullNA(value.mailPrice.totalQuantity) ?
                        parseInt(value.mailPrice.totalQuantity) : drugCost.mailDosageQuantity;
                    drugCost.retailDosageQuantity = value.retailPrice && isNotEmptyNullNA(value.retailPrice.totalQuantity) ?
                        parseInt(value.retailPrice.totalQuantity) : drugCost.retailDosageQuantity;
                    drugCost.generic = value;
                    drugCost.generic.ndcId = (value.retailPrice && value.retailPrice.ndcId) || (value.mailPrice &&
                    value.mailPrice.ndcId);
                    drugCost.generic.month_day = "months";
                    drugCost.generic.glovarmail = false;
                    drugCost.generic.glovaretail = false;
                    drugCost.generic.settle = true;
                    drugCost.generic.settlementDesc = [];
                    drugCost.generic.coveredByPlanInd = true;
                    if (value.mailPrice  && drugCost.dataInd && drugCost.dataInd.isMail) {
                        if (value.mailPrice.settlementCode && isNotEmptyNullNA(value.mailPrice.settlementCode) &&
                            parseInt(value.mailPrice.settlementCode, 10) !== 0) {
                            drugCost.generic.settle = false;
                            wtSettlementCode = wtSettlementCode + ";" + value.mailPrice.settlementCode;
                            if(value.mailPrice.settlementDesc){
                                if(value.mailPrice.settlementDesc.indexOf(":")>-1){
                                    var settlement=value.mailPrice.settlementDesc.split(":");
                                    if(settlement[0] && settlement[0].toUpperCase().indexOf("COVERED")>-1){
                                        drugCost.generic.coveredByPlanInd = false;
                                    }
                                    drugCost.generic.mailSettlementDescHeader=settlement[0]+":";
                                    drugCost.generic.mailSettlementDescMsg=settlement[1];
                                }else{
                                    drugCost.generic.mailSettlementDescHeader="";
                                    drugCost.generic.mailSettlementDescMsg=value.mailPrice.settlementDesc;
                                }
                                drugCost.generic.mailSettlementInd=true;
                            }else{
                                drugCost.generic.mailSettlementInd=false;
                            }
                        }
                        drugCost.generic.mailPriceAnually = value.mailPrice.totalDrugCostAnnual;
                        multiPriceAvail++;
                    } else {
                        //drugCost.dataInd.isMail = false;
                    }
                    if (value.retailPrice && drugCost.dataInd && drugCost.dataInd.isRetail) {
                        if (value.retailPrice.settlementCode && isNotEmptyNullNA(value.retailPrice.settlementCode) &&
                            parseInt(value.retailPrice.settlementCode, 10) !== 0) {
                            drugCost.generic.settle = false;
                            wtSettlementCode = wtSettlementCode + ";" + value.retailPrice.settlementCode;
                            if(value.retailPrice.settlementDesc){
                                if(value.retailPrice.settlementDesc.indexOf(":")>-1){
                                    var settlement=value.retailPrice.settlementDesc.split(":");
                                    if(settlement[0] && settlement[0].toUpperCase().indexOf("COVERED")>-1){
                                        drugCost.generic.coveredByPlanInd = false;
                                    }
                                    drugCost.generic.retailSettlementDescHeader=settlement[0]+":";
                                    drugCost.generic.retailSettlementDescMsg=settlement[1];
                                }else{
                                    drugCost.generic.retailSettlementDescHeader="";
                                    drugCost.generic.retailSettlementDescMsg=value.retailPrice.settlementDesc;
                                }
                                drugCost.generic.retailSettlementInd =true;
                            }else{
                                drugCost.generic.retailSettlementInd=false;
                            }
                        }
                        multiPriceAvail++;
                    }
                    drugCost.generic.textpercent = false;
                    drugCost.generic.dispmnthmail = "for month";
                    drugCost.generic.showretailprice = true;
                    if (value.retailPrice) {
                        if (value.retailPrice.costToday == "N/A") {
                            drugCost.generic.retailPrice.copayEmployerObject = "N/A";
                            drugCost.generic.showretailprice = false;
                        } else {
                            drugCost.generic.retailPrice.copayEmployerObject = help.createPriceObject(value.retailPrice.costToday);
                            drugCost.generic.showretailprice = true;
                        }
                    } else {
                        //drugCost.dataInd.isRetail = false;
                    }
                    /*if (drugCost.mailDosageSupply % 30 == 0 && drugCost.mailDosageSupply != 0) {
                        if ((parseInt(drugCost.mailDosageSupply) / 30) == 1) {
                            drugCost.generic.textpercent = false;
                            drugCost.generic.month_day = "month";
                        } else {
                            drugCost.generic.textpercent = true;
                            drugCost.generic.month_day = "months";
                        }
                        drugCost.generic.dispmnthmail = "per month";
                        drugCost.generic.mailMonths = parseInt(drugCost.mailDosageSupply) / 30;
                        drugCost.generic.retailMonths = parseInt(drugCost.retailDosageSupply) / 30;
                    } else if (drugCost.mailDosageSupply % 30 != 0 && drugCost.mailDosageSupply != 0) {
                        drugCost.generic.dispmnthmail = "for" + drugCost.mailDosageSupply;
                        drugCost.generic.mailMonths = drugCost.mailDosageSupply;
                        drugCost.generic.retailMonths = drugCost.mailDosageSupply;
                        drugCost.generic.textpercent = false;
                        drugCost.generic.month_day = "days";
                    } else {
                        drugCost.generic.mailMonths = 0;
                        drugCost.generic.retailMonths = 0;
                    }*/
                    /*MAIL*/
                    drugCost.generic.showprice = true;
                    if (value.mailPrice) {
                        drugCost.generic.mailPrice.copayEmployerObject = help.createPriceObject(value.mailPrice.costToday);
                        drugCost.generic.mailPriceAnually = value.mailPrice.totalDrugCostAnnual;
                        //   drugCost.generic.mailMonths = drugCost.mailDosageSupply!=0 ?parseInt(drugCost.mailDosageSupply) / 30 : 0  ;
                        if (value.mailPrice.costToday == "N/A") {
                            drugCost.generic.mailPriceTotal = "N/A";
                            drugCost.generic.mailPricetotalObject = "N/A";
                            drugCost.generic.showprice = false;
                        } else {
                            drugCost.generic.mailPriceTotal = (drugCost.generic.mailMonths * parseFloat(value.mailPrice.costToday))
                                .toFixed(2);
                            drugCost.generic.mailPricetotalObject = help.createPriceObject(value.mailPrice.costToday);
                            /*if( parseInt(value.mailPrice.costToday.split(".")[0])==0&&parseInt(value.mailPrice.costToday.split(".")[1])==0)
                            {
                                drugCost.generic.showprice = false;
                                drugCost.generic.mailPricetotalObject=0;


                            }
                            else {
                                drugCost.generic.showprice = true;
                            }*/

                        }
                        if (value.mailPrice.costToday == "N/A" || value.mailPrice.totalDrugCost == "N/A") {
                            drugCost.generic.glovarmail = false;
                        } else {
                            drugCost.generic.glovarmail = true;
                        }
                        //   drugCost.generic.mailPriceTotal = value.mailPrice.copayEmployer!='0'?(parseFloat(value.mailPrice.copayEmployer)* drugCost.generic.mailMonths).toFixed(2) :'N/A';
                        //  drugCost.generic.mailPricetotalObject = help.createPriceObject(drugCost.generic.mailPriceTotal);
                        drugCost.generic.mailEmployerPriceTotal = (parseFloat(value.mailPrice.costEmployer)).toFixed(2);
                        var val = parseFloat(value.mailPrice.totalDrugCost);
                        if (isNaN(val) || (val === 0)) {
                            drugCost.generic.mailPercentage = "0";
                            //drugCost.generic.retailPercentage = "0";
                        } else {
                            drugCost.generic.mailPercentage = Math.round((parseFloat(value.mailPrice.costToday) /
                            parseFloat(value.mailPrice.totalDrugCost)) * 100);
                            //drugCost.generic.retailPercentage = Math.round((parseFloat(value.retailPrice.copayEmployer) / parseFloat(value.retailPrice.totalDrugCost)) * 100);
                        }
                        drugCost.generic.mailprimaryClaimNumber = value.mailPrice.primaryClaimNumber;
                        drugCost.generic.mailprimaryClaimSequence = value.mailPrice.primaryClaimSequenceNumber;
                        drugCost.generic.mailSecondaryClaimNumber = value.mailPrice.secondaryClaimNumber;
                        drugCost.generic.mailSecondaryClaimSequence = value.mailPrice.secondaryClaimSequenceNumber;
                        if (isNotEmptyNullNA(value.mailPrice.costToday) && isNotZero(value.mailPrice.costToday)) {
                            drugCost.generic.mailPricePerDay = parseFloat(value.mailPrice.costToday) / drugCost.mailDosageSupply;
                            drugCost.generic.mailPricePerMonth = parseFloat(drugCost.generic.mailPricePerDay * 30).toFixed(
                                2);
                        } else if (!isNotZero(value.mailPrice.costToday)) {
                            drugCost.generic.mailPricePerDay = 0;
                            drugCost.generic.mailPricePerMonth = 0;
                        } else {
                            drugCost.generic.mailPricePerDay = 'N/A';
                            drugCost.generic.mailPricePerMonth = 'N/A';
                        }
                    } else {
                        //drugCost.dataInd.isMail = false;
                    }
                    /*RETAIL*/
                    if (value.retailPrice) {
                        // drugCost.generic.retailPrice.copayEmployerObject = help.createPriceObject(value.retailPrice.copayEmployer);
                        //drugCost.generic.retailMonths = drugCost.retailDosageSupply!=0 ?parseInt(drugCost.retailDosageSupply) / 30 : 0;
                        // drugCost.generic.retailPercentage = value.retailPrice.copayEmployer!='N/A' && value.retailPrice.copayEmployer!='' && value.retailPrice.copayEmployer!='0'
                        //  && value.retailPrice.totalDrugCost!='N/A' && value.retailPrice.totalDrugCost!='0' &&value.retailPrice.totalDrugCost!='0'
                        // ? Math.round((parseFloat(value.retailPrice.copayEmployer) / parseFloat(value.retailPrice.totalDrugCost)) * 100) : 'N/A';
                        if (value.retailPrice.costToday == "N/A" || value.retailPrice.totalDrugCost == "N/A") {
                            drugCost.generic.glovarretail = false;
                        } else {
                            drugCost.generic.glovarretail = true;
                        }
                        drugCost.generic.retailprimaryClaimNumber = value.retailPrice.primaryClaimNumber;
                        drugCost.generic.retailprimaryClaimSequence = value.retailPrice.primaryClaimSequenceNumber;
                        drugCost.generic.retailSecondaryClaimNumber = value.retailPrice.secondaryClaimNumber;
                        drugCost.generic.retailSecondaryClaimSequence = value.retailPrice.secondaryClaimSequenceNumber;
                        if (isNotEmptyNullNA(value.retailPrice.costToday) && isNotZero(value.retailPrice.costToday)) {
                            drugCost.generic.retailPricePerDay = parseFloat(value.retailPrice.costToday) / drugCost.retailDosageSupply;
                            drugCost.generic.retailPricePerMonth = parseFloat(drugCost.generic.retailPricePerDay * 30).toFixed(
                                2);
                        } else if (!isNotZero(value.retailPrice.costToday)) {
                            drugCost.generic.retailPricePerDay = 0;
                            drugCost.generic.retailPricePerMonth = 0;
                        } else {
                            drugCost.generic.retailPricePerDay = 'N/A';
                            drugCost.generic.retailPricePerMonth = 0;
                        }
                        var val = parseFloat(value.retailPrice.totalDrugCost);
                        if (isNaN(val) || (val === 0)) {
                            //drugCost.generic.mailPercentage = "0";
                            drugCost.generic.retailPercentage = "0";
                        } else {
                            //drugCost.generic.mailPercentage = Math.round((parseFloat(value.retailPrice.copayEmployer) / parseFloat(value.retailPrice.totalDrugCost)) * 100);
                            drugCost.generic.retailPercentage = Math.round((parseFloat(value.retailPrice.costToday) /
                            parseFloat(value.retailPrice.totalDrugCost)) * 100);
                        }
                    } else {
                        //drugCost.dataInd.isRetail = false;
                    }
                    if (drugCost.mailDosageSupply == '90' || drugCost.retailDosageSupply == '90') wt90Generic = true;
                    if (drugCost.mailDosageSupply == '30' || drugCost.retailDosageSupply == '30') wt30Generic = true;
                    /*if(request.data){*/
                    if (fromRequest != 'TAD') {
                        if(value.mailPrice && drugCost.dataInd && drugCost.dataInd.isMail){
                            bestValuesArray.push(value.mailPrice.costToday);
                        };
                        if(value.retailPrice && drugCost.dataInd && drugCost.dataInd.isRetail){
                            bestValuesArray.push(value.retailPrice.costToday)
                        };
                        //console.log(drugCost.generic.mailPricePerDay,drugCost.generic.retailPricePerDay);
                        var bestInd = getLowestPriceAndType(fromRequest, drugCost.generic.mailPricePerDay, drugCost.generic
                            .retailPricePerDay, request.data, 'generic',value.mailPrice && value.mailPrice.costToday,value.retailPrice && value.retailPrice.costToday);
                        if (lowestPrice && (lowestPrice && lowestPrice == bestInd.lowestPrice)) {
                            lowestPrice = bestInd.lowestPrice;
                            lowestPriceType = bestInd.lowestPriceType;
                            bestValuePrice = bestInd.bestValuePrice;
                            showBestValue = false;
                        } else if(lowestPrice=="N/A" && bestInd.showBestValue){
                            lowestPrice = bestInd.lowestPrice;
                            lowestPriceType = bestInd.lowestPriceType;
                            bestValuePrice = bestInd.bestValuePrice;
                            showBestValue = bestInd.showBestValue;
                        }
                        else if (!lowestPrice || (lowestPrice && lowestPrice > bestInd.lowestPrice)) {
                            if (lowestPrice === 0) {
                                if (lowestPrice === bestInd.lowestPrice) {
                                    showBestValue = false;
                                }
                            } else {
                                lowestPrice = bestInd.lowestPrice;
                                lowestPriceType = bestInd.lowestPriceType;
                                bestValuePrice = bestInd.bestValuePrice;
                                showBestValue = bestInd.showBestValue;
                            }
                        }else if(lowestPriceType ){
                            if((lowestPriceType==="brandMail" && !drugCost.dataInd.isMail && bestInd.lowestPriceType==="genericRetail")
                                || (lowestPriceType==="brandRetail" && !drugCost.dataInd.isRetail && bestInd.lowestPriceType==="genericMail")){
                                lowestPrice = bestInd.lowestPrice;
                                lowestPriceType = bestInd.lowestPriceType;
                                bestValuePrice = bestInd.bestValuePrice;
                                showBestValue = bestInd.showBestValue;
                            }
                        };
                    }
                    drugCost.best = {
                        price: lowestPrice,
                        type: lowestPriceType,
                        ind: showBestValue,
                        bestValuePrice: bestValuePrice
                    };
                    /*}*/
                }
            });
            ///making best value indicator false if only one drug cost is available
            if(multiPriceAvail<=1 && drugCost.best){
                drugCost.best.ind === false;
            }

            //     WebAnalytics code do not remove
            var wtValues = '';
            if (wt30Generic == true) wtValues = '30d:generic;';
            if (wt30Brand == true) wtValues = wtValues + '30d:brand;';
            if (wt90Generic == true) wtValues = wtValues + '90d:generic;';
            if (wt90Brand == true) wtValues = wtValues + '90d:brand;';
            wtValues = wtValues.substring(0, wtValues.length - 1);
            $rootScope.$emit('TealiumWebAnalytic', {
                "key": "30-90days",
                "value": wtValues
            });
            if (wtSettlementCode != '') {
                wtSettlementCode = wtSettlementCode.substring(1);
                $rootScope.$emit('TealiumWebAnalytic', {
                    "key": "SCODE",
                    "value": wtSettlementCode
                });
            }

            if(fromRequest!='additionalPharmacies') {
            if(!(drugCost.generic && drugCost.brand)){
                if(!(drugCost.dataInd && drugCost.dataInd.isMail && drugCost.dataInd.isRetail)){
                    drugCost.best.ind=false;
                }
            }
            }

            if(bestValuesArray.length>0){
                var count=0;
                //console.log(bestValuesArray);
                function isNumber(n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                }
                angular.forEach(bestValuesArray,function(value){
                    if(isNumber(value)){
                        count++;
                    }
                });

                if(count<2){
                    if((drugCost.best && drugCost.best.ind)){
                        drugCost.best.ind=false;
                    }
                };



            };
            //     WebAnalytics code do not remove
            return drugCost;
        };
        /**
         * creating a object for drug price
         * @param price
         * @returns {{}}
         */
    help.createPriceObject = function(price) {
        var jsonObject = {};
        if(price && price!=='' && price!='N/A' & price !='NaN' ){
            var newPrice = parseFloat(price);
            jsonObject.decimal = (newPrice % 2).toFixed(2).slice(-2);
            jsonObject.integer = Math.floor(newPrice);
            return jsonObject;
        }else if(price==0){
            jsonObject.decimal = "00";
            jsonObject.integer = "0";
            return jsonObject;
        }else{
            return null;
        }
    };
        /**
         * Request to add a new drug
         * @param request
         * @param userInfo
         * @returns {{}}
         */
    help.getTADDrugRequestObject = function(request,userInfo) {
        function getAge(dateString)
        {
            var today = new Date();
            var birthDate = new Date(dateString);
            var age = today.getFullYear() - birthDate.getFullYear();
            var m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate()))
            {
                age--;
            }
            return age;
        }
        var getDrugAlternativesRequest = {
            "retrieveRepDrug": false,//(request.tad&&  request.tad.tadRad),
            "retrieveDefaultIndication": false,
            //TODO ndCId
            "ndcId": request.retailDrug && request.retailDrug.ndcId,
            //request.Costs && (request.Costs.generic && request.Costs.generic.mail[0] && request.Costs.generic.mail[0].Price && request.Costs.generic.mail[0].Price.ndcId),
            "gender":userInfo && userInfo.gender,
            "age": userInfo && userInfo.dateOfBirth? getAge(userInfo.dateOfBirth): 0,
            "indicationId": (request.tad&&  request.tad.tadRadInd),
            "frequency": "1",
            "frequencyUnitId": "4",
            "recapFlag": userInfo && userInfo.eisName && userInfo && userInfo.eisName==='recap'? true :false,
            "recapMailFlag":userInfo && userInfo.eisName && userInfo && userInfo.eisName==='recap'? true :false,
            "rxclaimFlag": userInfo && userInfo.eisName && userInfo && userInfo.eisName==='recap'? false :true,
            "rxclaimMailFlag": userInfo && userInfo.eisName && userInfo && userInfo.eisName==='recap'? false :true

        };
        var beneficiaryKey = {
            "eisName": userInfo && userInfo.eisName,
            "internalID": userInfo && userInfo.internalID,
            "benefactorClientInternalID": userInfo && userInfo.benefactorClientInternalID,
            "eligibilityProviderClientID": "null",
            "cardholderInternalID": userInfo && userInfo.cardholderInternalID
           /* "carrierID": "", "accountID": "",  "groupID": "", "externalID": userInfo && userInfo.externalID,  "personCode": "","gender": userInfo && userInfo.gender,
            "dateOfBirth": (userInfo && userInfo.dateOfBirth) || undefined, "familyType": "", "cardholderRelationCode": userInfo && userInfo.cardholderRelationCode || undefined,
            "payerID": "","coverageEffectiveDate": userInfo && userInfo.coverageEffectiveDate,"coverageTerminationDate": userInfo && userInfo.coverageTerminationDate,
            "enrollmentCode": ""*/
        };
        var requesterObj = {
            "clientAppName": "Portal"
           /* "clientAppVersion": "1.0","userId": "","referenceId": "","clientTraceLevel": ""*/
        };

        var reqDrugRequestData = {
            "mailFormularyId": "",
            "retailFormularyId": "",
            "beneficiaryKey":beneficiaryKey
        };
        getDrugAlternativesRequest.requester = requesterObj;
        getDrugAlternativesRequest.reqDrugRequestData = reqDrugRequestData;
        var formedRequest = {};
        formedRequest['getDrugAlternativesRequest'] = getDrugAlternativesRequest;
        return formedRequest;
    };
        /**
         *
         * @param requestObj
         * @returns {{}}
         */
    var getDrugIndicationsByNDCIdRequest = function(requestObj){
        var requester={
            "clientAppName":requestObj.clientAppName || "Portal",
            "clientAppVersion":"",
            "userId":"",
            "referenceId":"",
            "clientTraceLevel":""
            };
        var formedRequest = {};
        var getDrugIndicationsRequest={
            "ndcId":requestObj.ndcId || "",
            "requester":requester
        };
        formedRequest['getDrugIndicationsRequest'] = getDrugIndicationsRequest;
        var request={};
        request.params={
            "operationName":"getDrugIndicationsByNDCId"
        };
        request.body=formedRequest;
        return request;

    };
        /**
         *
         * @param requetObj
         * @returns {*}
         */
    help.getDrugIndicationsByNDCId = function(requetObj) {
        var formedRequest=getDrugIndicationsByNDCIdRequest(requetObj);
        return cdcServices.getDrugIndicationsByNDCId(formedRequest.params,formedRequest.body);
    };

        /**
         *
         * @param requestObj
         * @param pharmacyId
         * @param userObj
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
    help.getTADPriceInformation = function(reqArray,pharmacyId,userObj,alternativeArray) {
        var createTADDrugPriceRequestArray = [];
        /*angular.forEach(requestObj, function(reqArray) {*/
            var formedRequest={
                drugDetails:{
                    isMail: reqArray.mailDrug && reqArray.mailDrug.ndcId ? true :false,
                    isRetail :reqArray.retailDrug && reqArray.retailDrug.ndcId ? true :false,
                    isSolid : true,
                    dosageSelected : {"hasCommon" : true
                    },
                    mailDrug:{
                        commonDaysSupply:reqArray.mailDrug && reqArray.mailDrug.commonDaysSupply || 90 ,
                        commonDispensedQuantity:reqArray.mailDrug && reqArray.mailDrug.mailMostCommonlyDispensedQty || 90,
                        ndcId:reqArray.mailDrug && reqArray.mailDrug.ndcId || reqArray.ndcId

                    },
                    retailDrug:{
                        commonDaysSupply:reqArray.retailDrug && reqArray.retailDrug.commonDaysSupply || 30 ,
                        commonDispensedQuantity:reqArray.retailDrug && reqArray.retailDrug.commonDispensedQuantity || 30,
                        ndcId:reqArray.retailDrug && reqArray.retailDrug.ndcId || reqArray.ndcId
                    }
                },
                userName:{
                    internalID:userObj.internalID,
                    stCob:userObj.stCob
                },
                pharmacy:{
                    pharmacyId:pharmacyId
                },
                version:"2.0",
                tadRequest:true,
                operationName:"getTADDrugPrice"
            };
            var priceRequest=help.formatDrugPriceRequest(formedRequest);
            createTADDrugPriceRequestArray=priceRequest;
            //createTADDrugPriceRequestArray.push(priceRequest[0]);
       /* });*/
        var deferred=$q.defer();
        callDrugPricePromiseChaining(createTADDrugPriceRequestArray).then(
            function(response){
                var listResponseArray=[];
                angular.forEach(response.response.detail.costDetailsList.costDetails,function(eachArrayValue){
                    var found=false;
                    var reqParam=createTADDrugPriceRequestArray[0].param;
                    /*if(eachArrayValue.mailPrice || eachArrayValue.retailPrice){
                        if(eachArrayValue.mailPrice && eachArrayValue.mailPrice.ndcId && alternativeArray.contains(eachArrayValue.mailPrice.ndcId)){
                         found=true;
                        }else{
                            if(eachArrayValue.mailPrice){delete eachArrayValue.mailPrice;}
                        }
                        if(eachArrayValue.retailPrice && eachArrayValue.retailPrice.ndcId && alternativeArray.contains(eachArrayValue.retailPrice.ndcId)){
                            found=true;
                        }else{
                            if(eachArrayValue.retailPrice){delete eachArrayValue.retailPrice;}
                        }
                    }*/
                    if(eachArrayValue.mailPrice || eachArrayValue.retailPrice){
                        var drugNameTmp=eachArrayValue.drugName.__cdata;
                       if(alternativeArray && alternativeArray.length>0){
                            angular.forEach(alternativeArray,function(eachvalue){
                                if(drugNameTmp.indexOf(eachvalue)>-1){
                                    found=true;
                                }
                            });
                        }
                     }
                    if(found){
                        var formattedResponse = help.formatDrugCostResponse(eachArrayValue, reqParam,"TAD");
                        var formattedResponseData = costResultDataService.formDataModel(formattedResponse, "generic");
                        listResponseArray.push(angular.copy(formattedResponseData));
                    }
                });
                deferred.resolve(listResponseArray);
            },
            function(error){
                deferred.reject(error);
            });
        return deferred.promise;
        //return cdcServices.getTADPriceInformation(help.getTADDrugRequestObject(requetObj));
    };
        /**
         * Getting GSM Alchemy
         * @param req
         */
    help.getGSMAlchemy = function(req) {
        var requestObj=GSMAlchemyRequest(req);
        var deferred=$q.defer();
      cdcServices.getGSMAlchemy(requestObj.params,requestObj.body).then(function(success){
          success['requestDrugName']=req.drugName;
          deferred.resolve(success);
      },function(error){
          deferred.reject(error);
      });
        return deferred.promise;
    };
        /**
         *
         * @param request
         * @returns {Array}
         */
    help.formatDrugPriceRequest = function(request,fromRequest) {
        var formattedRequestArray=[];
        var formattedRequest = {};
        formattedRequest.param = {};
        formattedRequest.param.data = {
            isMail: fromRequest && fromRequest==='additionalPharmacies'? false : request.drugDetails && request.drugDetails.isMail ?  true :false,
            isRetail: request.drugDetails.isRetail  ?  true :false,
            isSolid: request.drugDetails.isSolid ?  true :false,
            hasCommon:request.drugDetails.dosageSelected.hasCommon && !request.drugDetails.dosageSelected.isCustom ?true :false,
            isStCob:request.userName.stCob==="true"?true :false,
            pharmacy:request.pharmacy,
            isMChoiceMember:isMChoiceMember(request.userName),
            medicare:request.userName.medicare==="true"?true:false
        };
        formattedRequest.param.dispenseWritten=0;
        formattedRequest.param.pharmacyId = request.pharmacy.pharmacyId || request.pharmacy.pharmacyNumber;
        formattedRequest.param.drugNDCID = request.drugDetails.retailDrug.ndcId;
        formattedRequest.param.memberID = (request.userName && request.userName.internalID) || (request.memberSelect && request.memberSelect.internalID);
        formattedRequest.param.operationName = "getDrugPrice";
        //formattedRequest.param.tadRequest= false;
        formattedRequest.param.version = "2.0";
        if(request.tadRequest){
          formattedRequest.param.tadRequest=request.tadRequest;
            formattedRequest.param.metricQtyFilter=true;
            formattedRequest.param.operationName="getTADPrice";
            formattedRequest.param.dispenseWritten="0";
          }

        if(request.drugDetails.dosageSelected && request.drugDetails.dosageSelected.hasCommon && !request.drugDetails.dosageSelected.isCustom){
            //var daysSupply=request.drugDetails.mailDrug.commonDaysSupply || request.drugDetails.retailDrug.commonDaysSupply;
            //var qty=request.drugDetails.mailDrug.commonDispensedQuantity || request.drugDetails.retailDrug.commonDispensedQuantity;
            formattedRequest.param.data.mailDaysSupply= request.drugDetails.mailDrug && request.drugDetails.mailDrug.commonDaysSupply ? request.drugDetails.mailDrug.commonDaysSupply:0;
            formattedRequest.param.data.retailDaysSupply= request.drugDetails.retailDrug && request.drugDetails.retailDrug.commonDaysSupply ? request.drugDetails.retailDrug.commonDaysSupply:0;
            formattedRequest.param.data.retailQuantity= request.drugDetails.retailDrug ? Math.round(parseInt(request.drugDetails.retailDrug.commonDispensedQuantity)):0;
            formattedRequest.param.data.mailQuantity=request.drugDetails.mailDrug?Math.round(parseInt(request.drugDetails.mailDrug.commonDispensedQuantity)):0;
           /* for(i=0;i<2;i++){
                if(i==0){
                    formattedRequest.param.daysSupply=formattedRequest.param.data.mailDaysSupply;
                    formattedRequest.param.quantity=parseInt(formattedRequest.param.data.mailQuantity);
                    formattedRequest.param.drugNDCID = request.drugDetails.retailDrug.ndcId;
                    if(formattedRequest.param.data.isMail){
                        formattedRequestArray.push(angular.copy(formattedRequest));
                    }
                }else{
                    formattedRequest.param.daysSupply=formattedRequest.param.data.retailDaysSupply;
                    formattedRequest.param.quantity=parseInt(formattedRequest.param.data.retailQuantity);
                    formattedRequest.param.drugNDCID = request.drugDetails.retailDrug.ndcId;
                    if(formattedRequest.param.data.isRetail){
                        formattedRequestArray.push(angular.copy(formattedRequest));
                    }
                }
            }*/
            formattedRequest.param.daysSupply="BLNK";
            formattedRequest.param.quantity="BLNK";
            formattedRequest.param.drugNDCID = request.drugDetails.retailDrug.ndcId;
            formattedRequestArray.push(angular.copy(formattedRequest));

        }else{
            if(request.drugDetails.dosageSelected.options){
                if(request.drugDetails.dosageSelected.options.days){
                    var qty=request.drugDetails.dosageSelected.options.qty;
                    formattedRequest.param.daysSupply=request.drugDetails.dosageSelected.options.days;
                    formattedRequest.param.data.mailDaysSupply= request.drugDetails.dosageSelected.options.days;
                    formattedRequest.param.data.retailDaysSupply= request.drugDetails.dosageSelected.options.days;
                    formattedRequest.param.data.retailQuantity=Math.round(parseInt(qty) * parseInt(formattedRequest.param.daysSupply));
                    formattedRequest.param.data.mailQuantity=formattedRequest.param.data.retailQuantity;
                    formattedRequest.param.quantity=formattedRequest.param.data.mailQuantity;
                    formattedRequestArray.push(formattedRequest);
                }else{
                    /*for(var i=0;i<2;i++){*/
                        var freq=request.drugDetails.dosageSelected.options.duration.days ;
                        var qty=request.drugDetails.dosageSelected.options.qty;
                        formattedRequest.param.data.mailDaysSupply= 90;
                        formattedRequest.param.data.retailDaysSupply= 30;
                        if(request.drugDetails.dosageSelected.options.duration.days==1){
                            formattedRequest.param.daysSupply="DAYS";
                            formattedRequest.param.data.retailQuantity=Math.round(parseInt(30* parseInt(qty)));
                            formattedRequest.param.data.mailQuantity=Math.round(parseInt(90 * parseInt(qty)));
                         }else if(request.drugDetails.dosageSelected.options.duration.days===7){
                            formattedRequest.param.daysSupply="WEEK";
                            formattedRequest.param.data.retailQuantity=Math.round(parseInt(4* parseInt(qty)));
                            formattedRequest.param.data.mailQuantity=Math.round(parseInt(13 * parseInt(qty)));
                        }else{
                            formattedRequest.param.daysSupply="MONTH";
                            formattedRequest.param.data.retailQuantity=Math.round(parseInt(qty));
                            formattedRequest.param.data.mailQuantity=Math.round(parseInt(3 * parseInt(qty)));
                        }
                        //formattedRequest.param.daysSupply= request.drugDetails.dosageSelected.options.duration.days;
                        formattedRequest.param.quantity=Math.round(parseInt(qty));
                        /* if(i==0){
                            formattedRequest.param.daysSupply=90;
                            formattedRequest.param.data.mailDaysSupply= 90;
                            formattedRequest.param.data.retailDaysSupply= 30;
                            var quantity=parseInt(qty) / parseInt(freq);
                            if(quantity<1){
                                formattedRequest.param.quantity=Math.round(parseInt(formattedRequest.param.daysSupply));
                                formattedRequest.param.data.retailQuantity=30;
                            }else{
                                formattedRequest.param.quantity=Math.round(parseInt(formattedRequest.param.daysSupply) * quantity);
                                formattedRequest.param.data.retailQuantity=Math.round(formattedRequest.param.data.retailDaysSupply * quantity);
                            }
                            formattedRequest.param.data.mailQuantity=Math.round(parseInt(formattedRequest.param.quantity));
                            if(formattedRequest.param.data.isMail){
                                formattedRequestArray.push(angular.copy(formattedRequest));
                            }

                        }else{
                            formattedRequest.param.daysSupply=30;
                            var quantity=parseInt(qty) / parseInt(freq);
                            if(quantity<1){
                                formattedRequest.param.quantity=Math.round(parseInt(formattedRequest.param.daysSupply));
                            }else{
                                formattedRequest.param.quantity=Math.round(parseInt(formattedRequest.param.daysSupply) * quantity);
                            }
                            formattedRequest.param.data.retailDaysSupply= 30;
                            formattedRequest.param.data.retailQuantity=Math.round(parseInt(formattedRequest.param.quantity));
                            if(formattedRequest.param.data.isRetail){
                                formattedRequestArray.push(angular.copy(formattedRequest));
                            }
                        }*/

                        formattedRequestArray.push(angular.copy(formattedRequest));
                    /*}*/
                }
            }
        }
        return formattedRequestArray;
    };
	/**
         * getting claim request
         * @param request
         * @returns {{}}
         */
    help.formatGetClaimRequest = function(request,costDetails)
    {
        var requestArray=[];
        //claimNumber=151138375542001&claimSequenceNumber=998&deliverySystem=1&memberID=264462689  operationName=getClaimDetail

        var memberID = (request.userName && request.userName.internalID) || (request.memberSelect && request.memberSelect.internalID);

        for(var i=0;i<2;i++){
            if(i==0){
                var requestVal = {
                    claimNumber:costDetails.costDetail.primaryClaimNumber,
                    claimSequenceNumber: costDetails.costDetail.primaryClaimSequence ,
                    deliverySystem:"1",
                    operationName:"getClaimDetail",
                    primary:true
                };
                requestVal.memberID=memberID;
            }else{
                var requestVal = {
                    claimNumber: costDetails.costDetail.secondaryClaimNumber,
                    claimSequenceNumber:costDetails.costDetail.secondaryClaimSequence,
                    deliverySystem:"1",
                    operationName:"getClaimDetail",
                    primary:false
                };
                requestVal.memberID= memberID;
            }
            requestArray.push(requestVal);
        }
       return requestArray;
    };
    help.formatGetClaimDetailResponse = function(response) {
         var ClaimDetail = {};
            if(response && response.length>0){
                ClaimDetail.primary=response[0];
                ClaimDetail.secondary=response[1];
            }
        //console.log("claimDetails",ClaimDetail);
            return ClaimDetail;
    };
    /**
         *Details of drug searched in past
         * @param request
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
    help.pastDrugPriceDetails=function(request){
        var deferred = $q.defer();
        var additionalPharmaciesRequestArray=[];
        /*angular.forEach(request.additionalPharmaciesArray,function(resp){
            var forReq
           additionalPharmaciesRequestArray.push(request);
        });*/
        if (request.additionalPharmaciesArray.length > 0) {
            help.getAdditionalPharmacyPriceInformation(request).then(function(res) {
                deferred.resolve(res);
            }, function(error) {
                deferred.reject("Error");
            });
        } else {
            deferred.reject("Error");
        }
        return deferred.promise;
    };
    /**
         * Getting information about price of drug in additional pharmacy
         * @param request
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
    help.getAdditionalPharmacyPriceInformation = function(request) {
        var createTADDrugPriceRequestArray = [];
        var response = {};
        response.param = {};
        if(request.drugDetails.dosageSelected && request.drugDetails.dosageSelected.hasCommon){
            response.param.daysSupply=request.drugDetails.mailDrug.commonDaysSupply || request.drugDetails.retailDrug.commonDaysSupply;
            var qty=request.drugDetails.mailDrug.commonDispensedQuantity || request.drugDetails.retailDrug.commonDispensedQuantity;
            response.param.dispenseWritten=request.drugDetails.mailDrug.dispenseWritten || request.drugDetails.retailDrug.commonDispensedQuantity;
            var quantity=parseInt(qty) / parseInt(response.param.daysSupply);
            response.param.quantity=qty;
        }else{
            if(request.drugDetails.dosageSelected.options){
                response.param.daysSupply=request.drugDetails.dosageSelected.options.duration.days ;
                qty=request.drugDetails.dosageSelected.options.qty;
                response.param.dispenseWritten=request.drugDetails.dosageSelected.options.days || 90;
                var quantity=parseInt(qty) / parseInt(response.param.daysSupply);
                if(quantity<1){
                    response.param.quantity=parseInt(response.param.dispenseWritten);
                }else{
                    response.param.quantity=parseInt(response.param.dispenseWritten) * quantity;
                }
            }
        }
        if (request.pharmacy && request.pharmacy.pharmacyId) {
            response.param.pharmacyId = request.pharmacy.pharmacyId;
        };
        response.param.memberID = (request.userName && request.userName.externalID) || (request.memberSelect && request.memberSelect.externalID);
        response.param.drugNDCID = request.drugDetails.retailDrug.ndcId || request.drugDetails.mailDrug.ndcId;
        response.param.drugForm=request.drugDetails.drugForm.__cdata;
        response.param.drugName=request.drugDetails.drugName.__cdata;
        response.param.brandName=request.drugDetails.drugName.__cdata;
        angular.forEach(request.additionalPharmaciesArray, function(reqArray) {
        var formedRequest={
                "doseForm": response.param.drugForm,
                "drugName": response.param.drugName,
                "brandName": response.param.brandName,
                "daysSupply":response.param.daysSupply,
                "ndcId": response.param.drugNDCID,
                "mailMostCommonlyDispensedQty": response.param.quantity,
                "dispenseWritten":response.param.dispenseWritten,
                //"drugNDCID":reqArray.drugNDCID,
                "memberID":response.param.memberID,
                "pharmacyId":reqArray.pharmacyNumber,
                "operation":"getDrugPrice",
                "tadRequest":false
            };
            createTADDrugPriceRequestArray.push(formedRequest);
        });
        return callDrugPricePromiseChaining(createTADDrugPriceRequestArray);
        //return cdcServices.getTADPriceInformation(help.getTADDrugRequestObject(requetObj));
    };

    var isMChoiceMember= function(user){
        if(user && user.eligibility && user.eligibility.benefitPlanList && user.eligibility.benefitPlanList.benefitPlan){
            var benefitPlanArray=[];
            var returnedValue=false;
            if(Array.isArray(user.eligibility.benefitPlanList.benefitPlan)){
                benefitPlanArray=user.eligibility.benefitPlanList.benefitPlan;
            }else{
                benefitPlanArray.push(user.eligibility.benefitPlanList.benefitPlan);
            }
            angular.forEach(benefitPlanArray,function(benefitPlan){
                if(benefitPlan.maintenanceChoiceIndicator && benefitPlan.maintenanceChoiceIndicator==='true'){
                    returnedValue=true;
                }
            });
            return returnedValue;
        }else{
            return false;
        }

    };

        help.setSessionData = function (searchData, isPastSearch) {
            var getCurrentData = function (storedSessionData) {
                return {
                    'currentSearch': {
                        'userName': searchData.userName,
                        'drugName': searchData.drugName,
                        'pharmacy': searchData.pharmacy,
                        'drugDetails': searchData.drugDetails,
                        'additionalPharmacies': searchData.additionalPharmacies,
                        'tad': searchData.tad
                    }
                };
            };
            var sessionStoredData = helpService.getSessionStorage(activeModel.tokenId);
            if (sessionStoredData) {
                if (isPastSearch) {
                    sessionStoredData['pastSearch'] = searchData;
                } else {
                    sessionStoredData['currentSearch'] = getCurrentData(sessionStoredData).currentSearch;
                }
            }
            else {
                sessionStoredData = getCurrentData();
            }
            sessionStoredData['memberList'] = activeModel.memberList;
            sessionStoredData['loggedInUserInfo'] = userSessionData.getLoggedInUserInfo();
            helpService.setSessionStorage(activeModel.tokenId, sessionStoredData);
        };
    return help;
}]);