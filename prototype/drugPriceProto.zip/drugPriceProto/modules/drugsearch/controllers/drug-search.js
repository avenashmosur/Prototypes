(function () {
    'use strict';

    checkDrugCostController.controller('drugSearchController', drugSearchController);

    drugSearchController.$inject = ['CoreCommonsModal', '$scope', 'activeModel', 'help', 'errors','localytics',
        'userSessionData', 'drugSearchHelper', '$timeout', '$filter', 'personalization', 'pharmacyLocatorHelper'];

    function drugSearchController(CoreCommonsModal, $scope, activeModel, help, errors,localytics,
                                  userSessionData, drugSearchHelper, $timeout, $filter, personalization, pharmacyLocatorHelper) {

        try{
            localytics.ltOnScreenLoad("Search|Home");
        }
        catch(e){}

        $scope.printStateOn = help.printStateOn;
        $scope.error = {};
        $scope.error.message = '';
        $scope.FastContentService = help.readFASTContent();
        $scope.isPage = true;
        $scope.showHeader = true;
        $scope.enableSearch = false;
        if (!$scope.newSearch) {
            $scope.newSearch = false;
        }
        $scope.noResultMsg = '';
        $scope.authenticated = false;
        $scope.showLoading = false;
        $scope.noPharmacy='';
        $scope.noDosage='';
        var requestForSearch = null;

        if (help.currentLocation() !== '/' || help.currentLocation().indexOf('/drug-search.html') !== -1) {
            $scope.isPage = false;
        }

        if (activeModel.authenticated) {
            $scope.authenticated = true;
            if (!activeModel.memberList) {
                drugSearchHelper.checkAuthentication().then(successAuthenticate, errorAuthenticate);
            }
            else {
                $scope.memberList = activeModel.memberList;
                if ($scope.editCriteriaData) {
                    editSearch($scope.editCriteriaData);
                } else {
                    setToView();
                }
            }
        }
        else {
            updateErrorMessage(errors.getErrorMessage('009'));
        }

        var savedKey;
        $scope.getDrugSearch = function (val) {
            $scope.noResultMsg = '';
            if (val && val.length < 3) {
                return false;
            }
            if (!savedKey) {
                savedKey = val;
            }
            if ($scope.noResultMsg.length && val.length > 3 && val.indexOf(savedKey) === 0) {
                $scope.noResultMsg = errors.getErrorMessage('008');
                //WebAnalytics Code: Do not Delete
                $scope.$emit('TealiumWebAnalytic', {"key": "NoResultsFound"});
                return false;
            }

            reset();
            return drugSearchHelper.drugSearch(val).then(function (response) {
                $scope.noResultMsg = '';
                if (response.length) {
                    return response;
                } else {
                    $scope.noResultMsg = errors.getErrorMessage('008');
                    //WebAnalytics Code: Do not Delete
                    $scope.$emit('TealiumWebAnalytic', {"key": "NoResultsFound"});
                    return false;
                }
            }, function (data) {
                if (data && data.response && data.response.header.statusCode === '2020') {
                    $scope.noResultMsg = errors.getErrorMessage('008');
                    //WebAnalytics Code: Do not Delete
                    $scope.$emit('TealiumWebAnalytic', {"key": "NoResultsFound"});
                    return false;
                }
                else {
                    $scope.noResultMsg = errors.getErrorMessage('009');
                }
            });
        };

        $('#drugSearchInput').keydown(function(e) {

            if($('.dropdown-menu').is(':visible')) {


                var menu = $('.dropdown-menu');
                var active = menu.find('.active');
                var height = active.outerHeight(); //Height of <li>
                var top = menu.scrollTop(); //Current top of scroll window
                var menuHeight = menu[0].scrollHeight; //Full height of <ul>

                //Up
                if(e.keyCode == 38) {
                    if(top != 0) {
                        //All but top item goes up
                        menu.scrollTop(top - height);
                    } else {
                        //Top item - go to bottom of menu
                        menu.scrollTop(menuHeight + height);
                    }
                }
                //Down
                if(e.keyCode == 40) {
                    //window.alert(menuHeight - height);
                    var nextHeight = top + height; //Next scrollTop height
                    var maxHeight = menuHeight - height; //Max scrollTop height

                    if(nextHeight <= maxHeight) {
                        //All but bottom item goes down
                        menu.scrollTop(top + height);
                    } else {
                        //Bottom item - go to top of menu
                        menu.scrollTop(0);
                    }
                }
            }
        });



        $scope.removeDrug = function () {
            $scope.drugSearched = '';
            reset();
        };

        $scope.selectDrug = function ($item) {
            drugSelect($item);
        };

        function reset() {
            $scope.noResultMsg = '';
            $scope.showLoading = false;
            $scope.drugSelect = '';
            $scope.enableSearch = false;
            $scope.drugDetails = '';
            popOverHandler("#errorDosage", 'hide');
            updateErrorMessage();
            savedKey = '';
            $scope.noDosage='';
        }

        $scope.continueBtn = function (path) {
            //new search
            saveSearch();
            if (!$scope.isModalActive) {
                help.go(path);
            } else {
                // for new search modal
                $scope.submit();
            }
        };

        function saveSearch() {
            userSessionData.setSelectedUserName($scope.memberSelect);
            userSessionData.setSelectedDrugName($scope.drugSelect);
            userSessionData.setSelectedPharmacy($scope.userInfo.selectedPharmacy);
            userSessionData.setSelectedDosage($scope.drugDetails);
            userSessionData.setSelectedDrugDetails($scope.drugDetails);
        }

        function successAuthenticate(data) {
            // If true success
            if (data.response && data.response.header.statusCode === '0000') {
                activeModel.authenticated = true;
                activeModel.memberList = drugSearchHelper.getMemberList(data.response.detail.memberInfo);
                $scope.memberList = activeModel.memberList;
                drugSearchHelper.getMemberDetails(data.response.detail.memberInfo).then(function (memberInfo) {
                    userSessionData.setLoggedInUserInfo(memberInfo);
                    setToView();
                });
            } else {
                errorAuthenticate(data);
            }
        }

        function setToView() {
            var bestPharmaciesPzn=false;
            personalization.getPersonlizationContent().then(function(personlizationContent){
                if (personlizationContent  && personlizationContent[1001]) {
                    activeModel.bestPharmaciesPzn=personlizationContent["1001"]['resourceVisibleIndicator'] ;
                }
            });
            $scope.memberList.forEach(function (val, index) {
                if (val.selected) {
                    $scope.memberSelect = $scope.memberList[index];
                    activeModel.memberSelect = $scope.memberSelect;
                }
            });
            var userInfo = angular.copy(userSessionData.getLoggedInUserInfo());
            $scope.userInfo = {};
            if (userInfo) {
                $scope.userInfo.selectedPharmacy = userInfo.preferredPharmacy || userInfo.mchoicePharmacy
                    || userInfo.retailPharmacy || userInfo.nearestPharmacy || userInfo.selectedPharmacy;
                if (userInfo.selectedPharmacy) {
                    if (!userInfo.hasSavedPharmacy) {
                        $scope.noPharmacy = $scope.FastContentService.drugSearch.toolTip.noSavedPharmacy;
                        popOverHandler(".errorPharmacy", 'show');
                    }
                }
                else {
                    $scope.noPharmacy = $scope.FastContentService.drugSearch.toolTip.noPharmacy;
                    popOverHandler(".errorPharmacy", 'show');
                }
            }

            if ($scope.newSearch) {
                $scope.showHeader = false;
                reset();
            }
        }

        function editSearch(data) {
            //member
            $scope.memberList.forEach(function (val, index) {
                if (val.internalID == data.userInfoEdit.userName.internalID) {
                    $scope.memberSelect = $scope.memberList[index];
                }
            });
            $scope.showHeader = false;
            $scope.enableSearch = false;
            $scope.userInfo = {};
            //pharmacy
            $scope.userInfo.selectedPharmacy = data.userInfoEdit.pharmacy;
            $scope.drugSelect = data.userInfoEdit.drugDetails.displayText;

            //dosage
            $scope.drugDetails = data.userInfoEdit.drugDetails;
            if ($scope.drugSelect) {
                $scope.drugSearched = $filter('camelCase')($scope.drugSelect);
            }

            $scope.updateCriteria = function () {
                if (data.pastSearchIndex >= 0) {
                    var pastSearch = {};
                    pastSearch.userName = $scope.memberSelect;
                    pastSearch.pharmacy = $scope.userInfo.selectedPharmacy;
                    pastSearch.dosage = $scope.drugDetails;
                    pastSearch.drugName = $scope.drugSelect;
                    pastSearch.drugDetails = $scope.drugDetails;
                    $scope.submit(pastSearch, data.pastSearchIndex);
                }
                else {
                    saveSearch();
                    $scope.submit();
                }
            };
        }

        function drugSelect($item) {
            var drugData = drugSearchHelper.getDrugData($item);
            $scope.drugSelect = drugData.drugName;
            $scope.drugDetails = drugData.drugDetails;
            /*Localytics do not delete*/

            try{
                localytics.ltOnScreenLoad("Search|Filter");
            }
            catch(e){}

            if ($scope.drugDetails.dosageSelected.hasCommon) {
                if ($scope.userInfo.selectedPharmacy) {
                    if($scope.userInfo.selectedPharmacy.pharmacyId && $scope.userInfo.selectedPharmacy.pharmacyName)
                    {
                        $scope.enableSearch = true;
                    }
                    else
                    {
                        $scope.enableSearch = false;
                    }

                }
            }
            else if ($scope.drugDetails.isSolid) {
                $scope.noDosage = $scope.FastContentService.drugSearch.toolTip.noDosage;
                angular.element(document).off("click");
                angular.element(window.parent.document).off("click");
                popOverHandler("#errorDosage", 'show');
            } else {
                updateErrorMessage(errors.getErrorMessage('018'));
            }
        }

        function popOverHandler(element, event) {
            help.popOverHandler(element, event);
        }

        function errorAuthenticate(data) {
            if (data && data.response) {
                // If Member Not Found
                if (data.response.header.statusCode === '8002') {
                    updateErrorMessage(errors.getErrorMessage('012'));

                } else {
                    updateErrorMessage(errors.getErrorMessage('009'));
                }

                // if 500 error or some other kind of error
            } else {
                updateErrorMessage(errors.getErrorMessage('009'));
            }
        }

        function updateErrorMessage(errorMessage) {
            if (errorMessage) {
                $scope.error.message = errorMessage;
            } else {
                $scope.error.message = '';
            }
        }

        $scope.editDosage = function () {
            updateErrorMessage();
            var drugDetails=angular.copy($scope.drugDetails);
            var modalProperties = {
                "templateUrl": 'modules/dosage/views/dosage.html',
                "size": 'lg',
                "windowClass": "dosageModal",
                "data": {
                    "drugDetails": drugDetails
                }
            };
            var staticModalProperties = {
                "callback": selectedDosage
            };

            CoreCommonsModal.generalModal(modalProperties, staticModalProperties);
        };

        function selectedDosage(data) {
            if (data) {
                $scope.drugDetails = data;
                if (data.dosageSelected && data.dosageSelected.isCustom) {
                    $scope.dosageLabel = data.dosageSelected.dosageLabel;
                    popOverHandler("#errorDosage", 'hide');
                    if ($scope.userInfo.selectedPharmacy) {
                        if($scope.userInfo.selectedPharmacy.pharmacyId && $scope.userInfo.selectedPharmacy.pharmacyName)
                        {
                            $scope.enableSearch = true;
                        }
                        else
                        {
                            $scope.enableSearch = false;
                        }

                    }
                }
            }
            enableUpdate();
        }

        $scope.selectedPharmacy = function (data) {
            if (data) {
                drugSearchHelper.getPharmacyDetails(data).then(function(success){
                        $scope.userInfo.selectedPharmacy =success;
                    },
                function(){
                    $scope.userInfo.selectedPharmacy ="";
                });
                if ($scope.drugDetails && $scope.drugDetails.dosageSelected) {
                    if ($scope.drugDetails.dosageSelected.hasCommon || $scope.drugDetails.dosageSelected.isCustom) {
                        if ($scope.userInfo.selectedPharmacy) {
                            if($scope.userInfo.selectedPharmacy.pharmacyId && $scope.userInfo.selectedPharmacy.pharmacyName)
                            {
                                $scope.enableSearch = true;
                            }
                            else
                            {
                                $scope.enableSearch = false;
                            }

                        }
                    }
                }
                $scope.noPharmacy='';
                popOverHandler(".errorPharmacy", 'hide');
                enableUpdate();
            }
        };

        $scope.selectMember = function (member) {
            $scope.memberSelect = member;
            activeModel.memberSelect = $scope.memberSelect;
            enableUpdate();
        };

//          WebAnalytics code : Do not Delete
        if (typeof($scope.wtEventHandler) !== 'function') {
            $scope.wtEventHandler = function (key) {
//              webAnalytics.wtEvent(key);
                $scope.$emit('TealiumWebAnalytic', {"key": key});
            };
        }
//          WebAnalytics code : Do not Delete

        $scope.pharmacyLocator = function () {
            pharmacyLocatorHelper.openPharmacyLocator($scope.selectedPharmacy);
        };

        function enableUpdate() {
            if ($scope.editCriteriaData) {
                $scope.enableSearch = true;
            }
        }

        $scope.clearErroMsg = function () {
            $scope.noResultMsg = '';
        }

        help.emit('utag_loaded', function (event) {
            $scope.$emit('TealiumWebAnalytic', {"key": "TealiumLoaded"});
        });
    }
})();