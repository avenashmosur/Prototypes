/**
 * Created by Z179603 on 4/9/2015.
 */
(function () {
    'use strict';

    checkDrugCostFactory.factory('drugSearchHelper', drugSearchHelper);

    drugSearchHelper.$inject = ['activeModel', 'help', 'cdcServices', '$q', 'CommonDrugService', '$filter'];

    function drugSearchHelper(activeModel, help, cdcServices, $q, CommonDrugService, $filter) {

        var memberDetail = {
            "memberAddress": {},
            "selectedPharmacy": "",
            "hasSavedPharmacy": "true"
        }, responseList;
        /**
         * Checking for authentication
         * @returns {*}
         */
        var checkAuthentication = function () {
            return cdcServices.getMemberInfoByToken();
        };
        /**
         * Getting Pharmacy Details
         * @param pharmacyInfo
         * @returns {{}}
         */
        var getPharmacyDetails = function (pharmacyInfo) {
            var pharmacyDetails = {}, deferred = $q.defer();
            if (pharmacyInfo) {
                var getPharmacyPhone = function (pharmacyDetails) {
                    var params = {}, deferred = $q.defer();
                    params['city'] = pharmacyDetails.city;
                    params['state'] = pharmacyDetails.state;
                    params['zipCode'] = pharmacyDetails.zipCode;
                    getPharmacyList(params).then(function (data) {
                        if (data.response && data.response.header.statusCode === '0000') {
                            if (data.response.details.pharmacyList) {
                                var pharmacy = help.convertToArray(data.response.details.pharmacyList.pharmacy);
                                for (var i = 0; i < pharmacy.length; i++) {
                                    if (pharmacy[i].pharmacyNumber === pharmacyDetails.pharmacyId || pharmacy[i].pharmacyId === pharmacyDetails.pharmacyId) {
                                        pharmacyDetails.phoneNumber = pharmacy[i].phoneNumber;
                                        break;
                                    }
                                }
                            }
                        }
                        deferred.resolve(pharmacyDetails);
                    }, function () {
                        deferred.resolve(pharmacyDetails);
                    });
                    return deferred.promise;
                };
                pharmacyDetails.pharmacyName = pharmacyInfo.pharmacyName.__cdata;
                pharmacyDetails.address = pharmacyInfo.address.__cdata;
                pharmacyDetails.city = pharmacyInfo.city.__cdata;
                pharmacyDetails.state = pharmacyInfo.state;
                pharmacyDetails.zipCode = pharmacyInfo.zipCode;
                pharmacyDetails.pharmacyId = pharmacyInfo.pharmacyId || pharmacyInfo.pharmacyNumber;
                pharmacyDetails.phoneNumber = pharmacyInfo.phoneNumber;
                if (!pharmacyInfo.phoneNumber) {
                    getPharmacyPhone(pharmacyDetails).then(function (data) {
                        deferred.resolve(data);
                    });
                }
                else {
                    deferred.resolve(pharmacyDetails);
                }
            }
            return deferred.promise;
        };
        /**
         * Getting pharmacy list
         * @param params
         */
        var getPharmacyList = function (params) {
            return cdcServices.getPharmacyLocator(params);
        };
        /**
         * Getting details of members
         * @param memberInfo
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
        var getMemberDetails = function (memberInfo) {
            var deferred = $q.defer();
            if (!memberDetail.length) {
                memberDetail.memberAddress.line1 = memberInfo.addresses.line1.__cdata;
                memberDetail.memberAddress.city = memberInfo.addresses.city;
                memberDetail.memberAddress.state = memberInfo.addresses.state;
                memberDetail.memberAddress.zipCode = memberInfo.addresses.zipCode;
                memberDetail.primary = memberInfo.primary;
                memberDetail.extranetUsr = memberInfo.extranetUsr && memberInfo.extranetUsr === 'true' ? true : false;
                if (memberInfo.internalParams && memberInfo.internalParams.personalizationId) {
                    memberDetail.personalizationId = memberInfo.internalParams.personalizationId;
                }
                if (memberInfo.preferredPharmacy) {
                    getPharmacyDetails(memberInfo.preferredPharmacy).then(function (data) {
                        memberDetail.preferredPharmacy = data;
                        memberDetail.selectedPharmacy = memberDetail.preferredPharmacy;
                        deferred.resolve(memberDetail);
                    }, function () {
                        deferred.resolve(memberDetail);
                    });
                } else if (memberInfo.mchoicePharmacy) {
                    getPharmacyDetails(memberInfo.mchoicePharmacy).then(function (data) {
                        memberDetail.mchoicePharmacy = data;
                        memberDetail.selectedPharmacy = memberDetail.mchoicePharmacy;
                        deferred.resolve(memberDetail);
                    }, function () {
                        deferred.resolve(memberDetail);
                    });
                } else if (memberInfo.retailPharmacy) {
                    getPharmacyDetails(memberInfo.retailPharmacy).then(function (data) {
                        memberDetail.retailPharmacy = data;
                        memberDetail.selectedPharmacy = memberDetail.retailPharmacy;
                        deferred.resolve(memberDetail);
                    }, function () {
                        deferred.resolve(memberDetail);
                    });
                } else if (memberDetail.memberAddress.zipCode) {
                    memberDetail.hasSavedPharmacy = false;
                    var params = {};
                    params['zipCode'] = memberDetail.memberAddress.zipCode;
                    getPharmacyList(params).then(function (data) {
                        if (data.response && data.response.header.statusCode === '0000') {
                            if (data.response.details.pharmacyList) {
                                var pharmacy = help.convertToArray(data.response.details.pharmacyList.pharmacy);
                                getPharmacyDetails(pharmacy[0]).then(function(data){
                                    memberDetail.nearestPharmacy =data;
                                    memberDetail.selectedPharmacy = memberDetail.nearestPharmacy;
                                });
                            }
                        }
                        deferred.resolve(memberDetail);
                    }, function () {
                        deferred.resolve(memberDetail);
                    });
                }
                else {
                    deferred.resolve(memberDetail);
                }
            } else {
                deferred.resolve(memberDetail);
            }
            return deferred.promise;
        };

        /**
         * Check for mail or retail
         * @param drug
         * @param type
         * @returns {*|Number}
         */
        var isMailOrRetail = function(drug, type) {
            var drugType = drug[type];
            if(drugType && drugType.ndcId){
                return parseInt(drugType.ndcId) > 0;
            }
            return false;
        }

        /**
         * Checking for common dosage
         * @param drug
         * @param type
         * @returns {*|Number|string|boolean}
         */
        function hasCommonDosageProperty(drug, type) {
            var drugType = drug[type];
            return (drugType && drugType.ndcId && parseInt(drugType.ndcId)
            && drugType.commonDispensedQuantity && parseFloat(drugType.commonDispensedQuantity) > 0
            && drugType.commonDaysSupply && parseInt(drugType.commonDaysSupply) > 0);
        }

        /**
         * Checking for common dosage
         * @param drugDetails
         * @param drug
         */
        function hasCommonDosage(drug, drugDetails) {
            drug.isMail = isMailOrRetail(drug, "mailDrug");
            drug.isRetail = isMailOrRetail(drug, "retailDrug");

            if(drugDetails.isSolid){
                if (drug.isMail && drug.isRetail) {
                drugDetails.dosageSelected.hasCommon = hasCommonDosageProperty(drug, "mailDrug") && hasCommonDosageProperty(drug, "retailDrug");
                }
                else if (drug.isMail) {
                    drugDetails.dosageSelected.hasCommon = hasCommonDosageProperty(drug, "mailDrug");
                }
                else if (drug.isRetail) {
                    drugDetails.dosageSelected.hasCommon = hasCommonDosageProperty(drug, "retailDrug");
                }
            }
        }

        /**
         * Getting data of searched drug
         * @param drug
         * @returns {{}}
         */
        var getDrugData = function (drug) {
            var drugData = {}, genericInfo;
            if (drug) {
                var genericName = getGenericName(drug);
                if (genericName) {
                    angular.forEach(responseList, function (storedNameValue) {
                        if (getDrugName(storedNameValue).toLowerCase() == genericName.toLowerCase()) {
                            genericInfo = storedNameValue;
                        }
                    });
                }

                var drugDetails = drug;
                drugDetails.isSolid = (drug.drugForm.__cdata.toLowerCase().indexOf('tablet') !== -1 || drug.drugForm.__cdata.toLowerCase().indexOf('capsule') !== -1);
                if (!drugDetails["dosageSelected"]) {
                    drugDetails["dosageSelected"] = {
                        "hasCommon": true
                    };
                    hasCommonDosage(drug, drugDetails);
                    if (drugDetails.hasCommon && genericInfo) {
                        hasCommonDosage(genericInfo, drugDetails);
                    }
                }
                
                drugData.drugName = getDrugName(drug);
                drugData.drugDetails = drugDetails;
            }

            return drugData;
        };

        /**
         * getting the searched drug name
         * @param drug
         * @returns {string}
         */
        function getDrugName(drug) {
            return drug.drugName.__cdata + ' ' + drug.drugStrength.__cdata + ' ' + drug.drugForm.__cdata;
        }

        /**
         * getting the searched drug name
         * @param drug
         * @returns {string}
         */
        function getGenericName(drug) {
            if (drug.genericName) {
                return drug.genericName.__cdata + ' ' + drug.drugStrength.__cdata + ' ' + drug.drugForm.__cdata;
            }
        }

        /**
         * getting member list
         * @param memberParam
         * @returns {Array}
         */
        var getMemberList = function (memberParam) {
            var memberList = [];
            var memberInfo = memberParam;
            if (memberInfo) {
                memberInfo.dateOfBirth = help.getDate(memberInfo.dateOfBirth);
                memberInfo.selected = true;
                memberInfo.sortKey = memberInfo.firstName + memberInfo.lastName;
                memberInfo.isVaccineEligibile = isVaccineEligibile(memberInfo);
                memberInfo.isBestPharmacy=isBestPharmacy(memberInfo);
                memberList.push(memberInfo);

                if (memberInfo.family) {
                    if (memberInfo.family.dependentList && memberInfo.family.dependentList.memberInfo) {
                        var memberInfoList = help.convertToArray(memberInfo.family.dependentList.memberInfo);
                        angular.forEach(memberInfoList, (function (element) {
                            element.isVaccineEligibile = isVaccineEligibile(element);
                            element.isBestPharmacy=isBestPharmacy(element);
                            element.dateOfBirth = help.getDate(element.dateOfBirth);
                            element.sortKey = (element.firstName + element.lastName).toLowerCase();
                            memberList.push(element);
                        }));
                        help.sortList(memberList, 'sortKey');
                        memberList.sort(function (a, b) {
                            return a.dateOfBirth - b.dateOfBirth;
                        });
                    }
                }
            }

            return memberList;
        };
        /**
         * Searching with keyword
         * @param fullList
         * @param currentSearchkeyword
         * @returns {Array}
         */
        var extractResultFromKeyWord = function (fullList, currentSearchkeyword) {
            var tempNamesArray = [];
            angular.forEach(fullList, function (storedNameValue) {
                var inpTxt = getDrugName(storedNameValue);
                if (inpTxt.toLowerCase().indexOf(currentSearchkeyword.toLowerCase()) == 0) {
                    storedNameValue.sortKey = (storedNameValue.drugName.__cdata + " " + storedNameValue.drugForm.__cdata + " " + storedNameValue.drugStrength.__cdata).toLowerCase();
                    storedNameValue.displayText = $filter('camelCase')(storedNameValue.drugName.__cdata + ' ' + storedNameValue.drugStrength.__cdata + ' ' + storedNameValue.drugForm.__cdata);
                    tempNamesArray.push(storedNameValue);
                }
            });
            help.sortList(tempNamesArray, "sortKey");
            return tempNamesArray;
        };

        /**
         * Search for a drug
         * @param currentSearchkeyword
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
        var drugSearch = function (currentSearchkeyword) {
            var deferred = $q.defer(), response,
                savedKey = currentSearchkeyword.toLowerCase(),
                searchResultFromStorage;

            var sessionStoredData = help.getSessionStorage(activeModel.tokenId);
            if (sessionStoredData) {
                searchResultFromStorage = sessionStoredData['drugSearchResultCache'];
            }

            if (searchResultFromStorage && searchResultFromStorage[savedKey]) {
                responseList = searchResultFromStorage[savedKey];
                response = extractResultFromKeyWord(responseList, savedKey);
                deferred.resolve(response);
            } else {
                CommonDrugService.drugDetails(savedKey, activeModel.memberSelect.cardholderInternalID,true).then(
                    function (data) {
                        if (data && data.response && data.response.header.statusCode === '2020') {
                            deferred.reject(data);
                        } else {
                            responseList = data;
                            response = extractResultFromKeyWord(data, currentSearchkeyword);
                            deferred.resolve(response);
                        }
                    }, function (data) {
                        deferred.reject(data);
                    });
            }
            return deferred.promise;
        };

        /**
         * Check for availability of vaccine
         * @param data
         * @returns {boolean}
         */
        function isVaccineEligibile(data) {
            var isVaccineEligibile = false;
            if (data.eligibility && data.eligibility.benefitPlanList && data.eligibility.benefitPlanList.benefitPlan) {
                angular.forEach(data.eligibility.benefitPlanList.benefitPlan, function (benefitPlan) {
                    if (!isVaccineEligibile && benefitPlan.deliverySystem === "3") {
                        isVaccineEligibile = benefitPlan.vaccineEligible;
                    }
                });
            }
            return isVaccineEligibile;
        }

        /**
         * Check for availability of best pharmacy in pharmacy Search
         * @param data
         * @returns {boolean}
         */
        function isBestPharmacy(data) {
            var isBestPharmacy = false;
            if (data.eligibility && data.eligibility.benefitPlanList && data.eligibility.benefitPlanList.benefitPlan) {
                angular.forEach(data.eligibility.benefitPlanList.benefitPlan, function (benefitPlan) {
                    if (!isBestPharmacy  && benefitPlan.deliverySystem === "3") {
                        isBestPharmacy = (benefitPlan.mandatoryRetail90DaySupplyProgram && benefitPlan.mandatoryRetail90DaySupplyProgram==="true")
                        || (benefitPlan.retail90DaySupplyProgram && benefitPlan.retail90DaySupplyProgram==="true")
                        || (benefitPlan.maintenanceChoiceIndicator && benefitPlan.maintenanceChoiceIndicator==="true")  ;
                    }
                });
            }
            return isBestPharmacy;
        }

        return {
            "checkAuthentication": checkAuthentication,
            "getPharmacyDetails": getPharmacyDetails,
            "getMemberDetails": getMemberDetails,
            "getDrugData": getDrugData,
            "getMemberList": getMemberList,
            "drugSearch": drugSearch,
            "isMailOrRetail":isMailOrRetail
        };
    }
})();