/**
 * Created by Z179603 on 5/15/2015.
 */
checkDrugCostFactory.factory('CommonDrugService', ['activeModel', 'cdcServices', '$q', 'drugCostHelper', 'help',
    function (activeModel, CommonDrugServiceApi, $q, drugCostHelper, commonHelper) {
        var help = {
            drugPriceDetails: function (request) {
                var deferred = $q.defer();
                CommonDrugServiceApi.getDrugPrice(request).then(
                    function (response) {
                        deferred.resolve(response);
                    }, function () {
                        deferred.reject('Error');
                    }
                );
                return deferred.promise;
            },
            /**
             *
             * @param reqArray
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            currentDrugPriceDetailsChaining:function(reqArray){
                /*Number of times a functions needs to call*/
                var deferred = $q.defer();
                var priceRequestFunctionArray = [];
                angular.forEach(reqArray, function(valueArray) {
                    var newFormattedRequest = angular.copy(valueArray.param);
                    delete newFormattedRequest.data;
                    priceRequestFunctionArray.push(help.drugPriceDetails(newFormattedRequest));
                });
                $q.all(priceRequestFunctionArray).then(function(response) {
                    // Success callback where value is an array containing the success values
                    if(response.length==1){
                        if(response && response[0]&& response[0].response && response[0].response.header.statusCode ==='0000' && response[0].response.detail && response[0].response.detail.costDetailsList && response[0].response.detail.costDetailsList.costDetails){
                            deferred.resolve(response[0]);
                        }else{
                            deferred.reject(response);
                        }

                    }else{
                        if(response[0].response.header.statusCode ==='0000' && response[0].response.detail && response[0].response.detail.costDetailsList && response[0].response.detail.costDetailsList.costDetails
                        && response[1].response.header.statusCode ==='0000' && response[1].response.detail && response[1].response.detail.costDetailsList && response[1].response.detail.costDetailsList.costDetails){
                            var formattedResponse=angular.copy(response[0]);
                            angular.forEach(response[1].response.detail.costDetailsList.costDetails,function(eachResponse,index){
                                formattedResponse.response.detail.costDetailsList.costDetails[index].retailPrice=angular.copy(eachResponse.retailPrice);
                            });
                            //console.log(formattedResponse);
                            deferred.resolve(formattedResponse);
                        }else{
                            deferred.reject(response[0]);
                        }

                    }

                }, function(reason) {
                    // Error callback where reason is the value of the first rejected promise
                    deferred.reject('Error');
                });
                return deferred.promise;
            },
            /**
             * details of presently searched drug
             * @param request
             * @param fromRequest
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            currentDrugPriceDetails: function (request, fromRequest) {
                var deferred=$q.defer();
                var drugName;
                if((typeof request.drugName) ==="string"){
                    var drugNameArray=request.drugName.split(" ");
                    drugName=drugNameArray[0];
                }else{
                    drugName=getTADDrugName(request.drugName);
                }

                var memberId=request.userName.internalID;
                help.drugDetails(drugName,memberId).then(function(drugDetail){
                    var formattedRequestArray = drugCostHelper.formatDrugPriceRequest(request, fromRequest);
                    help.currentDrugPriceDetailsChaining(formattedRequestArray).then(
                        function (response) {
                            if (response.response.header.statusCode === '0000' && response.response.detail && response.response.detail.costDetailsList && response.response.detail.costDetailsList.costDetails) {
                                var formattedResponse = drugCostHelper.formatDrugCostResponse(response.response.detail.costDetailsList.costDetails, formattedRequestArray[0].param, fromRequest);
                                var memberID = (request.userName && request.userName.internalID) || (request.memberSelect && request.memberSelect.internalID);
                                // to enable/disable "Request New Prescription"
                                var ndcId=request.drugDetails.retailDrug && request.drugDetails.retailDrug.ndcId ||  request.drugDetails.mailDrug && request.drugDetails.mailDrug.ndcId;
                                help.drugProperties(memberID, formattedResponse, drugDetail).then(
                                    function (data) {
                                        formattedResponse['drugPropertiesList']=data;
                                        deferred.resolve(formattedResponse);
                                    }, function () {
                                        //resolve even if this drug properties api fails.
                                        deferred.resolve(formattedResponse);
                                    }
                                );
                            } else {
                                deferred.reject(response.response);
                            }

                        }, function (error) {
                            deferred.reject(error);
                        }
                    );
                },function(error){
                    deferred.reject(error);
                });

                return deferred.promise;

            },
            /**
             * getting name of a pharmacy
             * @returns {string}
             */
            getPharmacyName: function () {
                var pharmacy = activeModel.pharmacySelect.pharmacyName.__cdata + ' / ' + activeModel.pharmacySelect.city.__cdata + ' / ' + activeModel.pharmacySelect.state + ' / ' + activeModel.pharmacySelect.zipCode;
                return pharmacy;
            },
            /**
             * Details of a drug
             * @param drugName
             * @param memberId
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            drugDetails: function (drugName, memberId,hideloader) {
                var deferred = $q.defer();
                var params = {};
                params['drugName'] = drugName;
                params['memberID'] = memberId;
                CommonDrugServiceApi.getDrugDetails(params,hideloader).then(
                    function (data) {
                        var drugSearchListRaw={};
                        if(data && data.response && data.response.header.statusCode==='0000'){
                            drugSearchListRaw = commonHelper.convertToArray(data.response.detail.drugDetailsList.drug);
                            if (typeof(Storage) !== "undefined") {
                                var searchResultFromStorage = {};
                                var sessionStoredData = commonHelper.getSessionStorage(activeModel.tokenId);
                                if (sessionStoredData) {
                                    searchResultFromStorage = sessionStoredData['drugSearchResultCache'];
                                    if (searchResultFromStorage) {
                                        searchResultFromStorage[drugName] = drugSearchListRaw;
                                    }
                                } else {
                                    sessionStoredData = {};
                                    searchResultFromStorage[drugName] = drugSearchListRaw;
                                }
                                sessionStoredData['drugSearchResultCache'] = searchResultFromStorage;
                                commonHelper.setSessionStorage(activeModel.tokenId, sessionStoredData);
                            }
                            deferred.resolve(drugSearchListRaw);
                        }
                        else{
                            deferred.reject(data);
                        }
                    }, function () {
                        deferred.reject('Error');
                    }
                );
                return deferred.promise;
            },
            /**
             * Member information
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            memberInformation: function () {
                var deferred = $q.defer();
                var params = {};
                CommonDrugServiceApi.getMemberInfoByToken(request).then(
                    function (response) {
                        deferred.resolve(response);
                    }, function () {
                        deferred.reject('Error');
                    }
                );
                return deferred.promise;
            },
            /**
             *
             * @param request
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            getSTCOBClaimDetails: function (request,costDetails) {
                var deferred = $q.defer();
                var reqArray=drugCostHelper.formatGetClaimRequest(request,costDetails);
                var claimRequestFunctionArray=[];
                angular.forEach(reqArray, function(value) {
                   claimRequestFunctionArray.push(CommonDrugServiceApi.getClaimDetails(value));
                });
                $q.all(claimRequestFunctionArray).then(function(response) {
                    var responseArray=drugCostHelper.formatGetClaimDetailResponse(response);
                 deferred.resolve(responseArray);
                }, function(reason) {
                    // Error callback where reason is the value of the first rejected promise
                    deferred.reject(reason);
                });

                return deferred.promise;
            },
            /**
             * getting claim details
             * @param request
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            getClaimDetails: function (request) {
                var formattedRequest = drugCostHelper.formatGetClaimRequest(request);
                var deferred = $q.defer();
                help.getSTCOBClaimDetails(formattedRequest).then(function (response) {
                    var formattedResponse = drugCostHelper.formatGetClaimDetailResponse(response);
                    deferred.resolve(formattedResponse);
                }, function (error) {
                    deferred.reject('Error');

                });
                return deferred.promise;
            }
            ,
            /**
             * Price details of previous searched drug
             * @param request
             * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
             */
            pastDrugPriceDetails: function (request) {
                ////daysSupply=30&dispenseWritten=0&drugNDCID=777310402quantity=180&serviceName=drugPrice
                // var formattedRequest=drugCostHelper.formatPastDrugPriceRequest(request);
                var deferred = $q.defer();
                drugCostHelper.pastDrugPriceDetails(request).then(function (response) {
                    //var formattedResponse = drugCostHelper.formatDrugCostResponse(response.response.detail.costDetailsList.costDetails,request);
                    deferred.resolve(response);
                }, function (error) {
                    deferred.reject('Error');
                });
                return deferred.promise;
            },

            drugProperties: function (memberId, formattedResponse, drugDetail) {
                var deferred = $q.defer(), ndcIdList = [];
                var getDrugDetailForCart = function (detailObj, drugType) {
                    var drugDetailType = detailObj[drugType];
                    if (drugDetailType['mailPricePerDay'] && !isNaN(drugDetailType['mailPricePerDay'])) {
                        ndcIdList.push(drugDetailType.ndcId);
                        angular.forEach(drugDetail, function (val) {
                            if (val.mailDrug && ((val.retailDrug && val.retailDrug.ndcId === drugDetailType.ndcId) ||
                                (val.mailDrug.ndcId === drugDetailType.ndcId))) {
                                formattedResponse[drugType]['drugDetailForCart'] = angular.copy(val.mailDrug);
                                var drugDetailForCart = formattedResponse[drugType]['drugDetailForCart'];
                                drugDetailForCart['ndcId'] = drugDetailType.ndcId;
                                drugDetailForCart['commonDaysSupply'] = formattedResponse.dataInd.mailDaysSupply;
                                drugDetailForCart['commonDispensedQuantity'] = formattedResponse.dataInd.mailQuantity;
                                drugDetailForCart['memberId'] = memberId;
                            }
                        });
                    }
                };
                if (formattedResponse['brand']) {
                    getDrugDetailForCart(formattedResponse, 'brand');
                }
                if (formattedResponse['generic']) {
                    getDrugDetailForCart(formattedResponse, 'generic');
                }

                if(ndcIdList.length){
                    var params = {'memberID': memberId},
                        drugList = {
                            "request": {
                                "ndcIdList": {
                                    "ndcId": ndcIdList
                                }
                            }
                        };
                    CommonDrugServiceApi.getDrugProperties(params, drugList).then(
                        function (data) {
                            if (data && data.response.header.statusCode === '0000' && data.response.detail && data.response.detail.drugPropertiesList
                                && data.response.detail.drugPropertiesList.drugProperties) {
                                deferred.resolve(commonHelper.convertToArray(data.response.detail.drugPropertiesList.drugProperties));
                            }
                            else {
                                deferred.reject(data);
                            }
                        }, function () {
                            deferred.reject('Error');
                        }
                    );
                }
                else{
                    deferred.resolve();
                }

                return deferred.promise;
            }

        };

        /**
         * getting additional drug information
         * @param requestObj
         * @param userObj
         * @param pharmacyId
         * @returns {*|l.promise|{then, catch, finally}|d.promise|Function|promise}
         */
        help.getTADDrugInformation = function(requestObj,userObj,pharmacyId) {
            var deferred = $q.defer();
            var param={
                operationName:"getDrugAlternative"
            };
            CommonDrugServiceApi.getDrugAlternatives(param,drugCostHelper.getTADDrugRequestObject(requestObj,userObj)).then(function(response) {
                var drugAlternativesResponseArray=[];
                if(response.response && response.response.detail && response.response.detail.tadResponse &&
                    response.response.detail.tadResponse.drugClassifications && response.response.detail.tadResponse.drugClassifications){
                    var indicatorId=response.response.detail.tadResponse.originalDrugClassificationId;
                    var classificationResponse=[];
                    var alternativeresponseArray=[];
                    if(Array.isArray(response.response.detail.tadResponse.drugClassifications)){
                        classificationResponse=response.response.detail.tadResponse.drugClassifications;
                    }else{
                        classificationResponse.push(response.response.detail.tadResponse.drugClassifications);
                    }
                    if(classificationResponse.length>0){
                        angular.forEach(classificationResponse,function(eachArray){
                            if(eachArray.classificationId===indicatorId && eachArray.drugAlternatives){
                                if(Array.isArray(eachArray.drugAlternatives)){
                                    alternativeResponseArray=eachArray.drugAlternatives;
                                }else{
                                    alternativeResponseArray.push(eachArray.drugAlternatives);
                                }
                            }
                        });
                    }
                    if(alternativeResponseArray.length >0){
                        angular.forEach(alternativeResponseArray,function(resp){
                            var drugDetails;
                            if(resp && resp.drugName /*&& resp.drugStrength && resp.drugForm*/){
                                var drugDetails= resp.drugName/*+" "+resp.drugStrength+""+resp.drugForm*/;
                                drugDetails=drugDetails.toUpperCase();
                                drugAlternativesResponseArray.push(drugDetails);
                            };
                        });
                    }
                }
                if(response.response && response.response.header.statusCode ==='0000'){
                    var drugName=getTADDrugName(requestObj.drugNames);
                    var memberId=userObj.internalID;
                    help.drugDetails(drugName,memberId).then(function(reason){
                      drugCostHelper.getTADPriceInformation(requestObj,pharmacyId,userObj,drugAlternativesResponseArray).then(function(response) {
                                deferred.resolve(response);
                            }, function(error) {
                                deferred.reject(error);
                            });
                    },function(error){
                        deferred.reject(error);
                    });
                }else{
                    deferred.reject('Error');
                }
            }, function(error) {
                deferred.reject("Error");
            });
            return deferred.promise;
        };

        var getTADDrugName= function(obj){
            var drugName;
            var namesArray=obj.generic;
            if(namesArray && namesArray.length>0){
                drugName=namesArray[0].drugName && namesArray[0].drugName.__cdata;
            }
            return drugName;
        };

        return help;

    }]);
