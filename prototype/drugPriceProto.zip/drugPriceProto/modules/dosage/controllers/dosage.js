'use strict';

checkDrugCostController.controller('doseController', ['$scope', 'activeModel', 'help', 'errors', 'userSessionData', function ($scope, activeModel, help, errors, userSessionData) {

    // INITIALIZATION
    var qtyLabel = {
        "1": "once",
        "2": "twice",
        "3": "thrice"
    };
    $scope.edited = false;
    $scope.error = {};
    $scope.customDoseSelected = {};
    $scope.pageClass = "dosePage";
    $scope.radioDosageSelected = 'common';
    if (help.IEVersion() == 8) {

        document.getElementById("doseCommon").checked = true;
        document.getElementById("doseCustom").checked = false;

        $('#doseCommonlabel').css({"background-color": "#231F20" , "border": "2px solid"});

    }

    $scope.toggleDoseCheck=function() {
        if (help.IEVersion()) {

            $scope.customDoseSelected = {};
            $scope.customDoseSelected.timeSelect = $scope.customDose.timePeriod[0];

            if ($scope.radioDosageSelected == "common") {


                $scope.radioDosageSelected = "custom";
                $scope.edited = true;

                document.getElementById("doseCommon").checked = false;
                document.getElementById("doseCustom").checked = true;
                $('#doseCommonlabel').css({"background-color": "" , "border" : "2px solid #CBCBCB"});
                $('#doseCustomlabel').css({"background-color": "#231F20" , "border": "2px solid black"});

            }
            else {

                $scope.radioDosageSelected = "common";
                document.getElementById("doseCommon").checked = true;
                document.getElementById("doseCustom").checked = false;
                $('#doseCommonlabel').css({"background-color": "#231F20", "border": "2px solid black"});
                $('#doseCustomlabel').css({"background-color": "", "border": "2px solid #CBCBCB"});

            }
            $scope.dosageType = {
                common: $scope.radioDosageSelected == 'common',
                custom: $scope.radioDosageSelected == 'custom'
            };

        }
    };

    $scope.dosageType = {
        common: true,
        custom: false
    };
    $scope.FastContentService = help.readFASTContent();
    $scope.customDose = {
        "quantityPer": 1,                    // quantity of dose per
        "timePeriod": [
            {
                'name': 'Select',
                'days': 0
            },
            {
                'name': 'Day',
                'days': 1
            },
            {
                'name': 'Week',
                'days': 7
            },
            {
                'name': 'Month',
                'days': 30
            }
        ],
        "daysSupply": 30
    };

    var setDefaultCustomValues = function () {
        updateErrorMessage();
        $scope.customDoseSelected = {};
        $scope.customDoseSelected.timeSelect = $scope.customDose.timePeriod[0];
        if ($scope.drugDetails && $scope.drugDetails.dosageSelected && (!$scope.drugDetails.dosageSelected.hasCommon || $scope.drugDetails.dosageSelected.isCustom)) {
            $scope.radioDosageSelected = 'custom';
            $scope.dosageType = {
                common: false,
                custom: true
            };
        }
        if ($scope.drugDetails.dosageSelected.isCustom) {
            $scope.customDoseSelected.quantityPer = $scope.drugDetails.dosageSelected.options.qty;
            $scope.customDoseSelected.timeSelect = $scope.drugDetails.dosageSelected.options.duration;
            $scope.customDoseSelected.daysSupply = $scope.drugDetails.dosageSelected.options.days;
        }
    };

    setDefaultCustomValues();

    function updateErrorMessage(errorMessage) {
        if (errorMessage) {
            $scope.error.message = errorMessage;
        } else {
            $scope.error.message = '';
        }
    }

    $scope.confirmDosage = function (isValid) {
        $scope.submitted = true;
        if (isValid) {
            updateErrorMessage();
            var dosageSelected = $scope.drugDetails.dosageSelected;
            if ($scope.radioDosageSelected === 'custom') {
                if (checkDays()) {
                    updateErrorMessage(errors.getErrorMessage("017"));
                    return;
                }

                if (parseInt($scope.customDoseSelected.quantityPer) > 3) {
                    dosageSelected.dosageLabel = "Taken " + $scope.customDoseSelected.quantityPer + " times per " +
                    $scope.customDoseSelected.timeSelect.name.toLowerCase();
                }
                else {
                    dosageSelected.dosageLabel = "Taken " + qtyLabel[$scope.customDoseSelected.quantityPer] + " per " +
                    $scope.customDoseSelected.timeSelect.name.toLowerCase();
                }

                dosageSelected["isCustom"] = true;
                dosageSelected["options"] = {
                    "qty": $scope.customDoseSelected.quantityPer,
                    "duration": $scope.customDoseSelected.timeSelect,
                    "days": $scope.customDoseSelected.daysSupply
                };
            }
            else {
                dosageSelected["isCustom"] = false;
            }
            $scope.drugDetails.dosageSelected = dosageSelected;
            $scope.submit($scope.drugDetails);
        } else {
            updateErrorMessage(errors.getErrorMessage('017'));
        }
    };

    $scope.radioCheck = function (selectedDosageTypeValue) {
        if ($scope.radioDosageSelected !== selectedDosageTypeValue) {
            $scope.radioDosageSelected = selectedDosageTypeValue;
            updateErrorMessage();
            $scope.customDoseSelected = {};
            $scope.customDoseSelected.timeSelect = $scope.customDose.timePeriod[0];
            $scope.edited = true;
        }
        $scope.dosageType = {
            common: $scope.radioDosageSelected == 'common',
            custom: $scope.radioDosageSelected == 'custom'
        };
    };

    $scope.selectTimePeriod = function (timeSelect) {
        $scope.customDoseSelected.timeSelect = timeSelect;
        if (timeSelect.days !== 1) {
            $scope.customDoseSelected.daysSupply = '';
        }
        if (!$scope.customDoseSelected.quantityPer) {
            updateErrorMessage(errors.getErrorMessage('022'));
        }
    };

    $scope.$watch('customDoseSelected.quantityPer', function (newVal, oldVal) {
        if (checkDays()) {
            updateErrorMessage(errors.getErrorMessage("017"));
        }
        else if (newVal !== oldVal && checkQty()) {
            updateErrorMessage(errors.getErrorMessage('022'));
        }
        else {
            updateErrorMessage();
        }
    });

    $scope.$watch('customDoseSelected.daysSupply', function (newVal) {
        if (newVal && checkDays()) {
            updateErrorMessage(errors.getErrorMessage("017"));
        } else if (checkQty()) {
            updateErrorMessage(errors.getErrorMessage('022'));
        }
        else {
            updateErrorMessage();
        }
    });

    function checkDays() {
        return $scope.customDoseSelected.timeSelect.days === 1 && $scope.customDoseSelected.daysSupply &&
            ($scope.customDoseSelected.daysSupply < 1 || $scope.customDoseSelected.daysSupply > 365);
    }

    function checkQty() {
        return (!$scope.customDoseSelected.quantityPer &&
        $scope.customDoseSelected.timeSelect !== $scope.customDose.timePeriod[0]);
    }
}]);