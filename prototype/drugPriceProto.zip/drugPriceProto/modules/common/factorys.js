'use strict';

/* Factory */

var checkDrugCostFactory = angular.module('checkDrugCost.factorys', []);
//var pharmacyLocatorFactory = angular.module('pharmacyLocator.factorys', []);