/**
 * Created by 486485 on 5/15/2015.
 */
(function() {
    'use strict';
    checkDrugCostFactory.factory('personalization', ['userSessionData', 'cdcServices', '$q', 'help', function(userSessionData, cdcServices, $q, help) {
        var personlizationMapped;

        function getPersonlizationContent(pznId) {
            var deferred = $q.defer();
            if (!personlizationMapped) {
                if (parseInt(pznId) <= 0) {
                    deferred.resolve();
                }

                var personalizationData = {
                    "personalizationServiceRequest": {
                        "tag": config.resourceTag
                    }
                };
                var userInfo = userSessionData.getLoggedInUserInfo();
                if (userInfo && userInfo.personalizationId) {
                    personalizationData["personalizationServiceRequest"]["pznID"] = userSessionData.getLoggedInUserInfo().personalizationId;
                } else {
                    deferred.resolve();
                }

                cdcServices.getPZNByIDandResourcetag({}, personalizationData).then(function(data) {
                    if (data && data.response && data.response.header && data.response.header.statusCode==='0000' && 
                        data.response.detail && data.response.detail.detail && data.response.detail.detail.personalizationContent) {
                        var personalizationContents = data.response.detail.detail.personalizationContent.personalizationContents;
                        personlizationMapped = {};
                        personalizationContents = help.convertToArray(personalizationContents);
                        angular.forEach(personalizationContents, function(content) {
                            personlizationMapped[content.resourceTagId] = {};
                            if (content.contentText) {
                                personlizationMapped[content.resourceTagId]['contentText'] = content.contentText;
                            }
                            if (content.resourceVisibleIndicator) {
                                personlizationMapped[content.resourceTagId]['resourceVisibleIndicator'] = content.resourceVisibleIndicator !== "0";
                            }
                        });
                    }
                    deferred.resolve(personlizationMapped);
                }, function() {
                    deferred.resolve(personlizationMapped);
                });
            } else {
                deferred.resolve(personlizationMapped);
            }
            return deferred.promise;
        }

        return {
            getPersonlizationContent: getPersonlizationContent
        };
    }]);
})();