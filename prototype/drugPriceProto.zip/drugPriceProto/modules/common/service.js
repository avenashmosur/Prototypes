/**
 * Created by 400221259 on 3/26/2015.
 */

var checkDrugCostService = angular.module('checkDrugCost.services', []);
