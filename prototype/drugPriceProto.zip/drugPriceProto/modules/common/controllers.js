'use strict';

/* Controllers */

var checkDrugCostController = angular.module('checkDrugCost.controllers', []);
//var pharmacyLocatorController = angular.module('pharmacyLocator.controllers', []);