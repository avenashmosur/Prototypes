(function () {
    'use strict';

    checkDrugCostFactory.factory('pharmacyLocatorHelper', pharmacyLocatorHelper);

    pharmacyLocatorHelper.$inject = ['activeModel', 'CoreCommonsModal', 'portalJson'];

    function pharmacyLocatorHelper(activeModel, CoreCommonsModal, portalJson) {

        var openPharmacyLocator = function (callbackMethod, customModalProperties) {
            var pharmacySearchHeader='', pharmacyMapHeader='';
            if (portalJson.APP_CMS_DATA) {
                pharmacySearchHeader = portalJson.APP_CMS_DATA["portletIntegratedPharmacyLocatorChangeSearchModalHdrSpot"];
                pharmacyMapHeader = portalJson.APP_CMS_DATA["portletIntegratedPharmacyLocatorMapModalHdrSpot"]
            }
            var modalProperties = {
                "templateUrl": "bower_components/pharmacy/views/pharmacy-search.html",
                "size": "md",
                "windowClass": "",
                "data": {
                    "customizeView": {
                        "vaccineNetwork": {
                            "show": activeModel.memberSelect.isVaccineEligibile
                        },
                        "bestPharmacy":{
                            "show":activeModel.memberSelect.isBestPharmacy || activeModel.bestPharmaciesPzn
                        },
                        "pharmacySearchHeader": {
                            "text": pharmacySearchHeader
                        },
                        "pharmacyMapHeader": {
                            "text": pharmacyMapHeader
                        }
                    },
                    "tokenId": activeModel.tokenId
                }
            };


            for (var key in customModalProperties) {
                modalProperties[key] = modalProperties[key];
            }

            var staticModalProperties = {
                callback: callbackMethod
            };

            CoreCommonsModal.generalModal(modalProperties, staticModalProperties);
        };

        return {
            "openPharmacyLocator": openPharmacyLocator
        }
    }
})();