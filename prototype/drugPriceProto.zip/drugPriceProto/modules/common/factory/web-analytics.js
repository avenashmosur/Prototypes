'use strict';
checkDrugCostFactory.factory('webAnalytics', ['$rootScope', 'help', 'activeModel','portalJson','$timeout', function ($rootScope, help, activeModel,portalJson,$timeout) {
    var url='';
    if(portalJson && portalJson.APP_PARAM_DATA  && portalJson.APP_PARAM_DATA.CartUrl) {
        activeModel.tealiumUrl = config.tealiumUrl[help.getEnvFromURL(portalJson.APP_PARAM_DATA.CartUrl)].url;
        url = activeModel.tealiumUrl;
    }else{
        config.webAnalyticsFlag =false;
    }


    var deviceType = help.getUserAgent(navigator.userAgent);
    var channelName = (deviceType == 'DESKTOP') ? 'DESKTOP' : 'MOBILE WEB';

    var webAnalytics = {};

    $timeout(function() {
        $rootScope.$broadcast('utag_loaded');
    }, 5000);

    webAnalytics.loadScript = function (url, callback) {
        if(config.webAnalyticsFlag){
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.charset = 'utf8';
            script.async = true;
            if (script.readyState) {
                script.onreadystatechange = function () { //IE
                    if (script.readyState == 'loaded' || script.readyState == 'complete') {
                        script.onreadystatechange = null;
                        if (typeof  callback === 'function') {
                            callback();
                        }
                    }
                }
            } else {

                script.onload = function () {
                    script.onload = null;
                    if (typeof callback === 'function') {
                        callback();
                    }
                }
            }

            script.src = url;
            document.getElementsByTagName('head')[0].appendChild(script);
        }
    }

    webAnalytics.webTrendsOnPageLoad = function () {
        if(config.webAnalyticsFlag){
            try {
                //console.log("webTrendsOnPageLoad");
                if (arguments != null && arguments.length != 0 && arguments.length % 2 == 0) {
                    var returnParam = getUtagData();
                    for (var i = 0; i < arguments.length; i++) {
                        returnParam += arguments[i] + ':"' + arguments[i + 1] + '",';
                        i++;
                    }
                    if (returnParam.length > 1) {
                        returnParam = returnParam.substring(0, returnParam.length - 1);
                        returnParam = "{" + returnParam + "}";
                        utag.view(eval("(" + returnParam + ")"));
                    }
                }
            } catch (err) {
            }
        }
    }

    webAnalytics.webTrendsOnEvent = function () {
        if(config.webAnalyticsFlag){
        try {
            if (arguments != null && arguments.length != 0 && arguments.length % 2 == 0) {
                var returnParam = getUtagData();

                for (var i = 0; i < arguments.length; i++) {
                    returnParam += arguments[i] + ':"' + arguments[i + 1] + '",';
                    i++;
                }
                if (returnParam.length > 1) {
                    returnParam = returnParam.substring(0, returnParam.length - 1);
                    returnParam = "{" + returnParam + "}";
                    utag.link(eval("(" + returnParam + ")"));
                }
            }
        }
        catch (err) {
        }
        }
    }

    webAnalytics.wtLoadHome = function (activeModel) {
        this.webTrendsOnPageLoad("Page_Name", "Search : Drug Coverage and Cost", "Page_Category", "Check Drug Coverage and Cost", "Page_Sub_Category", "Drug Coverage and Cost", "Scenario_Name", "check_drug_cost", "Scenario_Step", "1");
    }
    /*	Make sure json.key element is always unique
     * 	Example:
     For single key:
     $rootScope.$emit('TealiumWebAnalytic', {"key":"30-90days"});

     For single key with multip value:
     $rootScope.$emit('TealiumWebAnalytic', {"key":"30-90days", "anyname":"anyvalue", "anyname":"anyvalue"});
     */
    webAnalytics.callHandler = function (event, json) {
        switch (json.key + '') {
            case '30dcvsb':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 30dayBrand",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case '90dcvsb':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 90dayBrand",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case '30dcvsg':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 30dayGeneric",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case '90dcvsg':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 90dayGeneric",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case '30dotherb':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 30dayBrand",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case '30dotherg':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", json.key,
                    "Page_Name", "Link : Drug Coverage and Cost : 30dayGeneric",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case 'NoResultsFound':
                this.webTrendsOnEvent(
                    "Page_Event", 43, "Page_Name",
                    "Search Unsuccessful", "Page_Category",
                    "Check Drug Coverage and Cost", "Page_Sub_Category",
                    "Drug Coverage and Cost", "Error_Messages", "CDC : No results found");
                break;

            case 'TealiumLoaded':
                this.wtLoadHome(activeModel, true);
                break;

            case 'PHARMACLICK1':
                this.webTrendsOnEvent(
                    "Page_Name", "Link : Drug Coverage and Cost : Edit Pharmacy",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Page_Event", "21");
                break;

            case 'DOSECLICK1':
                this.webTrendsOnEvent(
                    "Page_Name", "Link : Drug Coverage and Cost : Edit Dosage",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Page_Event", "21");
                break;

            case 'ADDPHARM1':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", "pap",
                    "Page_Name", "Link : Search Successful",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "3");
                break;

            case 'ALTER1':
                this.webTrendsOnEvent(
                    "Page_Event", 21,
                    "Navigation_View", "ta",
                    "Page_Name", "Link : Search Successful",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "4");
                break;

            case 'PATIENTSELECT1':
                this.webTrendsOnEvent(
                    "Page_Event", "99",
                    "Page_Name", "Flydown : Drug Coverage Cost : Select Patient",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case 'PRINT1':
                this.webTrendsOnEvent(
                    "Page_Event", "21",
                    "Page_Name", "Link : Drug Coverage and Cost : Print",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case 'HELP1':
                this.webTrendsOnEvent(
                    "Page_Event", "21",
                    "Page_Name", "Link : Drug Coverage and Cost : Need  help",
                    "Page_Category", "Check Drug Coverage and Cost");
                break;

            case 'Scenario2':
                this.webTrendsOnPageLoad(
                    "Page_Name", "Search Successful",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Page_Sub_Category","Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "2");
                break;

            case 'Scenario1a':
                this.webTrendsOnPageLoad(
                    "Page_Name", "New Search : Drug Coverage and Cost",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Page_Sub_Category","Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "1a");
                break;

            case '30-90days':
                this.webTrendsOnPageLoad(
                    "Page_Name", "Search Successful",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Page_Sub_Category","Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "2",
                    "total_results",json.value);
                break;

            case 'NEWRX':
                this.webTrendsOnEvent(
                    "Page_Event", "21",
                    "Page_Name", "Link : Drug Coverage and Cost : new Rx",
                    "Page_Category", "Check Drug Coverage and Cost",
                    "Scenario_Name", "check_drug_cost",
                    "Scenario_Step", "new rx");
                break;

            case 'SCODE':
                this.webTrendsOnPageLoad(
                    "Page_Event", 43,
                    "Page_Category", "Check Drug Coverage and Cost",
                    "cdc_settlementcode",json.value);
                break;

            default:
                break;
        }
    }

    String.prototype.contains = function (it) {
        return this.indexOf(it) != -1;
    };

    function getEnv(Tealium_URL) {
        var separator = "/";
        if (Tealium_URL != null) {
            var splitedArray = Tealium_URL.split(separator);
            if (splitedArray.length > 2) {
                return splitedArray[splitedArray.length - 2];
            }
        }
        return null;
    }

    function getUtagData(){
        var clientId="";//activeModel.clientId;
        var clientName="";//activeModel.clientName;
        if(activeModel.portalJson &&
            activeModel.portalJson.APP_PARAM_DATA &&
            activeModel.portalJson.APP_PARAM_DATA.ClientId &&
            activeModel.portalJson.APP_PARAM_DATA.ClientName){
            clientId=activeModel.portalJson.APP_PARAM_DATA.ClientId;
            clientName=activeModel.portalJson.APP_PARAM_DATA.ClientName;
        }
        return "environment:'" + getEnv(url) + "',site_name:'FASTINT',country:'US',language:'EN',currency:'USD',platform:'" + channelName + "',Client_Id:'"+clientId+"',PBM_Client_Name:'"+clientName+"',";

    }



    return webAnalytics;
}]);
