'use strict'

// activeModel: Caching app data that will be used throughout the app

checkDrugCostFactory.factory('activeModel', [function(){

  var activeModel = {};

  activeModel = {
    tokenId                     : '',
    authenticated               : false,
    memberList                  : '',     // list of members
    memberSelect                : '',     // selected member
    drugSelect                  : '',     // the search result item selected, string
    preferredPharmacy           : '',     // preferred pharmacy information from getMemberID

    drugList                    : [],     // Drug Detail List
    drugItemSelect              : '',     // the drugDetail Object selected
    commonDaysSupply            : '',     // default no. of tablets
    commonDispensedQuantity     : '',     // default no of days for dose

    daysSupplySelect            : '',     // the dosage SELECTED
    dispensedQuantitySelect     : '',     // the dosage SELECTED
    daysSupplySelectMail        : '',     // the dosage mail SELECTED
    dispensedQuantitySelectMail : '',     // the dosage mail SELECTED
    tealiumURL                  : '',

    customDose : {
      quantityPer : 1,                    // quantity of dose per 
      timePeriod  : [
            {
              'name' : 'day',
              'days' : 1
            },
            {
              'name' : 'week',
              'days' : 7
            },
            {
              'name' : 'month',
              'days' : 30
            },
            {
              'name' : 'year',
              'days' : 365
            }
          ],
      daysSupply  : 30 ,
      frequency :['Once', 'Twice', 'Thrice'],
      drugForm :['TABLET','LIQUID','PACKETS']
                        // total number of days for which the drug is dispensed for
    },

    pharmacySelect              : '',          // selected pharmacy
    pharmacySearchList          : {},     // pharmacy list
    searchResult                : '',
    searchPharmacy              : '',
    drugCost                    : '',
    filterPharmacy              : {},
    portalJson				    : {},


      //Data Model
      costResultDataModel : {},

      //Data Model
      pastCostResultDataModel : {},

      pastSearchData : [],

      onLoadDrugResultsScreen : false //Localytics


  };

  return activeModel;

}]);