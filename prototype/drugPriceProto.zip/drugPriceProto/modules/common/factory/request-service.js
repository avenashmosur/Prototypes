'use strict';


checkDrugCostFactory.factory('requestService', ['$rootScope', '$window', 'serviceFactory', 'errors', '$timeout', 'help', '$http', '$q', 'activeModel',
    function ($rootScope, $window, serviceFactory, errors, $timeout, help, $http, $q, activeModel) {

        var makeRequest, baseUrl, serviceEndPoints = "serviceEndPoints", apiParamData;
        if (help.IEVersion() == 8) {
            makeRequest = function (serviceEndPoint, params, data) {
                var xdr = new $window.XDomainRequest();
                var x2js = new X2JS();
                var deferred = $q.defer();
                $timeout(function () {
                   // angular.element("#LoadingImage").show();
                    showProgress('block');
                    if (xdr) {
                        //event raised when there is an error that prevents the completion of
                        // the cross-domain request.
                        xdr.onerror = function () {
                            $rootScope.$apply(function () {
                                deferred.reject(xdr.responseText);
                            });
                        };

                        //Raised when the object has been completely received from the server.
                        xdr.onload = function () {
                            $rootScope.$apply(function () {
                                var jsondata;
                                if (xdr.responseText) {
                                    var x2js = new X2JS();
                                    jsondata = x2js.xml_str2json(xdr.responseText);
                                    if (jsondata.response && jsondata.response.header && jsondata.response.header.statusCode == "3004") {
                                        jsondata.response.header.statusDesc = errors.getErrorMessage("100");
                                        deferred.reject(jsondata);
                                        //angular.element("#LoadingImage").hide();
                                        showProgress('none');

                                    } else {
                                        deferred.resolve(jsondata);
                                        //angular.element("#LoadingImage").hide();
                                        showProgress('none');

                                    }
                                } else {
                                    showProgress('none');
                                    jsondata = "No Response Object";
                                }
                            });
                        };
                        xdr.open("post", urlMaker(serviceEndPoint, params));
                        if (data) {
                            var requestData = serviceFactory.requestTranform(data);
                            xdr.send(requestData);
                        } else {
                            xdr.send();
                        }
                    }
                }, 0);
                return deferred.promise;
            };
        }
        else {
            makeRequest = function (serviceEndPoint, params, data, hideLoading) {

                if (!hideLoading) {
                    angular.element(".loadingModal").show();
                    $rootScope.$broadcast('spinner',[true]);
                } else {
                    angular.element(".loadingModal").hide();
                }

                try{
                    if(native){
                        native.showLoading();
                    }
                }catch (e) {console.log('native.showLoading');}

                var deferred = $q.defer();
                var request = $http({
                    method: 'POST',
                    url: urlMaker(serviceEndPoint, params),
                    data: serviceFactory.requestTranform(data),
                    transformResponse: serviceFactory.responseTransform,
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    timeout: deferred.promise
                });

                var promise = request.then(
                    function (response) {
                        return response.data;
                    },
                    function (response) {
                        return response;
                    }
                )['finally'](function () {
                    try{
                        if(native){
                            native.hideLoading();
                        }
                    }catch (e) {console.log('native.hideLoading');}

                    promise.abort = angular.noop;
                    deferred = request = promise = null;
                });

                promise.abort = function() {
                    deferred.resolve();
                };

                return promise;
            }
        }

        function urlMaker(serviceNames, params) {
            if (activeModel.authenticated && config.currentENV !== 'demo') {
                apiParamData = activeModel.portalJson.API_PARAM_DATA;
            }
            else {
                serviceEndPoints = "demo";
            }

            if (!baseUrl) {
                if (apiParamData) {
                    if(apiParamData["apiBaseUrl"]){
                        baseUrl = apiParamData["apiBaseUrl"];
                    }
                    else{
                        baseUrl = config[config.currentENV].baseUrl;
                    }
                }
                else {
                    baseUrl = config[config.currentENV].baseUrl;
                }
            }

            var appName = help.getUserAgent() == 'DESKTOP' ? 'CMK_WEB' : 'CMK_APP';


            var getKeyValue = function (key) {
                var keyValue = config.apiParams[key];
                if (apiParamData && apiParamData[key]) {
                    keyValue = apiParamData[key];
                }
                return keyValue;
            };
            var url = {
                "domain": baseUrl + config[serviceEndPoints][serviceNames],
                "params": {
                    "apiKey": getKeyValue('apiKey'),
                    "apiSecret": getKeyValue('apiSecret'),
                    "appName": getKeyValue('appName'),
                    "channelName": getKeyValue('channelName'),
                    "deviceID": getKeyValue('deviceID'),
                    "deviceToken": getKeyValue('deviceToken'),
                    "deviceType": getKeyValue('deviceType'),
                    "lineOfBusiness": getKeyValue('lineOfBusiness'),
                    "serviceCORS": "TRUE",
                    "version": getKeyValue('version'),
                    "tokenID": getKeyValue('tokenId'),
                    "serviceName": serviceNames
                }
            };
            if (config["operationName"][serviceNames]) {
                url.params["operationName"] = config["operationName"][serviceNames];
            }

            for (var key in params) {
                url.params[key] = params[key];
            }

            return constructURL(url);

        }

        function constructURL(url) {
            var finalURL;
            finalURL = url.domain;
            // build parameters
            if (url.params) {
                var params = "?";

                if (!Object.keys) {
                    Object.keys = function (obj) {
                        var keys = [];
                        for (var i in obj) {
                            if (obj.hasOwnProperty(i)) {
                                keys.push(i);
                            }
                        }
                        return keys;
                    };
                }
                // building params
                for (var i = 0, keys = Object.keys(url.params); i < keys.length; i++) {
                    params += (keys[i] + "=" + url.params[keys[i]] + (( i < keys.length - 1) ? "&" : ""));
                }
                // final URL with params
                finalURL += params;
            }

            return finalURL;
        }

        function showProgress(value) {
            var divProgressWheel = document.getElementById("progress_wheel_div");
            divProgressWheel.style.display = value;
        }

        return {
            makeRequest: makeRequest
        }


    }
]);