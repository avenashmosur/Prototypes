'use strict';

// This file has a function called matchRX to find an RX from within the service response and return it

checkDrugCostFactory.factory('help', ['activeModel', '$location', '$rootScope', 'FastContentService','$timeout',
    function (activeModel, $location, $rootScope, FastContentService,$timeout) {
        var help = {}, userAgent, msie, iframeContainer;

        help.matchRX = function (rx) {
            var refill = activeModel.refill;
            var drug;

            for (var i = 0; i < refill.length; i++) {
                if (rx == refill[i].rxNumber) {

                    drug = {
                        name: refill[i].drug.drugName,
                        strength: refill[i].drug.drugStrength,
                        form: refill[i].drug.drugForm,
                        rxNumber: refill[i].rxNumber,
                        cost: refill[i].estimatedCost
                    }
                }
            }

            return drug;
        };

        // Takes an OBJECT or STRING and wraps it in an array
        help.convertToArray = function (input) {
            var arr;

            if (Object.prototype.toString.call(input) === '[object Object]') {
                arr = [input];
            } else if (Object.prototype.toString.call(input) === '[object Array]') {
                arr = input
            } else if (Object.prototype.toString.call(input) === '[object String]') {
                arr = [input]
            }

            return arr;
        };

        help.returnUniqueArray = function (arrInput) {
            var arr = [];

            arrInput.forEach(function (element) {
                if (arr.indexOf(element) === -1) {
                    arr.push(element);
                }
            });

            return arr;
        };

        help.removeAllDrugStrengths = function (drugInputArray) {
            var arr = [];

            drugInputArray.forEach(function (element, index) {
                // regex find all digits followed by 'mg' in the element
                var found = /\d+mg|\d+units|\d+%/.exec(element);  // sample ["400mg", index: 7, input: "Avelox 400mg ABC Pack"]

                if (found) {
                    element = element.slice(0, found.index - 1);
                    // i.e. "Avelox 400mg ABC Pack" becomes "Avelox"
                }

                arr.push(element);

            });

            // after the trimming out of strnegth (i.e 400mg), uniquify the array
            arr = help.returnUniqueArray(arr);
            return arr;

        };

        help.IEVersion = function () {
            if (msie) {
                return msie;
            }
            var arr = (/msie (\d+)/.exec(navigator.userAgent.toLowerCase()));
            msie = (arr || [])[1];

            if (isNaN(msie)) {
                arr = (/trident\/.*; rv:(\d+)/.exec(navigator.userAgent.toLowerCase()));
                msie = (arr || [])[1];
            }
            return msie;

        };

        help.getUserAgent = function (userAgentPickedUp) {
            if (userAgent) {
                return userAgent;
            }
            // ANDROID
            if (/Android/i.test(userAgentPickedUp)) {
                // ANDROID MOBILE
                if (/Mobile/i.test(userAgentPickedUp)) {
                    userAgent = 'AND_MOBILE';

                    // ANDROID GLASS
                } else if (/Glass/i.test(userAgentPickedUp)) {
                    userAgent = 'AND_GLASS';

                    // ANDROID TABLET
                } else {
                    userAgent = 'AND_TABLET';
                }
                // iOS Mobile
            } else if (/iPhone|iPod/i.test(userAgentPickedUp)) {
                userAgent = 'IOS_MOBILE';


                // iOS Tablet
            } else if (/iPad/i.test(userAgentPickedUp)) {
                userAgent = 'IOS_TABLET';


                // Windows
            } else if (/IEMobile/i.test(userAgentPickedUp)) {
                userAgent = 'WIN_MOBILE';

                // Other identified vendor
            } else if (/webOS|BlackBerry|Opera Mini/i.test(userAgentPickedUp)) {
                userAgent = 'OTH_MOBILE';
            }
            else {
                userAgent = 'DESKTOP';
            }
            return userAgent;
        };

        help.go = function (path) {
            $location.path(path);
        };

        help.currentLocation = function () {
            return $location.url();
        };

        help.emit = function (messageName) {
            $rootScope.$emit(messageName);
        };

        help.broadCast = function (messageName) {
            $rootScope.$broadcast(messageName);
        };

        help.executeOn = function (messageName, method) {
            $rootScope.$on(messageName, method);
        };

        help.readFASTContent = function () {
            var contentService=FastContentService.desktopContent;
            if(help.getUserAgent().indexOf('MOBILE')!==-1){
                contentService = FastContentService.mobileContent;
            }
            return contentService;
        };

        help.getIframeData = function () {
            var iframeCol = window.parent.document.getElementsByTagName('iframe');
            angular.forEach(iframeCol, function (val) {
                if (val.contentDocument.body.id == 'cdc') {
                    iframeContainer = val;
                }
            });
            return iframeContainer;
        };

        help.sortList = function (listToSort, sortKey) {
            var reA = /[^a-zA-Z]/g;
            var reN = /\d+(\.\d+)?/g;
            listToSort.sort(function (alpha, beta) {
                var a=alpha[sortKey],
                b=beta[sortKey];
                var aA = a.replace(reA, "");
                var bA = b.replace(reA, "");
                if(aA === bA) {
                    var aN = a.match(reN)? parseFloat(a.match(reN)[0]):0;
                    var bN = b.match(reN)? parseFloat(b.match(reN)[0]):0;
                    return aN === bN ? 0 : aN > bN ? 1 : -1;
                } else {
                    return aA > bA ? 1 : -1;
                }
            });
        };

        help.setSessionStorage = function (key, data) {
            if (typeof(Storage) !== "undefined") {
                sessionStorage.setItem(key, JSON.stringify(data));
            }
        };

        help.getSessionStorage = function (key) {
            if (typeof(Storage) !== "undefined" && sessionStorage[key]) {
                return JSON.parse(sessionStorage[key]);
            }
            return false;
        };

        help.getDate = function (dateInput) {
            if(dateInput && (typeof dateInput=== 'string' ||dateInput instanceof String)){
                dateInput=dateInput.toString();
                var t = dateInput.split(/[- T]/);
                return new Date(t[0], t[1] - 1, t[2]);
            }else if(dateInput && (typeof dateInput=== 'object' ||dateInput instanceof Object)){
                dateInput=dateInput.__text;
                var t = dateInput.split(/[- T]/);
                return new Date(t[0], t[1] - 1, t[2]);
            }else{
                return dateInput;
            }
        };

        help.getEnvFromURL = function (url) {
            var envValues = ['dev1','dev2','dev3','sit1','sit2','sit3','prod','stp','cte'];
            var keepLooping = true;
            var urlParts = url.replace('http://', '').replace('https://', '').split(/[/?#]/);
            angular.forEach(envValues, function (env) {
                if (keepLooping) {
                    if (urlParts !== null) {
                        var domain = urlParts[0];
                        if (domain.indexOf(env) > -1) {
                            keepLooping = false;
                            activeModel.env = env;
                        }
                    }
                }
            });
            return activeModel.env;
        }

        help.popOverHandler=function(element, event) {
            $timeout(function () {
                angular.element(element).popover(event);
                var bindClick = function (e) {
                    var $popover = $('[data-toggle=popover]').popover();
                    var isPopover = angular.element(e.target).is('[data-toggle=popover]'),
                        inPopover = angular.element(e.target).closest('.popover').length > 0;
                    if (!isPopover && !inPopover) {
                        $popover.popover('hide');
                    }
                };
                angular.element(document).on("click", bindClick);
                angular.element(window.parent.document).on("click", bindClick);
            });
        }

        return help;
    }]);