'use strict';

//checkDrugCost Service Factory
checkDrugCostService.service('costResultDataService', function () {

    var datamodel = {};
    var responseDatamodel={};

    datamodel.formDataModel = function(response,placeholder )
    {
        responseDatamodel = {
            drugNames : {
                generic : [],
                additionalPharmacy: [],
                TAD:[]
            },
            dosage: {
                generic: [],
                additionalPharmacy:[],
                TAD:[]
            },
            Costs  : {
                generic : {
                    mail:[],
                    retail:[]
                },
                additionalPharmacy: {
                    mail:[],
                    retail:[]
                },
                TAD:[]
            },
            additionalPharmacies:[]

        };

        if(response.mailDosageSupply && response.dataInd.isMail && ((response.brand && response.brand.mailPrice) || (response.generic && response.generic.mailPrice)) )
        {
            datamodel.formDosage(response.mailDosageQuantity,response.mailDosageSupply,"Mail service",placeholder,response.dataInd && response.dataInd.isMChoiceMember,response.dataInd && response.dataInd.isSolid);
        }

        /* Retail Dosage Supply */
        if(response.retailDosageSupply && response.dataInd.isRetail && ((response.brand && response.brand.retailPrice) || (response.generic && response.generic.retailPrice)))
        {
            datamodel.formDosage(response.retailDosageQuantity,response.retailDosageSupply,"Store pickup",placeholder,false,response.dataInd && response.dataInd.isSolid);
        }

        /* Brand Drug Details */
        if(response.brand) {
            var bestValueInd =response.best.ind;
            var best;
            if(bestValueInd && response.best.type.indexOf('brand') > -1 ){
                bestValueInd = true;
                if(response.best.type.indexOf('Mail') > -1 ){
                    best ="mail";
                }else{
                    best ='retail'
                }
            }else{
                bestValueInd = false;
            }

            var emptyMailBlock=false;
            var emptyRetailBlock=false;
            if(!response.brand.mailPrice && response.generic && response.generic.mailPrice && response.dataInd.isRetail){
                emptyMailBlock=true
            }else if(!response.brand.retailPrice && response.generic && response.generic.retailPrice && response.dataInd.isMail) {
                emptyRetailBlock = true;
            }
            if((response.dataInd.isMail && response.brand.mailPrice) || (response.brand.retailPrice && response.dataInd.isRetail)){
                datamodel.formLabel(response.brand,'brand','Covered by Your Plan',placeholder,"",false,best,response.isStCob,response.dataInd.medicare);
                datamodel.formCost(response.brand,placeholder,response.hasCommon,bestValueInd,best,response.dataInd,response.drugPropertiesList,response,"Best Value:",emptyMailBlock,emptyRetailBlock);
            }
        }

        /* Equivalent Drug Details*/
        if(response.generic)
        {
            var bestValueInd =response.best.ind;
            var bestHeading;
            if(bestValueInd && response.best.type.indexOf('generic') > -1 ){
                bestValueInd = true;
                if(response.best.type.indexOf('Mail') > -1 ){
                    best ="mail";
                }else{
                    best="retail"
                }
            }else{
                bestValueInd = false;
            }

            if(!(response.brand)){
                bestHeading="Best Value:"
            }else{
                bestHeading="Save money with generic equivalent:"
            }
            var emptyMailBlock=false;
            var emptyRetailBlock=false;
            if(!response.generic.mailPrice && response.brand && response.brand.mailPrice  && response.dataInd.isRetail){
                emptyMailBlock=true
            }
            if(!response.generic.retailPrice && response.brand && response.brand.retailPrice && response.dataInd.isMail){
                emptyRetailBlock=true;
            }

            if((response.dataInd.isMail && response.generic.mailPrice) || (response.generic.retailPrice && response.dataInd.isRetail)){
                datamodel.formLabel(response.generic,'generic Equivalent','Covered by Your Plan',placeholder,"",false,best,response.isStCob,response.dataInd.medicare);
                datamodel.formCost(response.generic,placeholder,response.hasCommon,bestValueInd,best,response.dataInd,response.drugPropertiesList,response,bestHeading,emptyMailBlock,emptyRetailBlock);
            }
        }

        //console.log(responseDatamodel);
        return responseDatamodel;
    };




    datamodel.formLabel = function(drugLabel,type,planDetail,placeholder,heading,bestValueIndicator,best,isStCob,medicare)
    {
        var obj = {
            drugName        :   drugLabel.drugName,
            drugForm        :   drugLabel.drugForm,
            drugStrength    :   drugLabel.drugStrength,
            jiggy           :   drugLabel.settle,
            settlementDesc  :   drugLabel.settlementDesc,
            drugType        :   type,
            planDetail      :   planDetail,
            heading         :   bestValueIndicator ? heading :"",
            bestValueInd    :   bestValueIndicator ? true : false,
            bottomBorder    :   best ==='retail'? true : false,
            ndcId           :   drugLabel.ndcId,
            isStCob         :   isStCob,
            coveredByPlanInd      : drugLabel.coveredByPlanInd,
            medicare        :   medicare
        };

        if(drugLabel.drugDetailForCart){
            obj['drugDetailForCart']=drugLabel.drugDetailForCart;
        }

        responseDatamodel.drugNames[placeholder].push(obj);
    };

    datamodel.formDosage = function(DosageQuantity,DosageSupply,purchaseType,placeholder,isMChoice,isSolid)
    {
        var obj = {
            DosageQuantity  :   DosageQuantity,
            DosageSupply    :   DosageSupply,
            purchaseType    :   purchaseType,
            isMChoiceMember:    isMChoice?isMChoice :false,
            isSolid         :   isSolid? isSolid :false
        };
        if(purchaseType == "Mail service")
            obj.maildelivery = true;
        else if(purchaseType == "Store pickup")
            obj.retaildelivery = true;

        responseDatamodel.dosage[placeholder].push(obj);
    };

    datamodel.formCost = function(responseCost,placeholder,hasCommon,bestValue,best,retailMailInd,drugPropertiesList,response,bestHeading,emptyMailBlock,emptyRetailBlock) {


            if(responseCost.mailPrice && retailMailInd.isMail)
        {
            var obj = {
                PricetotalObject    :   responseCost.mailPricetotalObject,
                Months              :   response.mail && response.mail.mailMonths? response.mail.mailMonths :0,//responseCost.mailMonths,
                Price               :   responseCost.mailPrice,
                Percentage          :   responseCost.mailPercentage,
                bestValueInd  :         bestValue ? (best==='mail' ? true :false)  : false,
                primaryClaimNumber :    responseCost.mailprimaryClaimNumber,
                primaryClaimSequence:   responseCost.mailprimaryClaimSequence,
                secondaryClaimNumber :  responseCost.mailSecondaryClaimNumber,
                secondaryClaimSequence: responseCost.mailSecondaryClaimSequence,
                PieShowMail:            responseCost.glovarmail,
                TextMonth:               responseCost.dispmnth,
                TextPercent  :            response.mail &&  response.mail.textpercent,//responseCost.textpercent,
                ShowPrice:                responseCost.showprice,
	            ShowMonthDaym:           response.mail && response.mail.month_day,//responseCost.month_day,
                PricePerMonth      :   responseCost.mailPricePerMonth,
                Pharmacy           :   "CVS/caremark Mail Service Pharmacy\u2122",
                bestHeading        :bestHeading,
		        brand: responseCost.brand,
                PricePerDay      :responseCost.mailPricePerDay,
                jiggy           :   responseCost.settle,
                settlementDesc  :   responseCost.settlementDesc,
                settlementInd    :responseCost.mailSettlementInd,
                settlementDescHeader:responseCost.mailSettlementDescHeader,
                settlementDescMsg:responseCost.mailSettlementDescMsg

            };
            var hideReqNewRx = false;
            if (drugPropertiesList) {
                var drugProperties = {};
                angular.forEach(drugPropertiesList, function (val) {
                    if (val.ndcId == responseCost.ndcId)
                        drugProperties = val;
                });

                //FR_417
                if (drugProperties && drugProperties.orderMyRefillsFamilyAccessTurnedOn=='true' && drugProperties.fastStartOptionOn=='true'){
                    //FR_416
                    if (drugProperties.compoundMedications=='true' || drugProperties.controlledSubstances=='true' || drugProperties.GPI=='true' ||
                        drugProperties.sensitiveMedications=='true')
                    {
                        hideReqNewRx = true;
                    }
                    //FR_418
                    if(drugProperties.displayRequestPresComp=='false')
                    {
                        hideReqNewRx = true;
                    }
                    //FR_419
                    //submittedInPast - The searched drug has been a FastStart Request within 30 Days.
                    //maintenance - false - Non-Maintenance Drug
                    //The searched drug for the same Member is already in the Shopping Cart. - covered by portaljson cart state check
                    //planRestriction - The Member's benefit plan's active mail benefits expire within 14 days.
                    //newDrug - The searched drug is a Retail Only drug.The searched drug is a Refill./The searched drug is a Renewal./The searched drug is enrolled in Readyfill at Mail for Refills or Renewals.
                    if(drugProperties.submittedInPast=='true'|| drugProperties.maintenance=='false' || drugProperties.newDrug=='false' ||
                        drugProperties.planRestriction=='true')
                    {
                        hideReqNewRx = true;
                    }
                }
                else{
                    hideReqNewRx = true;
                }

            }else{
                hideReqNewRx = true;
            }

            obj['hideReqNewRx']=hideReqNewRx;
            responseDatamodel.Costs[placeholder].mail.push(obj);

        }else if(emptyMailBlock){
                obj={hideEveryThing:true};
                responseDatamodel.Costs[placeholder].mail.push(obj);
            }

        if(responseCost.retailPrice && retailMailInd.isRetail)
        { responseCost.showretailprice=true
            var PricetotalObjectArray=["N/A","N/A"];
            if(responseCost.retailPrice.costToday.indexOf(".")>-1) {
                   if( parseInt(responseCost.retailPrice.costToday.split(".")[0])==0&&parseInt(responseCost.retailPrice.costToday.split(".")[1])==0 || (responseCost.retailPrice.costToday && parseInt(responseCost.retailPrice.costToday)==0))
                   {
                       /*PricetotalObjectArray[0]=0;
                       PricetotalObjectArray[1]=0;
                       responseCost.showretailprice=false;*/
                       responseCost.showretailprice=true;

                   }
                else {
                       PricetotalObjectArray = responseCost.retailPrice.costToday.split(".");
                       responseCost.showretailprice=true;
                   }
            }else if(responseCost.retailPrice.costToday && responseCost.retailPrice.costToday !=="N/A"){
                responseCost.showretailprice=true;
            }else{
                responseCost.showretailprice=false;
            }

            var obj = {
                PricetotalObject   : {integer:PricetotalObjectArray[0],decimal:PricetotalObjectArray[1]},
                Price             :   responseCost.retailPrice,
                Percentage        :   responseCost.retailPercentage,
                Months            :  response.retail && response.retail.retailMonths ?response.retail.retailMonths :0,//responseCost.retailMonths,
                bestValueInd:  bestValue ? (best==='mail' ? false :true)  : false,
                primaryClaimNumber : responseCost.retailprimaryClaimNumber,
                primaryClaimSequence:responseCost.retailprimaryClaimSequence,
                secondaryClaimNumber : responseCost.retailSecondaryClaimNumber,
                secondaryClaimSequence:responseCost.retailSecondaryClaimSequence,
                  PieShowRetail:         responseCost.glovarretail,
                TextMonth1:               responseCost.dispmnth,
                TextPercent  :             response.retail && response.retail.textpercent,//responseCost.textpercent,
                ShowRetPrice:              responseCost.showretailprice,
               ShowMonthDayr:       response.retail && response.retail.month_day,//responseCost.month_day,
                PricePerMonth      :   responseCost.retailPricePerMonth,
                Pharmacy           :   retailMailInd.pharmacy && retailMailInd.pharmacy.pharmacyName?(typeof retailMailInd.pharmacy.pharmacyName =='object'? retailMailInd.pharmacy.pharmacyName.__cdata:retailMailInd.pharmacy.pharmacyName) : "CVS/caremark Retail Service Pharmacy\u2122",
                bestHeading        :bestHeading,
                PricePerDay      :responseCost.retailPricePerDay,
                jiggy           :   responseCost.settle,
                settlementDesc  :   responseCost.settlementDesc,
                settlementInd    :responseCost.retailSettlementInd,
                settlementDescHeader:responseCost.retailSettlementDescHeader,
                settlementDescMsg:responseCost.retailSettlementDescMsg



            };
            //console.log(typeof retailMailInd.pharmacy.pharmacyName =='object');
            responseDatamodel.Costs[placeholder].retail.push(obj);
        }else if(emptyRetailBlock){
            obj={hideEveryThing:true};
            responseDatamodel.Costs[placeholder].retail.push(obj);
        }
    };
    return datamodel;
});