'use strict'

// making a central factory for errors, easier to handle error messages
checkDrugCostFactory.factory('errors', [function(){
    var errors = [
      {
        "errorCode": "0",
        "errorMessage": "Operation Timed Out, Please Try again Later"
      },
      {
        "errorCode": "500",
        "errorMessage": "We are sorry. We are unable to process your request."
      },
      {
        "errorCode": "401",
        "errorMessage": "Operation Not Allowed. Please Try Again Later."
      },
      {
        "errorCode": "001",
        "errorMessage": "Your member information is not authenticated"
      },
      {
        "errorCode": "002",
        "errorMessage": "Service Error"
      },
      {
        "errorCode": "003",
        "errorMessage": "Please select any drug and its strength"
      },
      {
        "errorCode": "004",
        "errorMessage": "Zip code or city and state is invalid"
      },
      {
        "errorCode": "005",
        "errorMessage": "Invalid Zip Code"
      },
      {
        "errorCode": "006",
        "errorMessage": "Distance is required"
      },
      {
        "errorCode": "007",
        "errorMessage": "Please select the drug dosage"
      },
      {
        "errorCode": "008",
        "errorMessage": "No results found. Check your spelling or enter just the first 3 letters of the drug you wish to price, then try again."
      },
      {
        "errorCode": "009",
        "errorMessage": "Some parts of Caremark.com may be unavailable at this time. If the problem persists, please call Customer Care at the number on your prescription benefit ID card."
      },
      {
        "errorCode": "010",
        "errorMessage": "We could not find a pharmacy that matched your search criteria. Please check your spelling and/or make sure the zip code is accurate, then try again."
      },
      {
        "errorCode": "011",
        "errorMessage": "This medication/supply is not covered under your Benefit Plan."
      },
      {
        "errorCode": "012",
        "errorMessage": "Member Not Found"
      },
      {
        "errorCode": "013",
        "errorMessage": "The dosage field requires a number greater than zero. Please make corrections and try again"
      },
      {
        "errorCode": "014",
        "errorMessage": "Enter a valid dosage amount."
      },
      {
        "errorCode": "015",
        "errorMessage": "Remove any spaces and/or letters before or after the numeric entered. Please make corrections below."
      },
      {
        "errorCode": "016",
        "errorMessage": "The days field requires a number greater than zero. Please make corrections below"
      },
      {
        "errorCode": "017",
        "errorMessage": "Enter 1 to 365 days."
      },
      {
        "errorCode": "018",
        "errorMessage": "Please contact your plan benefit administrator to get pricing for this drug."
      },
      {
        "errorCode": "019",
        "errorMessage": ""
      },
      {
        "errorCode": "020",
        "errorMessage": ""
      },
      {
        "errorCode": "021",
        "errorMessage": "Please log in to manage your prescriptions."
      },
        {      
            "errorCode": "022",
            "errorMessage": "Enter the number of pills."
        },
        {
            "errorCode": "023",
            "errorMessage": "Geo-location service not available."
        },{
            "errorCode": "024",
            "errorMessage": "No location data found."
        },{
            "errorCode": "025",
            "errorMessage": "Location zipCode could not be found."
        },{
            "errorCode": "026",
            "errorMessage": "User location could not be retrieved."
        },{
            "errorCode": "027",
            "errorMessage": "Zip code found is not valid."
        }
    ];

    errors.getErrorMessage = function(errorNumber){
        var message = "";
        angular.forEach(errors,function(value,key){
            if(errorNumber == value.errorCode)
                message= value.errorMessage;
        });
        return message;
    }

    return errors;

}]);
