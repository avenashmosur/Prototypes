'use strict';

//checkDrugCost Service Factory
checkDrugCostService.service('costResultDataServices', function () {

    var datamodel = {};
    var responseDatamodel={};

    datamodel.formDataModel = function(response,placeholder )
    {


        responseDatamodel = {};
        responseDatamodel.drugDetails = new Array();
        if(response.brand) {


            var bestValueInd =response.best.ind;
            var best;
            if(bestValueInd && response.best.type.indexOf('brand') > -1 ){
                bestValueInd = true;
                if(response.best.type.indexOf('Mail') > -1 ){
                    best ="mail";
                }else{
                    best ='retail'
                }
            }else{
                bestValueInd = false;
            }

            /*if(response.mailDosageQuantity && response.mailDosageSupply) {
                responseDatamodel.drugname[responseDatamodel.drugname.length-1].push({
                    dosage: datamodel.formDosage(response.mailDosageQuantity, response.mailDosageSupply, "Home Delivery"),
                    cost: datamodel.formCost(response.brand,"mail")
                });
            }*/
           /* responseDatamodel.drugname[responseDatamodel.drugname.length-1].brand = true;
            if(response.retailDosageQuantity && response.retailDosageSupply)
            {*/
                    if (responseDatamodel.drugDetails) {

                        responseDatamodel.drugDetails.push(
                            {

                                name: datamodel.formLabel(response.brand,'brand','Covered by Your Plan',"Best Value:",bestValueInd,best,response.isStCob),
                                "items": datamodel.addCostDosgaeDetails(response,"brand",bestValueInd,best,placeholder,"Best Value:")

                            }
                        );
                    }

           // }
        }




        if(response.generic) {
            var bestValueInd =response.best.ind;
            var bestHeading;
            if(bestValueInd && response.best.type.indexOf('generic') > -1 ){
                bestValueInd = true;
                if(response.best.type.indexOf('Mail') > -1 ){
                    best ="mail";
                }else{
                    best="retail"
                }
            }else{
                bestValueInd = false;
            }

            if(!(response.brand)){
                bestHeading="Best Value:"
            }else{
                bestHeading="Save money with generic equivalent:"
            }
            //datamodel.formLabel(response.generic,'generic Equivalent','Covered by your plan');
            if (responseDatamodel.drugDetails) {
                responseDatamodel.drugDetails.push(
                    {
                        name: datamodel.formLabel(response.generic,'generic Equivalent','Covered by Your Plan',"Save money with generic equivalent:",bestValueInd,best,response.isStCob),
                        "items": datamodel.addCostDosgaeDetails(response,"generic",bestValueInd,best,placeholder,bestHeading)

                    }
                );
            }

            /*if(response.mailDosageQuantity && response.mailDosageSupply) {
                responseDatamodel.drugname[responseDatamodel.drugname.length-1].push({
                    dosage: datamodel.formDosage(response.mailDosageQuantity, response.mailDosageSupply, "Home Delivery"),
                    cost: datamodel.formCost(response.generic,"mail")
                });
                responseDatamodel.drugname[responseDatamodel.drugname.length-1].generic = true;
            }

            if(response.retailDosageQuantity && response.retailDosageSupply)
            {
                    if (responseDatamodel.drugname) {
                        responseDatamodel.drugname[responseDatamodel.drugname.length-1].push({
                            dosage: datamodel.formDosage(response.retailDosageQuantity, response.retailDosageSupply, "In-Store pickup"),
                            cost: datamodel.formCost(response.generic,"retail")
                        });
                    }
            }*/
        }



        return responseDatamodel;
    };


    datamodel.addCostDosgaeDetails = function(response,type,bestValueInd,best,placeholder,bestHeading)
    {

       var items=[];


        if(response.mailDosageQuantity && response.mailDosageSupply && response.dataInd.isMail) {
            items.push({
                dosage: datamodel.formDosage(response.mailDosageQuantity, response.mailDosageSupply, "Mail service",placeholder,response.dataInd && response.dataInd.isMChoiceMember,response.dataInd && response.dataInd.isSolid),
                cost: datamodel.formCost(response[type],"mail",response.hasCommon,bestValueInd,best,response.dataInd,response,bestHeading),
                isMail: response.dataInd.isMail,
                isRetail: false
            });
        }

        if(response.retailDosageQuantity && response.retailDosageSupply  && response.dataInd.isRetail) {

                items.push({
                    dosage: datamodel.formDosage(response.retailDosageQuantity, response.retailDosageSupply, "Store pickup",placeholder,false,response.dataInd && response.dataInd.isSolid),
                    cost: datamodel.formCost(response[type], "retail",response.hasCommon,bestValueInd,best,response.dataInd,response,bestHeading),
                    isRetail: response.dataInd.isRetail,
                    isMail: false
                });

        }
        return items;
    }

    datamodel.formLabel = function(drugLabel,type,planDetail,heading,bestValueIndicator,best,isStCob)
    {


        var obj = {
            drugName        :   drugLabel.drugName,
            drugForm        :   drugLabel.drugForm,
            drugStrength    :   drugLabel.drugStrength,
            drugType        :   type,
            planDetail      :   planDetail,
            heading         :   heading,
            bestValueInd    :   bestValueIndicator ? best ==='mail'? true : false : false,
            bottomBorder    :   best ==='retail'? true : false,
            ndcId           :   drugLabel.ndcId,
            isStCob         :   isStCob,
            coveredByPlanInd      : drugLabel.coveredByPlanInd


        };

        return obj;
        //responseDatamodel.drugname[obj.index]=[];
        //responseDatamodel.drugNames.drugDetails.push(obj);

    };

    datamodel.formDosage = function(DosageQuantity,DosageSupply,purchaseType,placeholder,isMChoice,isSolid)
    {
        var obj = {
            DosageQuantity  :   DosageQuantity + ' tablets',
            DosageSupply    :   DosageSupply,
            purchaseType    :   purchaseType,
            isMChoiceMember:    isMChoice?isMChoice :false,
            isSolid         :   isSolid? isSolid :false
        };
        if(purchaseType == "Mail service")
            obj.maildelivery = true;
        else if(purchaseType == "Store pickup")
            obj.retaildelivery = true;
        return obj;
    };

    datamodel.formCost = function(responseCost,type,hasCommon,bestValue,best,retailMailInd,response,bestHeading)
    {
        if(type == 'mail')
        {
            if(responseCost.mailPrice)
            {
                var obj = {
                    PricetotalObject    :   responseCost.mailPricetotalObject,
                    Months              :   response.mail && response.mail.mailMonths? response.mail.mailMonths :responseCost.mailMonths || 0,
                    Price               :   responseCost.mailPrice,
                    Percentage          :   responseCost.mailPercentage,
                    bestValueInd  :   bestValue ? (best==='mail' ? true :false)  : false,
                    Pharmacy           :   "CVS/caremark Mail Service Pharmacy\u2122",
                    ShowPrice:                responseCost.showprice,
                    ShowMonthDaym:           response.mail && response.mail.month_day,//responseCost.month_day,
                    TextPercent  :            response.mail &&  response.mail.textpercent,//responseCost.textpercent,
                    PricePerMonth      :   responseCost.mailPricePerMonth,
                    bestHeading        :bestHeading,
                    brand: responseCost.brand,
                    PricePerDay      :responseCost.mailPricePerDay,
                    settlementInd    :responseCost.mailSettlementInd,
                    settlementDescHeader:responseCost.mailSettlementDescHeader,
                    settlementDescMsg:responseCost.mailSettlementDescMsg
                }

                //responseDatamodel.Costs[placeholder].mail.push(obj);
             return obj;

            }
        }
        else if(type == 'retail')
        {
            if(responseCost.retailPrice)
            {
                var obj = {
                    PricetotalObject    :   responseCost.ratailPricetotalObject,
                    Months            :   response.retail && response.retail.retailMonths ?response.retail.retailMonths :responseCost.retailMonths ||0,
                    Price             :   responseCost.retailPrice,
                    Percentage        :   responseCost.retailPercentage,
                    bestValueInd:  bestValue ? (best==='mail' ? false :true)  : false,
                    Pharmacy           :   retailMailInd.pharmacy && retailMailInd.pharmacy.pharmacyName?(typeof retailMailInd.pharmacy.pharmacyName =='object'? retailMailInd.pharmacy.pharmacyName.__cdata:retailMailInd.pharmacy.pharmacyName) : "CVS/caremark Retail Service Pharmacy\u2122",
                    ShowRetPrice:              responseCost.showretailprice,
                    TextPercent  :             response.retail && response.retail.textpercent,//responseCost.textpercent,
                    PricePerMonth      :   responseCost.retailPricePerMonth,
                    bestHeading        :bestHeading,
                    PricePerDay      :responseCost.retailPricePerDay,
                    settlementInd    :responseCost.retailSettlementInd,
                    settlementDescHeader:responseCost.retailSettlementDescHeader,
                    settlementDescMsg:responseCost.retailSettlementDescMsg,
                    ShowMonthDayr:       response.retail && response.retail.month_day//responseCost.month_day,
                }

                //responseDatamodel.Costs[placeholder].retail.push(obj);
                return obj;
            }
        }
    };





    return datamodel;
});