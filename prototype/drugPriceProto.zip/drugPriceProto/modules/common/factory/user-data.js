/**
 * Created by Z179603 on 4/6/2015.
 */

'use strict';

// activeModel: Caching app data that will be used throughout the app

checkDrugCostFactory.factory('userSessionData', [function(){

    var userInfo={},
        service = {
            getLoggedInUserInfo : function(){
                return userInfo.memberDetail;
            },
            setLoggedInUserInfo : function(memberDetail){
                userInfo.memberDetail = memberDetail;
            },
            getSelectedUserName : function(){
                return userInfo.selectedUserName;
            },
            setSelectedUserName : function(userName){
                userInfo.selectedUserName = userName;
            },
            getSelectedPharmacy : function(){
                return userInfo.selectedPharmacy;
            },
            setSelectedPharmacy : function(selectedPharmacy){
                userInfo.selectedPharmacy = selectedPharmacy;
            },
            getSelectedDosage : function(){
                return userInfo.selectedDosage;
            },
            setSelectedDosage : function(selectedDosage){
                userInfo.selectedDosage = selectedDosage;
            },
            getSelectedDrugName : function(){
                return userInfo.selectedDrugName;
            },
            setSelectedDrugName : function(selectedDrugName){
                userInfo.selectedDrugName = selectedDrugName;
            },
            getSelectedDrugDetails : function(){
                return userInfo.selectedDrug;
            },
            setSelectedDrugDetails : function(selectedDrug){
                userInfo.selectedDrug = selectedDrug;
            },
            getBestValue : function(){
                return userInfo.bestValue;
            },
            setBestValue : function(bestValue){
                userInfo.bestValue = bestValue;
            },
            getAdditionalPharmacies : function(){
                return userInfo.additionalPharmacies;
            },
            setAdditionalPharmacies : function(additionalPharmacies){
                userInfo.additionalPharmacies = additionalPharmacies;
            }
        };
 return  service;
}]);
