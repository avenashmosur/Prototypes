checkDrugCostService.service('CoreCommonsModal', ['$modal','$rootScope','$timeout','help', function ($modal,$rootScope,$timeout,help) {


    var modalOptions = {
        "templateUrl": '',
        "windowTemplateUrl": 'modules/common/views/window.html',
        "windowClass": '',
        "resolve": '',
        "size": '',
        "callback": '',
        "backdrop": 'static'
    };

    if(help.getUserAgent().indexOf('MOBILE')!==-1){
        modalOptions['windowClass']='IOS-keypad';
    }

    var staticOptions = {
        "templateUrl": '',
        "windowTemplateUrl": '',
        "windowClass": '',
        "resolve": '',
        "size": '',
        "callback": '',
        "backdrop": ''
    };
    var StaticModalOptionObjs = {};
    var modalObj = {};

    this.generalModal = function (modalProperties, staticModalProperties) {
        /*if ($('.modal').hasClass('in')) { //Check if the modal is already showing
         return;
         }*/
            var parent = $(window.frameElement).parent().closest('body');
            var parentHeight=$(window.frameElement).parent().closest('body').height();
            var parentWidth=$(window.frameElement).parent().closest('body').width();
            $(window.frameElement).css({
                "z-index":"100",
                "position":"relative"
            })
            $(parent).append( "<div id='parentmodel' style='z-index:98;height:100%;width:100%;position:fixed;background-color:#000000;filter:alpha(opacity=50); opacity: 0.5;top:0'></div>" );
        //Create temp objects to work with since we're in a singleton service
        var ModalOptionObjs = {};

        if (staticModalProperties) {
            StaticModalOptionObjs = {};
            angular.extend(StaticModalOptionObjs, staticOptions, staticModalProperties);
        }

        //Map angular-ui modal custom defaults to modal defaults defined in service
        angular.extend(ModalOptionObjs, modalOptions, modalProperties);


        if (!ModalOptionObjs.controller) {
            ModalOptionObjs.controller = function ($timeout, $scope, $modalInstance) {

                //initializing the template data
                $scope.isModalActive = true;

                if (ModalOptionObjs.data) {
                    $scope = angular.extend($scope, ModalOptionObjs.data);
                }
                /*if(ModalOptionObjs.data) {
                 $scope.modalData= ModalOptionObjs.data;
                 }*/

                $scope.closeModel = function () {
                    if ($modalInstance) {
                        if (StaticModalOptionObjs.close) {
                            StaticModalOptionObjs.close();
                        }
                        else if (ModalOptionObjs.close) {
                            ModalOptionObjs.close();
                        }
                        $modalInstance.dismiss();
                    }
                };


                $scope.dismissModal = function () {
                    if ($modalInstance) {
                        $modalInstance.dismiss();
                    }
                };

                $scope.submit = function (data) {

                    if ($modalInstance) {
                        if ((ModalOptionObjs && !ModalOptionObjs.callback) && StaticModalOptionObjs.callback) {
                            StaticModalOptionObjs.callback(data);
                        }
                        else if (ModalOptionObjs.callback) {
                            ModalOptionObjs.callback(data);
                        }
                        //$modalInstance.dismiss();
                    }
                };

                //$scope.$on('$viewContentLoaded') event not works for modal
                //fixing above bug with custom element ready directive bind with below function.
                /*$scope.viewContentLoaded = function () {
                    if (ModalOptionObjs && ModalOptionObjs.onReady) {
                        ModalOptionObjs.onReady();
                    }
                };*/

                /*$scope.$on('$viewContentLoaded', function(event) {

                 if(ModalOptionObjs && ModalOptionObjs.onReady) {
                 ModalOptionObjs.onReady("test");
                 }
                 });*/
            }
        }
        modalObj = $modal.open(ModalOptionObjs);
        modalObj.result.then(function () {
             // alert('Modal success at:' + new Date());
        }, function () {
               $(window.frameElement).parent().closest('body').find("#parentmodel").remove();
                        $(window.frameElement).css({
                "z-index": " ",
                "position": " "
            })
        });
        return modalObj.result;


    };
    this.pharmacyLocator = function (modalProperties,staticModalProperties) {
        this.generalModal(modalProperties,staticModalProperties);
    };
    this.newDrugSearch = function (modalProperties)//added this to support for drug cost details
    {
        this.generalModal(modalProperties);
    };
    this.viewDrugCostDetails = function (modalProperties)//added this to support for drug cost details
    {
        this.generalModal(modalProperties);
    };
    this.printDrugDetails = function (modalProperties)//added this to support for drug cost details
    {
        this.generalModal(modalProperties);
    };
    this.gsmAlchemyPopPreview = function (modalProperties) {
        this.generalModal(modalProperties);
    };
    this.helpPopPreview = function (modalProperties) {
        this.generalModal(modalProperties);
    };

}]);