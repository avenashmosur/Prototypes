/**
 * Created by Z179604 on 5/15/2015.
 */

'use strict';

//checkDrugCost Service Factory
checkDrugCostService.service('cdcServices', ['requestService', function (requestService) {

    var service = {};

    service.getMemberInfoByToken = function (params) {
        return requestService.makeRequest(config.serviceNames.getMemberInfoByToken, params);
    };

    service.getDrugPrice = function (params) {
        return requestService.makeRequest(config.serviceNames.drugPrice, params);
    };
    service.getTADDrugPrice = function (params) {
        return requestService.makeRequest(config.serviceNames.tadDrugPrice, params);
    };

    service.getDrugDetails = function (params, hideLoader) {
        return requestService.makeRequest(config.serviceNames.drugDetails, params,null,hideLoader);
    };

    service.getDrugProperties = function (params, data) {
        params["operationName"]="getDrugProperties";
        params["version"]="2.0";
        params["serviceName"]="drugDetails";
        return requestService.makeRequest(config.serviceNames.drugProperties, params, data);
    };

    service.getPharmacyLocator = function (params) {
        return requestService.makeRequest(config.serviceNames.pharmacyLocator, params);
    };
    //To be removed
    service.getTADHealthInformation = function (params) {
        return requestService.makeRequest(config.serviceNames.getTADHealthInformation, params);
    }; //End

    service.getDrugIndicationsByNDCId = function (params, data) {
        return requestService.makeRequest(config.serviceNames.getDrugIndicationsByNDCId, params, data);
    };

    service.getDrugAlternatives = function (params, data) {
        return requestService.makeRequest(config.serviceNames.getDrugAlternatives, params, data);
    };

    service.getGSMAlchemy = function (params, data) {
        return requestService.makeRequest(config.serviceNames.GSMAlchemy, params, data);
    };

    service.getClaimDetails = function (params, data) {
        return requestService.makeRequest(config.serviceNames.getClaimDetails, params, data);
    };

    service.getPZNByIDandResourcetag = function (params, data) {
        params["operation"]="getPZNByIDandResourcetag";
        return requestService.makeRequest(config.serviceNames.personalization, params, data);
    };

    return service;

}]);