/**
 * Created by Z179603 on 5/13/2015.
 */

checkDrugCostFactory.factory('FastContentService', [function () {
    var desktopContent = {
        "common": {
            "disclaimer": "Disclaimers:<br/>This coverage information is based on information provided to CVS Caremark by your benefits administrator as of April 21, 2015. " +
            "This information, and estimated drug prices are subject to change. For complete details, refer to your Plan brochure or policy. CVS Caremark " +
            "must fill your prescriptions for the exact amount prescribed by your doctor, or the day supply limit specied by your benet plan, whichever is less." +
            "<br/><br/>Your annualized cost is calculated by multiplying the co-payment plus any potential penalty amounts by the maximum number of times you can order your" +
            " prescription within a year, however may not display due to plan design, deductible or other factors that do not allow for an accurate annual cost calculation." +
            "<br/><br/>Your plan may allow a higher quantity and days supply. Change quantity and/or days supply to make changes and obtain a new estimate." +
            "<br/><br/>CVS Caremark may have nancial relationships with the manufacturers of the listed products." +
            "<br/><br/>If your prescription benefits include CVS Caremark's Mail Service program, you are eligible to order your non-covered prescriptions through Caremark Direct�." +
            "<br/><br/>* Your Cost-Annual represents the cost you may pay for a drug in a one-year period. Since the deductible has not yet been met, your annual cost will not be estimated." +
            "<br/><br/>This tool provides useful information to help you review plans based on your current drug needs. The drug costs displayed are estimates and may vary based on the specific" +
            "quantity, strength and/or dosage of the medication, the order in which you purchase your prescriptions, and the pharmacy you use." +
            "<br/><br/>You may fill your 90-day supply prescription at CVS/pharmacy." +
            "<br/><br/>Drug type does not imply or guarantee the product is dispensed by your pharmacy, or will be at a certain copayment amount or tier. Use the Check Drug Coverage and Cost" +
            "for estimates. Coverage and cost estimates are based on commonly dispensed products for the drug name, strength, dosage form selected, and package size. Actual" +
            "coverage and pricing may vary at the time of fulfillment. Formulary information may not be illustrated if information is unavailable or does not apply.",
            "mainDisclaimer":"Estimated usage, costs and savings are calculated through current plan year or the end of current calendar year. Actual savings may vary depending on plan structure, deductibles, previous payments, future claims and prior authorizations.",
            "COBDisclaimer_yourCost": "* Your Cost-Annual represents the cost you may pay for a drug in a one-year period.",
            "COBDisclaimer_totalCost":"Total Cost means the total amount of the prescription in accordance with the plan participant's applicable benefit plan, which may be a deductible, a percentage of the prescription price, a fixed amount or other charge PLUS the balance, if any, paid by the benefit plan.",
            "COBDisclaimer_primary":"Your prescription benefit consists of a primary plan and a supplemental coverage plan. You are now able to receive a consolidated view of both plans via this account.",
            "COBDisclaimer_waiver":"Your claim was eligible for waiver/reduction of your cost share. This benefit has a date/drug expiration that may not be available on your next refill.",
            "COBDisclaimer_benefitPlan":"Your cost is the amount the member is required to pay to obtain the prescription in accordance with the member's benefit plan.",
            "COBDisclaimer_adminFee":"Cost includes a vaccine administration fee.",
            "service_unavailable":"Some parts of Caremark.com may be unavailable at this time. If the problem persists, please call Customer Care at the number on your prescription benefit ID card.",
            "personalization": {
                "CDC_DISP_REQ_PRESC_COMP": {
                    "id": "40000025",
                    "resourceTagName":"CDC_DISP_REQ_PRESC_COMP"
                },
                "CDC_DISPLAY_TAD_COMPONENT": {
                    "id": "40000033",
                    "resourceTagName":"CDC_DISPLAY_TAD_COMPONENT"
                },
                "CDC_DISPLAY_TALK_TO_DOC": {
                    "id": "6131",
                    "resourceTagName":"CDC_DISPLAY_TALK_TO_DOC"
                },
                "CDC_DISPLAY_PIE_CHART_MAIL": {
                    "id": "6132",
                    "resourceTagName":"CDC_DISPLAY_PIE_CHART_MAIL"
                },
                "CDC_DISPLAY_PIE_CHART_RETAIL": {
                    "id": "6133",
                    "resourceTagName":"CDC_DISPLAY_PIE_CHART_RETAIL"
                },
                "PLAN_VERBIAGE": {
                    "id": "6134",
                    "resourceTagName":"PLAN_VERBIAGE"
                },
                "COST_BREAKDOWN_SHOW_CURRENT_COST": {
                    "id": "615",
                    "resourceTagName":"COST_BREAKDOWN_SHOW_CURRENT_COST"
                },
                "COST_BREAKDOWN_SHOW_ANNUAL_COST": {
                    "id": "616",
                    "resourceTagName":"COST_BREAKDOWN_SHOW_ANNUAL_COST"
                },
                "COST_BREAKDOWN_SHOW_PRIMARY_PAY": {
                    "id": "617",
                    "resourceTagName":"COST_BREAKDOWN_SHOW_PRIMARY_PAY"
                },
                "COST_BREAKDOWN_SHOW_SECONDARY_PAY": {
                    "id": "618",
                    "resourceTagName":"COST_BREAKDOWN_SHOW_SECONDARY_PAY"
                },"CUSTOM_PHARMACY_NETWORK_ID":{
                    "id":"1001",
                    "resourceTagName":"CUSTOM_PHARMACY_NETWORK_ID"
                }
            }
        },
        "index": {},
        "commonHeader": {
            "header": "Check Drug Cost and Coverage",
            "priceVaryMsg1": "Price varies by person and location.",
            "priceVaryMsg2": "Price varies by location.",
            "newSearch": "Search New Drug"
        },
        "dosage": {
            "header": "How often would you like to take this medication",
            "label": {
                "common": "Use the most common amount and frequency",
                "custom": "Use the amount and frequency below",
                "customMsg1": "I would take",
                "customMsg2": "pill(s) every",
                "customMsg3": "How many days' supply? (optional)"
            },
            "btn": {
                "update": "Update",
                "cancel": "Cancel"
            },
            "error": {
                "validDosage": "Enter a valid dosage amount.",
                "validDays": "Enter 1 to 365 days.",
                "lessDays": "You must select more than 15 days to view a mail service price. Please change your intended schedule.",
                "lessDaysMailSupply":"We can't show mail service prices for less than a 16-day supply."
            }
        },
        "dose": {},
        "drugSearch": {
            "btn": {
                "search": "Search",
                "editPharmacy": "Change pharmacy",
                "editDosage": "Edit dosage",
                "editSearchCriteria": "Edit search criteria",
                "closeSearchCriteria": "Close search criteria"
            },
            "placeholder": {
                "searchTxt": "Enter first 3 letters of drug name.",
                "commonDosage": "Most common",
                "enterDosage": "Enter your dosage."
            },
            "header": {
                "search": "Search New Drug",
                "patient": "Patient",
                "pharmacy": "Pharmacy",
                "dosage": "Dosage"
            },
            "toolTip": {
                "noSavedPharmacy": "You have not chosen a primary pharmacy, so we will use the pharmacy closest to your ZIP code. You can change the phamacy on the results page or choose a primary pharmacy in the Pharmacy Locator tool.",
                "noPharmacy": "Please choose a pharmacy so we can provide accurate pricing.",
                "noDosage": "We need a dosage to price this drug. Edit the dosage to enter how much of this medication you take and how often."
            },
            "errorMsgs": {
                "noResults":"No results found. Check your spelling or enter just the first 3 letters of the drug you wish to price, then try again.",
                "drugSearchedAlready": "You have already searched for this drug. Check your results below.",
                "currentSearch":"currentsearch",
                "pastSearch":"pastsearch"
            }
        },
        "searchResults": {
            "cost": {
                "btn": {
                    "editPharmacy": "Change pharmacy",
                    "rqstPrs": "Request a New Prescription",
                    "addPharmacies": "Check Price at Additional Pharmacy",
                    "addPharMaxError1": "You\'ve reached the limit of 5 in-store pharmacies.",
                    "duplicateAddPharmacy": "You have already priced this drug at this pharmacy. Check your results below.",
                    "addPharMaxError2": "To see pricing at another pharmacy, please remove one of your pharmacy searches above.",
                    "viewOrder": "View order"
                },
                "label": {
                    "searched": "You searched for:",
                    "brand": "Brand",
                    "plan": "Covered by Your Plan",
                    "daysSupply": "-day supply",
                    "homeDelivery": "Mail service",
                    "tablets": "tablets",
                    "InStorePickup": " Store pickup",
                    "reqDoctorPrescription": "Ask your doctor about this dosage.",
                    "reqPrescriptionAdded": "This prescription has been added to your order.",
                    "genericHeader": "Save money with the generic equivalent:",
                    "generic": "Generic",
                    "priceVariesMsg": "(price varies by person and location)",
                    "lowestPrice": "Lowest price :",
                    "usrNameFor": "For :",
                    "pharmacy": "Pharmacy : ",
                    "dosage": "Dosage : ",
                    "youPay": "You pay",
                    "empPay": "Your <personalize>plan</personalize> pays",
                    "ofTheCost": "of the cost. "
                }
            },
            "costBreakDown": {
                "mailDrugChannel":"CVS/caremark Mail Service Pharmacy™"
            },
            "tad": {
                "btnSeeAlternatives": "See Alternatives",
                "seeAltCondChkDesc": " Get the most appropriate medication options by telling us why you are taking or would take this drug. We do not store this information.",
                "patientCondDesc1": "Have the same chemical type of active ingredient",
                "patientCondDesc2": "Are used for a particular condition the same way.",
                "tadListHealthDesc": " The drugs below are in the same class as the searched drug. The class is ",
                "tadListClassDesc": "Drugs in the same class:",
                "btnEdit": "Edit the reason why you're taking it.",
                "tadDesc": "The drug you searched has one or more therapeutic Alternatives that treat the same condition, are just as safe and effective, and may save you or your plan money.",
                "tadHeader": "Therapeutic Alternatives",
                "wrongText": "Wrong type of drug? ",
                "noTad": "The drug you searched has no therapeutic Alternatives."
            }
        },
        "costDetail": {
            "heading": "Cost Details"
        }
    };

    // mobile related content changes
    var mobileContent=angular.copy(desktopContent);
    mobileContent.dosage.label.customMsg2="Every";
    mobileContent.drugSearch.placeholder.searchTxt="Enter Drug Name";
    mobileContent.drugSearch.placeholder.commonDosage="Most Common Dosage";
    mobileContent.drugSearch.btn.editPharmacy="";
    mobileContent.drugSearch.btn.editDosage="";

   return {
        'desktopContent':desktopContent,
        'mobileContent':mobileContent
    }
}]);