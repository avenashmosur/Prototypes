'use strict';

checkDrugCostFactory.factory("localytics",['$rootScope','$route',function($rootScope,$route){
	
	function getPageName(){
    	var url=$route.current.templateUrl;
    	if(url.search('home')!=-1){
    		return 'Easy Refill Start Page';
    	}if(url.search('confirmation')!=-1){
    		return 'Easy Refill Order Confirmation';
    	}if(url.search('review')!=-1){
    		return 'Easy Refill Review Order';
    	}
    	
    	return "No URL";
    }

    $rootScope.$on('formErrors',function(event,message){
    	var errorMsg='';
        angular.forEach(message,function(val){
        	errorMsg = errorMsg+val+";";
            
        });
        if(errorMsg!="")
        	{
        ltOnError(getPageName(),errorMsg.substring(0, errorMsg.length-1));
        	}

    });
    
    var ltOnScreenLoad=function(screen_name){
    	console.debug(JSON.stringify({
    		"SCREEN":"CDC|"+screen_name
    	}))
		
		try{
    	native.invokeAnalytics(JSON.stringify({
    		"SCREEN":"CDC|"+screen_name
    	}));
    	}
    	
    	catch(e){
    		console.log("Exception:" + e);
    		
    	}
	
    }
	
	var ltOnEvents = function(event, attributes) {
		try {

console.debug(JSON.stringify({
				EVENT : event,
				ATTRIBUTES : attributes
			}))
			native.invokeAnalytics(JSON.stringify({
				EVENT : event,
				ATTRIBUTES : attributes
			}));
		} catch (e) {
			console.log("Exception:" + e);
		}
	}
	
	var ltOnButtonTap =function(screenName,actionName)
	{
		var attributes = [ {
			"Screen Name" : screenName
		},
		{"Action Name" :actionName}
		
		];
		
		ltOnEvents("Button Tap:",attributes)
		
	}
	
	var ltOnClickOrAlert = function(pageName,eventType,navigationView,event)
	{
		
		var attributes = [ {
			Page_Name : pageName
		}, {
			event_type : eventType
		}, {
			
			Navigation_View:navigationView
		},{
			Page_Category : "Prescriptions and Coverage"
		}];
		ltOnEvents(event, attributes)
		
	}
	
	var ltOnFocus=function(pageName,scenerioStep)
	{
		var attributes = [ {
			Page_Name : pageName
		}, {
			event_type : "99"
		}, {
			Page_Category : "Prescriptions and Coverage"
		}, {
			Scenario_Name : "Easy refill"
		}, {
			Scenario_Step : scenerioStep
		} ];
		
		ltOnEvents("Field Focus", attributes);
	}
	

		var ltOnPageLoad = function(pageName, pageSubCategory,
			scenerioStep, customLTparameter) {

		var attributes = [ {
			Page_Name : pageName
		}, {
			event_type : "0"
		}, {
			Page_Category : "Prescriptions and Coverage"
		}, {
			Page_Sub_Category : pageSubCategory
		}, {
			Scenario_Name : "Easy refill"
		}, {
			Scenario_Step : scenerioStep
		} ];
		if (angular.isDefined(customLTparameter))

		{

			attributes=attributes.concat(customLTparameter);

		}

		ltOnEvents("Page Load", attributes);
	}
	var ltOnError = function(pageName,customLTparameter)
	{
		
		var attributes = [ {
			"Error Type:" : pageName
		}];
		
		if (angular.isDefined(customLTparameter))

		{

			attributes.push({"Error Message:":customLTparameter});

		}
		ltOnEvents("Error Message:", attributes);

		
	}
	
	return{
		
		ltOnPageLoad:ltOnPageLoad,
		ltOnFocus:ltOnFocus,
		ltOnError:ltOnError,
		ltOnClickOrAlert:ltOnClickOrAlert,
		ltOnScreenLoad:ltOnScreenLoad,
		ltOnButtonTap:ltOnButtonTap 
		
		
	}
	
	
}]);