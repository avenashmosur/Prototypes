'use strict';

/* Directives */
var checkDrugCostDirectives = angular.module('checkDrugCost.directives', []);

checkDrugCostDirectives.
    directive('appVersion', ['version', function (version) {
        return function (scope, elm, attrs) {
            elm.text(version);
        };
    }])

    .directive('commonHeader', ['help', 'CoreCommonsModal', function (help, CoreCommonsModal, $rootScope) {
        return {
            restrict: "A",
            scope: {
                "showIconsBtn": "@",
                "hidePrintIcon": "=",
                "openDrugSearch": "=",
                "newsearch": "&",
                "printcostdetails": "&",
                "hasMultipleMembers": "=",
                "showHelpPopup": "&"
            },
            templateUrl: "modules/common/views/common-header.html",
            link: function ($scope) {
                $scope.FastContent = help.readFASTContent();

                $scope.printStateOn = help.printStateOn;


                $scope.helpText = function () {

//          WebAnalytics code : Do not Delete
                    $scope.$emit('TealiumWebAnalytic', {"key": "HELP1"});
//          WebAnalytics code : Do not Delete

                    $scope.showHelpPopup();
                };

                $scope.newDrugSearchCheck = function () {
                    $scope.newsearch();
                };
            }
        }
    }])
    .directive('customPopover', ['$compile', '$templateCache', function ($compile, $templateCache) {
        var getTemplate = function (contentType) {
            var template = '';
            switch (contentType) {
                case 'user':
                    template = $templateCache.get("templateId.html");
                    break;
            }
            return template;
        };
        return {
            restrict: "A",
            scope: {
                "className": "@",
                "msg": "@",
                "placement": "@"
            },
            link: function (scope, element) {
                var popOverContent;
                var html = getTemplate("user");
                popOverContent = $compile(html)(scope);
                var options = {
                    content: popOverContent,
                    placement: scope.placement,
                    html: true
                };
                angular.element(element).popover(options);
            }
        };
    }])
    .directive('inputFormat', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                var regEx = /[^0-9]/g; // default as number only
                function fromUser(text) {
                    if (text) {
                        if (attr.inputFormat) {
                            regEx = new RegExp(attr.inputFormat, 'gi');
                        }
                        var transformedInput = text.replace(regEx, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }

                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })

    .directive('popOver', function ($compile) {
        var itemsTemplate = "<div class='unstyled'><p class='productDescription'>{{items}}</p></div>";
        var getTemplate = function (contentType) {
            var template = '';
            switch (contentType) {
                case 'items':
                    template = itemsTemplate;
                    break;
            }
            return template;
        };
        return {
            restrict: "A",
            transclude: true,
            template: "<span ng-transclude></span>",
            link: function (scope, element, attrs) {
                var popOverContent;
                if (scope.items) {
                    var html = getTemplate("items");
                    popOverContent = $compile(html)(scope);
                }
                var options = {
                    content: popOverContent,
                    placement: "right",
                    html: true,
                    title: scope.title
                };
                $(element).popover(options);
            },
            scope: {
                items: '=',
                title: '@'
            }
        };
    })
    ///alternative way for modal $viewContentLoaded since it is not working
    ///fixing issue with $viewContentLoaded
    .directive('elemReadyInitTooltip', function ($parse) {
        return {
            restrict: 'A',
            link: function ($scope, elem, attrs) {
                //var readyFunc = $parse(attrs.elemReady);
                elem.ready($('[data-toggle="popover"]').popover());
            }
        }
    })
    .directive('cachedTemplate', ['$templateCache', function ($templateCache) {
        "use strict";
        return {
            restrict: 'A',
            terminal: true,
            compile: function (element, attr) {
                if (attr.type === 'text/ng-template') {
                    var templateUrl = attr.cachedTemplate,
                        text = element.html();
                    $templateCache.put(templateUrl, text);
                }
            }
        };
    }])
    .directive('personlizeElement', ['personalization', 'serviceFactory','$compile', function(personalization, serviceFactory,$compile) {
        return {
            restrict: 'A',
            link: function(scope, elem, attrs) {

                function setToDOM(elem, dataReplace){
                    var innerText = (elem[0].innerHTML && elem[0].innerHTML.trim()) ||
                                    (elem[0].textContent && elem[0].textContent.trim());
                    innerText= innerText.replace(/&lt;/g,'<');
                    innerText= innerText.replace(/&gt;/g,'>');
                    var personalize = innerText.match("<personalize>(.*)</personalize>");
                    if (personalize) {
                        if(!dataReplace){
                            dataReplace = innerText.replace(personalize[0], personalize[1]);
                        }else{
                            dataReplace= innerText.replace(personalize[0], dataReplace);
                        }
                        elem[0].innerHTML = dataReplace;
                        $compile(elem.contents())(scope);
                    }
                }

                if (!angular.isUndefined(attrs["personlizeElement"])) {
                    var resourceTag = JSON.parse(attrs["personlizeElement"]);
                    personalization.getPersonlizationContent().then(function(personlizationContent) {
                        if (personlizationContent && resourceTag && resourceTag.id && personlizationContent[resourceTag.id]) {
                            if (personlizationContent[resourceTag.id]['resourceVisibleIndicator'] === false) {
                                if(attrs["class"] && attrs["class"].indexOf('personalize-visible-hidden')!==-1){
                                    elem.attr('style', 'visibility: hidden'); // to keep the space in DOM occupied
                                }else{
                                    elem.attr('style', 'display: none'); // Remove from DOM
                                }
                            } else if (personlizationContent[resourceTag.id]['contentText']) {
                                var contentText = personlizationContent[resourceTag.id]['contentText'];
                                if (contentText) {
                                    var dataReplace;
                                    if (contentText.__cdata) {
                                        scope.dataReplace = contentText.__cdata;
                                    } else if (contentText.indexOf('CDATA') !== -1) {
                                        contentText = serviceFactory.responseTransform('<contentText>' + contentText + '</contentText>');
                                        dataReplace = contentText.contentText.__cdata;
                                    }
                                    if (dataReplace && dataReplace !== resourceTag.resourceTagName) {
                                        setToDOM(elem,dataReplace);
                                    }
                                }
                            }
                            else{
                                setToDOM(elem);
                            }
                        }else{
                            setToDOM(elem);
                        }
                    },function(){
                        setToDOM(elem);
                    });
                }
            }
        };
    }])
    .directive('cmsSpot', function(portalJson, $compile) {
        return {
            restrict: 'A',
            scope: {
                "alternateContent": "&"
            },
            link: function (scope, elem, attrs) {
                if (!angular.isUndefined(attrs["cmsSpot"]) && portalJson && portalJson.APP_CMS_DATA && portalJson.APP_CMS_DATA[attrs["cmsSpot"]]) {
                    scope.expression = portalJson.APP_CMS_DATA[attrs["cmsSpot"]];
                    var cmsContent=$compile(scope.expression)(scope);
                    if(cmsContent[0] && (cmsContent[0].innerText || cmsContent[0].textContent)){
                        elem.replaceWith($compile('<span class="cms-spot" ng-bind-html="expression"></span>')(scope));
                    }
                }
            }
        };
    }).directive('positionModal', ['help', function (help) {
        return {
            restrict: 'A',
            link: function (scope, elm) {

                if (help.getIframeData() && $(window.parent.document).scrollTop() !== 0 &&
                    (!$(elm[0]).css("marginTop") || $(elm[0]).css("marginTop") == "auto")) {
                    if(help.IEVersion()== 11){
                        if($(window.parent.document).scrollTop()<=300){
                            $(elm[0]).css("margin-top", 0);
                        }

                        else {
                            $(elm[0]).css("margin-top", 100);
                        }
                    }
                    else{
                        if($(window.parent.document).scrollTop()<=200){
                            $(elm[0]).css("margin-top", 0);
                        }

                    else if($(window.parent.document).scrollTop()>200 ){
                        $(elm[0]).css("margin-top", Math.abs($(window.parent.document).scrollTop()-$("#cdc").offset().top)-210);
                    }
                    else{
                        $(elm[0]).css("margin-top", Math.abs($(window.parent.document).scrollTop()-$("#cdc").offset().top));
                    }
                }

                }

            }
        }
    }]).directive('positionSpinner', ['help', function (help) {
        return {
            restrict: 'A',
            link: function (scope, elm) {

                scope.$on('spinner',function (event, args) {

                    if(help.getIframeData() && $(window.parent.document).scrollTop() == 0){
                        $(elm[0]).css("margin-top", 260);
                    }
                    else if (help.getIframeData() && $(window.parent.document).scrollTop() > 0) {
                        if(help.IEVersion()== 11){
                            $(elm[0]).css("margin-top", Math.abs($(window.parent.document).scrollTop()+100));
                        }
                        else{
                            $(elm[0]).css("margin-top", Math.abs($(window.parent.document).scrollTop()-$("#cdc").offset().top));
                        }

                    }
                });




            }
        }
    }]).directive('elementFocus', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModelCtrl) {
                ngModelCtrl.$focused = false;
                element.bind('focus', function (evt) {
                    ngModelCtrl.$setViewValue(element[0].value);
                    ngModelCtrl.$render();
                })
            }
        }
    }).directive('typeaheadFocus', function () {
          return {
              require: 'ngModel',
              link: function (scope, element, attr, ngModel) {

                  //trigger the popup on 'click' because 'focus'
                  //is also triggered after the item selection
                  element.bind('click', function () {

                      var viewValue = ngModel.$viewValue;

                      //restore to null value so that the typeahead can detect a change
                      if (ngModel.$viewValue == ' ') {
                          ngModel.$setViewValue(null);
                      }

                      //force trigger the popup
                      ngModel.$setViewValue(' ');

                      //set the actual value in case there was already a value in the input
                      ngModel.$setViewValue(viewValue || ' ');
                  });

                  //compare function that treats the empty space as a match
                  scope.emptyOrMatch = function (actual, expected) {
                      if (expected == ' ') {
                          return true;
                      }
                      return actual.indexOf(expected) > -1;
                  };
              }
         };
      }).directive('fixedContinue',function($timeout,help){
           return {restrict:'A',
           link:function(scope,element,attrs){
              var timeout=(help.getUserAgent()).indexOf("AND")!=-1?1500:0;

              $timeout(function(){
                 var height=$(window).height();
                 $(element).height(height-224);
              },timeout)
              $(element).scroll(function(){
                 var totalHeight=$(element).scrollTop()+$(element).outerHeight();
                 var scrollHeight=$(element).prop('scrollHeight');
                 if(scrollHeight-totalHeight<100){
                    scope.$apply(attrs.fixedContinue)
                 }
              })
           }}
        });