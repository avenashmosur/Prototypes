'use strict';

/* Filters */

angular.module('checkDrugCost.filters', []).
    filter('interpolate', ['version', function (version) {
        return function (text) {
            return String(text).replace(/\%VERSION\%/mg, version);
        };
    }])
    .filter('cost', ['$filter', function ($filter) {
        return function (input) {
            var output = input;
            if (input) {
                input = input.toString();
                output = input.replace(/,/g, '');
            }

            if (output === '') {
                output = 'N/A';
            }
            var out = $filter('currency')(output);
            return out ? out : 'N/A';
        };
    }])
    .filter('pagination', function () //pharmacy list
    {
        return function (input, start) {
            var start = +start;
            return input.slice(start);
        }
    })

    .filter('dropDownFilter', function () {
        return function (drugSearchList, query) {
            if (drugSearchList.length > 0) {
                var newList = [];
                var len = query.length;
                angular.forEach(drugSearchList, function (value, key) {
                    newList.push(query + '-' + value.substring(len - 1, value.length));
                });
            }

            return newList;
            //drugSearchList.replace(RegExp('('+ query + ')', 'g'), '<span class="super-class">$1</span>');
        }
    })

    .filter('boldFilter', function () {
        return function (input, query) {
            var inptxt = input.drugName.__cdata + ' ' + input.drugStrength.__cdata + ' ' + input.drugForm.__cdata;
            return inptxt.replace(RegExp('(' + query + ')', 'i'), '<span class="super-class">$1</span>');
        }
    })
    .filter('camelCase', [function () {
        return function (input) {
            input = input || '';
            return input.replace(/\w\S*/g, function (txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            });
        };
    }])
    //basic phone number formatting as per the data from backend, can be improvised
    .filter('phoneNumber', [function () {
        return function (input) {
            if(input && input.length){
                var telePhoneNo=input.split('-');
                if(telePhoneNo[0]){
                    return '('+telePhoneNo[0]+') '+telePhoneNo[1]+'-'+telePhoneNo[2];
                }
            }
        };
    }]).filter('capitalizeText', ['$filter', function ($filter) {
        return function (input, pos) {
            if (input && input.length) {
                var displayText = $filter('camelCase')(input);
                if (pos) {
                    var textToCaplitalize = pos[0];
                    if (input.toLowerCase().indexOf(textToCaplitalize) === 0) {
                        input = $filter('camelCase')(input);
                        textToCaplitalize = $filter('camelCase')(textToCaplitalize);
                        displayText =input.replace(textToCaplitalize, textToCaplitalize.toUpperCase());

                    }
                }

                return displayText;
            }
        };
    }]).filter('lastWordBreak',function(){
        return function(input){

            if(angular.isDefined(input)){

                var text=input.split(' ').pop();
               return input.replace(text,"<span class='nobr'>"+text+'</span>');

                
            }
        }

    });

