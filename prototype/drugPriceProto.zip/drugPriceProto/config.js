var config =
{
    "webAnalyticsFlag": true,
    //"webAnalyticsFlag":false, //for MOBILE APPS
    "tealiumUrl": {
        "demo": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/dev2/utag.js"
        },
        "dev": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/dev1/utag.js"
        },
        "dev1": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/dev1/utag.js"
        },
        "dev2": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/dev2/utag.js"
        },
        "dev3": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/dev3/utag.js"
        },
        "sit": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/sit1/utag.js"
        },
        "sit1": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/sit1/utag.js"
        },
        "sit2": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/sit2/utag.js"
        },
        "sit3": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/sit3/utag.js"
        },
        "stp": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/stp/utag.js"
        },
        "cte": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/cte/utag.js"
        },
        "prod": {
            "url": "//tags.tiqcdn.com/utag/cvs/fast/prod/utag.js"
        }
    },

    "resourceTag": [
        {"resourceTag": "40000025"},
        {"resourceTag": "40000033"},
        {"resourceTag": "6131"},
        {"resourceTag": "6132"},
        {"resourceTag": "6133"},
        {"resourceTag": "6134"},
        {"resourceTag": "615"},
        {"resourceTag": "616"},
        {"resourceTag": "617"},
        {"resourceTag": "618"},
        {"resourceTag": "1001"}
    ],

    "apiParams": {
        "apiKey": "1008347202313004A50F01F33D27EAB1",
        "apiSecret": "E228F4CF4BE33EA5A20FE5FF9D5573F8",
        "appName": "CMK_WEB",
        "channelName": "WEB",
        "deviceID": "device12345",
        "deviceToken": "device12345",
        "deviceType": "DESKTOP",
        "faststyle": "alcoa",
        "lineOfBusiness": "PBM",
        "serviceCORS": "TRUE",
        "tokenId": "A532C1670E823002A287654744DB2E11",
        "version": "1.0",
        "memberID":"264462689"
    },
    "sit1": {
        "baseUrl": "https://sit1services.caremark.com:444/"
    },
    "sit2": {
        "baseUrl": "https://sit2services.caremark.com:444/"
    },
    "sit3": {
        "baseUrl": "https://sit3services.caremark.com:444/"
    },
    "dev2": {
        "baseUrl": "https://devservices.caremark.com:11440/"
    },
    "demo": {
        "baseUrl": "data/xml/",
        "createTrustedMemberToken": "createTrustedMemberTokenResponse.xml",
        "getMemberInfoByToken": "getMemberInfoByToken.xml",
        "partnerLogin": "partnerLogin-family.xml",
        "drugSearch": "drugSearch.xml",
        "drugDetails": "drugDetails_Lip_latest.xml",
        "pharmacyLocator": "pharmacyLocator-mock.xml",
        "drugPrice": "drugPrice.xml",
        "drugProperties":"drugDetailsProperties.xml",
        "TAD": "tad-HealthInformation.xml",
        "getDrugAlternatives": "tadDrugInformation.xml",
        "GSMAlchemy": "gsmAlchemy.xml",
        "ClaimDetails": "getClaimDetails.xml",
        "getDrugIndicationsByNDCId": "getDrugIndicationsByNDCId.xml",
        "personalization": "pzn.xml",
        "tadDrugPrice":"tadPrice.xml"
    },
    "serviceEndPoints": {
        "createTrustedMemberToken": "createTrustedMemberToken",
        "getMemberInfoByToken": "refill/getMemberInfoByToken",
        "drugDetails": "drug/drugDetails",
        "drugPrice": "drug/drugPrice",
        "drugProperties": "drug/drugDetails",
        "getDrugAlternatives": "drug/getDrugAlternatives",
        "TAD": "TAD/TAD",
        "processDispositionRequest": "processDispositionRequest",
        "getSTCOBCostBreakdown": "getSTCOBCostBreakdown",
        "pharmacyLocator": "pharmacy/pharmacyLocator",
        "ClaimDetails": "claims/ClaimDetails",
        "GSMAlchemy": "GSM/GSMAlchemy",
        "personalization": "PZN/getPZNByIDandResourcetag",
        "tadDrugPrice":"drug/drugPrice"
    },
    "serviceNames": {
        "createTrustedMemberToken": "createTrustedMemberToken",
        "getMemberInfoByToken": "getMemberInfoByToken",
        "drugDetails": "drugDetails",
        "drugPrice": "drugPrice",
        "drugProperties": "drugProperties",
        "getDrugAlternatives": "TAD", //TODO getDrugAlternatives
        "getDrugIndicationsByNDCId": "TAD",
        "processDispositionRequest": "processDispositionRequest",
        "getSTCOBCostBreakdown": "getSTCOBCostBreakdown",
        "pharmacyLocator": "pharmacyLocator",
        "getTADHealthInformation": "getTADHealthInformation",
        "getTADDrugInformation": "getTADDrugInformation",
        "GSMAlchemy": "GSMAlchemy",
        "getClaimDetails": "ClaimDetails",
        "personalization": "personalization",
        "tadDrugPrice":"tadDrugPrice"
    },
    "operationName": {
        "drugPrice": "getDrugPrice"
    },
    "portalJSONVarName": "FAST_INPUT_DATA",
    "currentENV": "demo" // please do not commit with demo

};