'use strict'
clickAppController.controller('getReviewOrderController', ['$scope','activeModel','$location', '$filter', '$rootScope', function ($scope, activeModel,$location,$filter, $rootScope) {

	$scope.reviewAddressList= activeModel.shippingList;


	$scope.radioSelect = activeModel.shippingList[0].ADDRESS_BOOK_ID;
	$scope.addressSelect = activeModel.addressList[0];

	console.log("currentShipAddress" , activeModel.currentShipAddress);
	console.log($scope.reviewAddressList);
	 $scope.go = function (path) {
			console.log("scope go");
			$location.path(path);
	};

	if(activeModel.editAddressFlag)
	{
		for(var i = 0; i< $scope.reviewAddressList.length; i++)
		{
			if($scope.reviewAddressList[i].ADDRESS_BOOK_ID == activeModel.currentShipAddress.ADDRESS_BOOK_ID)
			{
				$scope.reviewAddressList[i] = activeModel.currentShipAddress;
				activeModel.addressSelect = $scope.reviewAddressList[i];
				$scope.radioSelect = $scope.reviewAddressList[i].ADDRESS_BOOK_ID;
				console.log('$scope.radioSelect' , $scope.radioSelect);
				console.log('$scope.reviewAddressList[i]', $scope.reviewAddressList[i]);
			}
		}
	}


	$scope.setAddressSelectVal = function(address)
	{

		console.log("Entering into setAddressSelectValue" + address);
		activeModel.selectedADDRESS_BOOK_ID = address.ADDRESS_BOOK_ID;
		activeModel.addressSelect = (address.ADDRESS1);
		$scope.addressSelect = activeModel.addressSelect;
		console.log('activeModel.addressSelect' , activeModel.addressSelect);
		activeModel.currentShipAddress = address;
		console.log('activeModel.currentShipAddress', activeModel.currentShipAddress);
		console.log('$scope.addressSelect' , $scope.addressSelect);
	}
	
	

}]);
