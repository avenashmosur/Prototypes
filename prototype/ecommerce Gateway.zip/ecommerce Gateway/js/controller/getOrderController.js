'use strict'
clickAppController.controller('getOrderController', ['$scope','orderModel','activeModel','help', '$filter', '$rootScope','getOrderService' , '$location', function ($scope, orderModel,activeModel,help,$filter, $rootScope,getOrderService,$location) {
	$scope.$on('$viewContentLoaded', function () {
		getOrderService.retrieveCheckOutDetails({
			
	}, '', successRetrieveCheckOutDetails, errorRetrieveCheckOutDetails )
	})
   
	$scope.getTotalCostDetails = {};
	$scope.selectedShipping = "500";
	$scope.addresValue = {};

	$scope.go = function (path) {
		console.log('$location' , $location)
		$location.path(path);
	};
    	 
    	 function successRetrieveCheckOutDetails(data, headers){
    		 activeModel.shippingList=data.PROFILE.SHIPPING_ADDRESSES;
			 console.log('activeModel.shippingList',activeModel.shippingList);
    		 activeModel.billingAddressList=data.PROFILE.BILLING_ADDRESSES;
    		 console.log('activeModel.billingaddress',activeModel.billingAddressList);
    		 activeModel.paymentInfoList=data.PROFILE.PAYMENTS;
    		 console.log('activeModel-paymentInfoList',activeModel.paymentInfoList);


    		 $scope.defaultLabelID=activeModel.shippingList[0].ADDRESS_BOOK_ID;

    	     angular.forEach(activeModel.shippingList, function (address, index) {
    	    	 activeModel.editAddressList.push(address);
				 activeModel.addressList.push(address.ADDRESS1);
               });
    	     $scope.tempAddressList=  activeModel.addressList;
			
    	     if(!activeModel.addressSelect) {
				 $scope.addressSelect = activeModel.addressList[0];
				 activeModel.currentShipAddress = activeModel.editAddressList[0];
				 console.log('activeModel.currentShipAddress' , activeModel.currentShipAddress);

			 }
			 else{
				 $scope.addressSelect = activeModel.addressSelect.FIRST_NAME +" " +activeModel.addressSelect.LAST_NAME +" "+
					 activeModel.addressSelect.ADDRESS1;
				 console.log('$scope.addressSelect ' , $scope.addressSelect );
			 }


    	     $scope.shippingList =  activeModel.shippingList;	      
    	    
    	     angular.forEach(activeModel.paymentInfoList, function (cardDetail, index) {
    	    	 var temp =cardDetail.CARD_TYPE+" ending in "+cardDetail.CC_LAST_4_DIGITS;
	    	     activeModel.cardDetailsList.push(temp);
    	     });
    	     $scope.tempPaymentList= activeModel.cardDetailsList;
    	     $scope.paymentSelect = activeModel.cardDetailsList[0];

			 orderModel.appliedPromotions = data.ORDER.APPLIED_PROMOTIONS;
			 orderModel.commerceItems = data.ORDER.COMMERCE_ITEMS;
			 orderModel.ecInfo=data.ORDER.EC_INFO;
			 orderModel.orderID = data.ORDER.ORDER_ID;
			 orderModel.orderBillingInfo=data.ORDER.ORDER_BILLING_INFO;
			 orderModel.orderShippingInfo=data.ORDER.ORDER_SHIPPING_INFO;
			 orderModel.orderState = data.ORDER_ORDER_STATE;
			 orderModel.orderSummary = data.ORDER.ORDER_SUMMARY;

			 $scope.appliedPromotions = orderModel.appliedPromotions;
			 $scope.commerceItems=orderModel.commerceItems ;
			 $scope.ecInfo= orderModel.ecInfo;
			 $scope.orderID=orderModel.orderID ;
			 $scope.orderBillingInfo= orderModel.orderBillingInfo;
			 $scope.orderShippingInfo=orderModel.orderShippingInfo;
			 $scope.orderState= orderModel.orderState;

			 
			 $scope.emailID = orderModel.orderShippingInfo.SHIPPING_ADDRESS.EMAIL_ADDRESS;
			 
			 /* Calculate Order Summary for default address */
			 var tempDefaultAddressSummAndTotalParams = {};
			 angular.forEach(activeModel.shippingList, function (shipAddress, index) {
    	    	 if(shipAddress.DEFAULT_FLAG === 'Y'){
    	    		 console.log(shipAddress);
    	    		 console.log($scope.selectedShipping);
    	    		 sendGetOrderService(shipAddress,$scope.selectedShipping);
       	    	 }
	         });
    	 }
    	  $scope.selectAddress = function (selectedAddress) {
    		  console.log("selectAddress");
			  var addressParam= {};
    		    $scope.addressSelect = selectedAddress;
			  console.log('$scope.addressSelect' , $scope.addressSelect);
			  for( var i = 0 ; i<activeModel.shippingList.length; i++)
			  {
				  if(activeModel.shippingList[i].ADDRESS1 == $scope.addressSelect)
				  {
					  addressParam = activeModel.shippingList[i];
				  }
			  }
			  var calcOrderShippingSummaryAndTotalParams = {};

			  calcOrderShippingSummaryAndTotalParams.SELECTED_SHIPPING_METHOD =  $scope.selectedShipping;
			  calcOrderShippingSummaryAndTotalParams.ADDRESS1 = addressParam.ADDRESS1;
			  calcOrderShippingSummaryAndTotalParams.ADDRESS2 = addressParam.ADDRESS2;
			  calcOrderShippingSummaryAndTotalParams.CITY = addressParam.CITY;
			  calcOrderShippingSummaryAndTotalParams.STATE = addressParam.STATE;
			  calcOrderShippingSummaryAndTotalParams.ZIP = addressParam.ZIP;
           	  getOrderService.calcOrderShippingSummaryAndTotal(calcOrderShippingSummaryAndTotalParams, '', successCalcOrderShippingSummaryAndTotalDetails, errorCalcOrderShippingSummaryAndTotaltDetails )
            };

	function successCalcOrderShippingSummaryAndTotalDetails(data, headers){
        console.log("successCalc");
		$scope.getTotalCostDetails = data.details;
		console.log('$scope.getTotalCostDetails',$scope.getTotalCostDetails);
		$scope.subTotal = $scope.getTotalCostDetails.ORDER_SUMMARY[0].SUBTOTAL;
		$scope.extraCare=$scope.getTotalCostDetails.ORDER_SUMMARY[0].EXTRA_CARE_REWARDS;
		$scope.shipping=$scope.getTotalCostDetails.ORDER_SUMMARY[0].SHIPPING_CHARGES;
		$scope.tax=$scope.getTotalCostDetails.ORDER_SUMMARY[0].TAX;
		$scope.totalcost = $scope.getTotalCostDetails.ORDER_SUMMARY[0].TOTAL;

	}

	function errorCalcOrderShippingSummaryAndTotaltDetails(data, headers){

	}
    	  
    	  $scope.selectPayment = function (selectedPayment) {
    		   $scope.paymentSelect = selectedPayment;
    	  };
    	 function errorRetrieveCheckOutDetails(data, headers){
    		 console.log(data);
    	 }
    	 $scope.prevent =function(){
    		 return false;
    	 }
    	 
    	 
    	/* Function to send Get Order Service */ 
    	function sendGetOrderService (shipAddress,shipValue){
    		console.log("sendGetOrderService");
    		var tempDefaultAddressSummAndTotalParams={};
    		 tempDefaultAddressSummAndTotalParams.SELECTED_SHIPPING_METHOD = shipValue;
    		 tempDefaultAddressSummAndTotalParams.ADDRESS1 = shipAddress.ADDRESS1;
			 tempDefaultAddressSummAndTotalParams.ADDRESS2 = shipAddress.ADDRESS2;
			 tempDefaultAddressSummAndTotalParams.CITY = shipAddress.CITY;
			 tempDefaultAddressSummAndTotalParams.STATE = shipAddress.STATE;
			 tempDefaultAddressSummAndTotalParams.ZIP = shipAddress.ZIP;
			 getOrderService.calcOrderShippingSummaryAndTotal(tempDefaultAddressSummAndTotalParams, '', successCalcOrderShippingSummaryAndTotalDetails, errorCalcOrderShippingSummaryAndTotaltDetails )
    	} 
    	 
    	/* Call GetOrder Service to calculate the Order Summary when shipping method gets changed */
    	$scope.selectShippingMethod = function(value) {
    	     var currentAddress = $scope.addressSelect;
    	     var shipMethodValue = value;
   	        
    	     angular.forEach(activeModel.shippingList, function (shipAddress, index) {
    	    	 if(shipAddress.ADDRESS1 === currentAddress){
    	    		 console.log(shipAddress);
    	    		 sendGetOrderService(shipAddress,shipMethodValue);
       	    	 }
	         });
    	     
    	};
    	


}]);
