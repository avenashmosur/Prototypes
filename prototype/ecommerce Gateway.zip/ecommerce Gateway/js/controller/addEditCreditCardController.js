'use strict'
clickAppController.controller('addEditCreditCardController', ['$scope','activeModel','$rootScope', function ($scope, activeModel,$rootScope) {
	
	$scope.selectedCard=activeModel.cardSelect+" ending in "+activeModel.selectedCC_LAST_4_DIGITS;
}]);
