'use strict'
clickAppController.controller('editShippingDetailsController', ['$scope','orderModel','activeModel','help', '$filter', '$rootScope','getOrderService' ,'$location', function ($scope, orderModel,activeModel,help,$filter, $rootScope,getOrderService,$location) {

    $scope.input = {};
    activeModel.editAddressFlag = true;
    console.log('currentShipAddress' , activeModel.currentShipAddress);
    $scope.input.FirstName = activeModel.currentShipAddress.FIRST_NAME;
    $scope.input.LastName = activeModel.currentShipAddress.LAST_NAME;
    $scope.input.StreetAddress = activeModel.currentShipAddress.ADDRESS1;
   var str = activeModel.currentShipAddress.ADDRESS2;
    if(str) {
        $scope.input.APTBldg = str.slice(4);
    }
    $scope.input.City = activeModel.currentShipAddress.CITY;
    $scope.input.State = activeModel.currentShipAddress.STATE;
    $scope.input.Zip = activeModel.currentShipAddress.ZIP;
    $scope.input.Phone = activeModel.currentShipAddress.PHONE_NUMBER;
    $scope.input.ADDRESS_BOOK_ID = activeModel.currentShipAddress.ADDRESS_BOOK_ID;


    $scope.setAddressList = function()
    {

        activeModel.currentShipAddress.LAST_NAME = $scope.input.LastName;
        activeModel.currentShipAddress.ADDRESS1 = $scope.input.StreetAddress ;
        activeModel.currentShipAddress.ADDRESS2 = $scope.input.APTBldg;
        console.log('activeModel.currentShipAddress.ADDRESS2' , activeModel.currentShipAddress.ADDRESS2);
        activeModel.currentShipAddress.CITY = $scope.input.City ;
        activeModel.currentShipAddress.STATE =  $scope.input.State ;
        activeModel.currentShipAddress.ZIP = $scope.input.Zip;
        activeModel.currentShipAddress.PHONE_NUMBER = $scope.input.Phone;
        activeModel.currentShipAddress.ADDRESS_BOOK_ID = $scope.input.ADDRESS_BOOK_ID

    }


    $scope.go = function (path) {
        console.log('$location' , $location);
        $location.path(path);
    };



}]);
