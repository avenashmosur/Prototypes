clickAppController.controller('addNewShippingDetailsController', ['$scope','orderModel','activeModel','help', '$filter', '$rootScope','getOrderService' ,'$location', function ($scope, orderModel,activeModel,help,$filter, $rootScope,getOrderService,$location) {
/*Add New Shipping Details*/

    $scope.go = function (path) {
        console.log('$location' , $location);
        $location.path(path);
    };





}]);