'use strict'
/*clickAppController.controller('creditCardSelectionController', ['$scope','activeModel','$rootScope', function ($scope, activeModel,$rootScope) {
	
	$scope.getTotalCostDetails = {};
	$scope.creditCardList = activeModel.paymentInfoList;
	
	
	angular.forEach(activeModel.paymentInfoList, function (cardDetail, index) {
   	 var temp =cardDetail.CARD_TYPE+" ending in "+cardDetail.CC_LAST_4_DIGITS;
	     activeModel.cardDetailsList.push(temp);
    });
   // $scope.tempPaymentList= activeModel.cardDetailsList;
    $scope.paymentSelect = activeModel.cardDetailsList[0];
    activeModel.selectedCC_LAST_4_DIGITS=activeModel.cardDetailsList[0].CC_LAST_4_DIGITS;
	activeModel.cardSelect=activeModel.cardDetailsList[0].CARD_TYPE;
	$scope.defaultRadioSelect=activeModel.cardDetailsList[0].PAYMENT_ID;
	$scope.defaultCardID=activeModel.cardDetailsList[0].CARD_TYPE;


	
	$scope.setCreditCardSelectVal = function(cc)
	{
		activeModel.selectedCC_LAST_4_DIGITS = cc.CC_LAST_4_DIGITS;
		activeModel.cardSelect = cc.CARD_TYPE;
		console.log('$scope.cardSelect' , $scope.cardSelect);
	}
    	      
  	$scope.go = function (path) {
		$location.path(path);
	};
	   

}]);*/



clickAppController.controller('creditCardSelectionController', ['$scope','orderModel','activeModel','help', '$filter', '$rootScope','getOrderService' , '$location', function ($scope, orderModel,activeModel,help,$filter, $rootScope,getOrderService,$location) {
	$scope.getTotalCostDetails = {};
	$scope.setCreditCardSelectVal = function(cc)
	{
		console.log(cc);
		activeModel.selectedCC_LAST_4_DIGITS = cc.CC_LAST_4_DIGITS;
		activeModel.cardSelect = cc.CARD_TYPE;
		console.log('activeModel.cardSelect' , activeModel.cardSelect);
	}
    	      
    	 
    	
    		// activeModel.paymentInfoList=data.PROFILE.PAYMENTS;
    		 $scope.creditCardList=activeModel.paymentInfoList;
    		 activeModel.selectedCC_LAST_4_DIGITS=$scope.creditCardList[0].CC_LAST_4_DIGITS;
    		 activeModel.cardSelect=activeModel.paymentInfoList[0].CARD_TYPE;
    		 $scope.defaultRadioSelect=activeModel.paymentInfoList[0].PAYMENT_ID;
    		 $scope.defaultCardID=activeModel.paymentInfoList.CARD_TYPE;
    		 
    	      	   
    	    angular.forEach(activeModel.paymentInfoList, function (cardDetail, index) {
    	    	 var temp =cardDetail.CARD_TYPE+" ending in "+cardDetail.CC_LAST_4_DIGITS;
	    	     activeModel.cardDetailsList.push(temp);
    	     });
    	    // $scope.tempPaymentList= activeModel.cardDetailsList;
    	     //$scope.paymentSelect = activeModel.cardDetailsList[0];

			    
    
	$scope.go = function (path) {
		$location.path(path);
	};
	   

}]);

