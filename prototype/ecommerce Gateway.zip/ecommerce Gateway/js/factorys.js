'use strict';

var clickAppFactory = angular.module('clickApp.factorys', []);