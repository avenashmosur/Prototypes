'use strict';
angular.module('clickApp', [
    'ngRoute',
    'ngResource',
    'clickApp.factorys',
    'clickApp.controllers',
    'ui.bootstrap',
    'ng.httpLoader'
]).config(['$routeProvider', function($routeProvider){
	$routeProvider.when('/', {
		controller: 'getOrderController',
		templateUrl: 'partials/orderMobileReview.html'
	}).when('/reviewOrder',{
		controller: 'getReviewOrderController',
		templateUrl: 'partials/reviewOrderPage.html'
	}).when('/editShippingDetails',{
			controller: 'editShippingDetailsController',
			templateUrl: 'partials/editShippingDetails.html'

	}).when('/addNewShippingAddress',{
		controller: 'addNewShippingDetailsController',
		templateUrl: 'partials/addNewShippingAddress.html'

	}).when('/creditCardSelection', {
		controller: 'creditCardSelectionController',
		templateUrl: 'partials/creditCardSelection.html'
	}).when('/addEditCreditCard', {
		controller: 'addEditCreditCardController',
		templateUrl: 'partials/addEditCreditCard.html'
	})

	.otherwise({redirectTo:'/'});
	
}]).run(['$rootScope', 'FAST_CONTENT',function($rootScope, FAST_CONTENT){
	$rootScope.FAST_CONTENT = FAST_CONTENT;
}
]);