'use strict';

/* Controllers */

var clickAppController = angular.module('clickApp.controllers', []);