'use strict'

clickAppFactory.factory('FAST_CONTENT', [function () {
    var FAST_CONTENT = {
        "GuestRefillAlert": {
            "header": "How Easy Refill Works",
            "body1Strt": "You can refill prescriptions ",
            "body1bold": "(mail service only)",
            "body1End": " without creating an account",
            "body2": "Orders can only be placed for one person at a time."
        },
        "PanelHeader1": "More Prescriptions due for refill",
        "PanelHeader1NotifTxt": "<span>These prescriptions can be refilled now.</span>  <a href='' ng-click='signIn()'>Sign in</a> <span>to see all your medications</span>",
        "PanelHeader2": "More expired or zero-refill prescriptions for renewal",
        "PanelHeader2NotifTxt": "We'll need to contact your doctor for permission, so these may take longer to process than refills do.",
        "RequiredText": "Renew your expired or zero-refill prescriptions",
        "RequiredTextNotifTxt": "We'll need to contact your doctor for permission, so these may take longer to process than refills do.",
        "TableHeadingTxt": {
            "Rx": "Rx#",
            "Prescptn": "Prescription",
            "Qty": "Qty/supply",
            "EstCost": "Estimated Cost",
            "EstTotalDrgCost": "Estimated Total Drug Cost"
        },
        "StatusTxt": {
            "1": "Enter",
            "2": "Review",
            "3": "Submit"
        },
        "costSummaryHdr": {
            "EstDrugCost": "Estimated Drug Cost",
            "EstShpCost": "Estimated Shipping Cost",
            "OutstndServBalnc": "Outstanding Mail Service Balance",
            "EstOrdrTotl": "Estimated Order Total",
            "notifyTxt": "Any money owed from prior orders is included in the total cost."
        },
        "shpTotxt": "Ship to",
        "MshpTotxt": "Shipping Address",
        "shpMthdtxt": "Shipping Method",
        "paymnMthdtxt": "Payment method",
        "paymnOptntxt": "Payment Options",
        "paymnNotiftxt": "This payment method will be saved to your account",
        "SelctAllTxt": "Select all",
        "PrscptnSelectTxt": "prescriptions selected",
        "SinglePrscptnSelectTxt": "prescription selected",
        "singlePrscptnLeft": "No other prescriptions are due now.",
        "singleExpiredPrscptnLeft":"No additional prescriptions are due at this time.",
        "cancelOrderModal": {
            "SureModalHrd": "Are you sure?",
            "SureModalBody": "If you leave now your order will not be saved, and these prescriptions will not be refilled.",
            "continueBtn": "Continue with order",
            "cancelOrder": "Cancel this order"
        },
        "footrLoginTxt1": "Can't find your mail service Rx number?",
        "footrLoginTxt2": "You can still order online. Just",
        "signIn": "sign in",
        "or": "or",
        "creatAcct": "create an account.",
        "closeTxt": "Close",
        "ModalBodyTxt1": "The 9-digit number must be from a prescription filled by CVS/Caremark.",
        "ModalBodyTxt2": "You can find it on the medicine bottle, tube, jar, other packaging, or invoice. Enter only the letters and numbers into the Rx # field.",
        "ModalHdrTxt": "Rx# Information",
        "NeedTxt": "Need Help?",
        "M_NeedTxt": "Help?",
        "reqrdTxt": "*All fields are required",
        "ButtnTxt": {
            "ContnOrdr": "Continue with order",
            "CanclOrde": "Cancel This order",
            "AddRxBtn": "Add Rx",
            "ContBtn": "Continue",
            "CanclBtn": "Cancel Order",
            "CancelBtn": "Cancel",
            "SubmtBtn": "Submit Order",
            "PlaceBtn":"Place Order",
            "ChngBtn": "Edit Order",
            // "RegistrBtn": "Register Now",
            "RegistrBtn": "Create an Account",
            "SignInBtn": "Sign In",
            "StrtOvrBtn": "Start Over",
            "ContnBtn": "Continue",
            "ContToChkOutBtn": "Go to Checkout",
            "ReturnToOrder":"Return to Order"
        },
        "PanelHrd": {
            "RxHdr": "Mail Service Rx#",
            "dobHdr": "Member's Date of Birth",
            "MHomePanelHrd": "Easy Refill",
            "HomePanelHrd": "Enter the member's date of birth and mail service Rx# to continue.",
            "orderReviewHdr": "Review Your Order",
            "ChkOutHdr": "Add more prescriptions or check out:",
            "CnfrmHdr": "Order Details for Member:",
             "checkTo":"Checkout"
        },
        "ChkOutdata": [{
            "visible": "true",
            "headingTxt": "Additional prescriptions due for refill:",
            "notifTxt": "We'll need to contact your doctor for permission, so these may take longer to process than refills do."
        }, {
            "visible": "true",
            "headingTxt": "Renew your expired/zero-refill prescriptions:",
            "notifTxt": "We'll need to contact your doctor for permission, so these may take longer to process than refills do."
        }, {
            "visible": "true",
            "headingTxt": "More expired/zero-refill prescriptions for renewal",
            "notifTxt": "We'll need to contact your doctor for permission, so these may take longer to process than refills do."
        },],
        "Cnfrmdata": {
            "ThnkUHeadr": "Thank you for your payment and order!",
            //"ThnkUBody": "The confirmation is sent to the email address provided below. Your order will ship in 1-2 days after processing begins. You can sign in to check your order status in a few hours.",
            "ThnkUBody": "Confirmation of your order will be sent to the email address below. Your order will ship 1-5 days after processing begins. You can ",
            "ThnkUBodyContd":"to check your order status in a few hours.",
            "ReglistItem": [{
                "itemTxt": "Track your order status"
            }, {
                "itemTxt": "Learn about your prescription benefit plan"
            }, {
                "itemTxt": "View your prescription history"
            }, {
                "itemTxt": "Request a new prescription"
            }, {
                "itemTxt": "Check drug costs and coverage"
            }, {
                "itemTxt": "Manage family members' prescriptions"
            }, {
                "itemTxt": "Manage prescription alerts"
            }],
            "RegLoginHdr": {
                "RegTxt": "Register now for full access. You're just one step away!",
                //"SignInTxt": "Sign In now to get full access.",
                "SignInTxt": "Sign in now for full access to Caremark.com",
                "RegTxtVisble": "false",
                "SignInTxtVisble": "true"
            }
        },
        "Orderdata": {
            "placeHolder":{
                "streetAddress":"Street Address",
                "city":"City",
                "zipCode":"Zip Code",
                "emailId":"Email Address",
                "creditCardNumber": "Credit Card Number."
            },
            "BalncTooltiptxt": "If you owe money from prior order. It is included in the total cost.",
            "subPanelHdr": {
                "ship": "Shipping Options",
                "shipAddr": "Ship to",
                "shipMethod": "Shipping method",
                "paymnt": "Payment Options",
                "shippayment":"Shipping & Payment",
                "orderSummary":"Order Summary",
                "email": {
                    "hdrtxt": "Receive an Order Confirmation",
                    "detailtxt": "Enter or edit your email address so that we can send you confirmation of your prescription order.",
                    "notifyTxt": "Your email address will only be used to send an order confirmation. It will not be sold or shared with third parties."
                },
                "ordrDetail": "Order Details for Member",
                "emailorderInfo":"Send order information to",
                "creditcardinfo":"Credit Card",
                "cvvinfo":"Please enter the 3-digit security code found on the back of your card",	
                "shippingSpeed":"Shipping Speed"	 
            },
            "ShiptoOptn": {
                "Opt1": {
                    "txt": "Use an existing address",
                    "checked": "true"
                },
                "Opt2": {
                    "txt": "Use a one-time shipping address",
                    "checked": "false"
                }
            },
            "ShipMthdOptn": {
                "Opt1": {
                    "txt": "5-7 business days for FREE",
                    "checked": "true"
                },
                "Opt2": {
                    "txt": "2-3 business days for $9.49",
                    "checked": "false"
                }
            },
            "payMthdOptn": {
                "Opt1": {
                    "txt": "Use an existing payment method",
                    "checked": "true"
                },
                "Opt2": {
                    "txt": "Use an alternate payment method",
                    "checked": "false"
                }
            },
            "panelHeader": {
                "prescripRenew": "Prescription Renewal",
                "addRefill": "Additional Refills",
                "addRenewal": "Additional Renewals"
            },
            "errorText": {
                "invalidAddress": {
                    "address1": "Enter Street Address.",
                    "city": "Enter City.",
                    "state": "Select State",
                    "zipCode": "Enter Zip Code.",
                    "zipCodeLength": "Please enter a valid Zip Code(5 digits)."
                },
                "invalidCredit": {
                    "creditCardNumber": "Enter Credit Card Number.",
                    "month": "Select Month",
                    "year": "Select Year"
                },
                "invalidEmail": {
                    "emailId": "Please enter a valid email address.",
                    "enterEmail": "Enter Email Address."
                }
            },
            "rxHeader": {
                "prescription": "Prescription",
                "rx": "Rx#",
                "quantity": "Qty/supply",
                "estCost": "Estimated Cost"
            },
            "totalSummary": {
                "estDrugCost": "Estimated Drug Cost",
                "estShipCost": "Estimated Shipping Cost",
                "outBalance": "Outstanding Mail Service Balance",
                "outBalanceMobile": "Outstanding Mail Service Account Balance",
                "estOrderTotalMobile": "Estimated Total Drug Cost",
                "estOrderTotal": "Estimated Order Total",
                "subTotal":"Subtotal including coupons",	
                "extraCare":"ExtraCare Rewards",
                "shipping":"Shipping",
                "estimatedtax":"Estimated Tax"
            },
            "shipMethodNote": "Please note:"
        },
        "Months": [{
            "value": '01',
            "text": "January"
        }, {
            "value": '02',
            "text": "February"
        }, {
            "value": '03',
            "text": "March"
        }, {
            "value": '04',
            "text": "April"
        }, {
            "value": '05',
            "text": "May"
        }, {
            "value": '06',
            "text": "June"
        }, {
            "value": '07',
            "text": "July"
        }, {
            "value": '08',
            "text": "August"
        }, {
            "value": '09',
            "text": "September"
        }, {
            "value": '10',
            "text": "October"
        }, {
            "value": '11',
            "text": "November"
        }, {
            "value": '12',
            "text": "December"
        }],
        "BlockedContent": {
            "BlockedBody1": "You've tried to enter Rx details too many times.",
            "BlockedBody2": "For security purpose, you have been blocked from Easy Refill. Please wait 30 minutes to try again. Or you can place your order now by signing in or creating an account.",
            "BlockedFootr1": "If you have questions, you can call the toll-free Customer Care number on your prescription benefit ID card.",
            "BlockedFootr2Strt": "You may also",
            "BlockedFootr2Mid": "contact Customer Care online",
            "BlockedFootr2End": "or call toll-free at",
            "BlockedPhnNo": "1-800-552-8159",
            "BlockPanelHdr": "You are temporarily blocked from Easy Refill.",
            "CreatAcct": "Create an Account",
            "SignIn": "Sign In"
        },
        "Notetxt": "Faster methods only speed up shipping time, not the time it takes to process a prescription.",
        "UnCheckAllPrescriptions": "<b>Did you mean to uncheck all prescriptions?</b>",
        "UnCheckAllPrescriptionsBody": "You need to select at least one prescription to place an order. To order prescriptions for someone else, you must start  the process over.",
        "CheckOutPrescriptionsHdr": "Checkout Error",
        "CheckOutPrescriptionsBody1": "Please note that you cannot check out with no prescription selected.",
        "CheckOutPrescriptionsBody2": "To continue with current Prescription, click 'Continue'. To start over with a different member's Rx,click on 'Start Over'.",
        "SignInText": "If the doctor listed here is no longer accurate, please",
        "SignInText2": "to add your new doctor.",
        "ViewAllRx": "View All prescriptions",
        "DisclaimerText": "Estimated usage, costs and savings are calculated through current plan year or end of current calendar year. Actual savings may vary depending on plan structure, deductibles, previous payments, future claims and prior authorizations.",

        "AlrdyLink": "Already have an account?",
        "RetrnHome": "Return home",
        "footerTxt": "Estimated usage, costs and savings are calculated through current plan year or the end of current calendar year. Actual savings may vary depending on plan structure, deductibles, previous payments, future claims and prior authorizations.",
        "errorHeader": "We're Sorry",
        "footerNote": {
            "contactUs": "Contact Us",
            "home": "Home",
            "desktopSite": "Desktop Site",
            "privacy": "Privacy Policy",
            "rights": "@ CVS/caremark. All rights reserved"
        },
        "devcaremark": "http://dev1www61maint.caremark.com/",
        "regAdv":"Here's what you can do on Caremark.com:",
        "signInAdv":"Here's what else you can do:",
        "rxDataContent":{
            "invalidLength":"Our Rx#s have 9 digits. Please enter all 9.",
            "invalidChar":"Use numbers only. Our Rx#s have no letters."
        },
        "home": {
            "errorMsg": {
                "missingRx": "Enter the Rx#.",
                "missingDOB": "Enter date of birth.",
                "invalidDob":"Invalid Date (Correct Date Format mm/dd/yyyy)."
            },
            "placeHolder": {
                "dob": "mm / dd / yyyy",
                "rx": "Rx# (Must be 9 digits)"
            }
        }
        
        /* "footertxt":"What if I don't have Mail Order Rx Number handy?<br/>You could <a href="#">Sign in</a> or <a href="#">Create an Account</a> now."*/
    };
    return FAST_CONTENT;
}]);