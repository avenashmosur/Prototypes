'use strict';

clickAppFactory.factory('help', ['activeModel', '$modal', '$rootScope', function (activeModel, $modal, $rootScope) {
    var help = {} ;
    // convert an obj to array
    help.convertToArray = function (obj) {
        var arr;
        if (Object.prototype.toString.call(obj) === '[object Object]') {
            arr = [obj];
        } else if (Object.prototype.toString.call(obj) === '[object Array]') {
            arr = obj;
        }
        return arr;
    };

    help.getValidAddress = function (addressListArray) {

        return addressListArray.filter(function (element) {

            if (
                (typeof element.Line1.__cdata !== 'undefined' && element.Line1.__cdata !== '') &&
                (typeof element.City.__cdata !== 'undefined' && element.City.__cdata !== '') &&
                (typeof element.State.__cdata !== 'undefined' && element.State.__cdata !== '') &&
                (typeof element.ZipCode !== 'undefined' && element.ZipCode !== '')
            ) {
                return true;
            } else {
                false;
            }

        });
    };
    return help;
}]);
