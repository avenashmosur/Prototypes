'use strict';

clickAppFactory.factory('orderModel', ['$filter', function($filter){
  var orderModel = {};
  orderModel.appliedPromotions = []; 
  orderModel.commerceItems = []; 
  orderModel.ecInfo= []; 
  orderModel.orderBillingInfo = []; 
  orderModel.orderShippingInfo = [];
  orderModel.orderSummary = [];
  orderModel.orderState;
  orderModel.orderID;
  return orderModel;
}]);