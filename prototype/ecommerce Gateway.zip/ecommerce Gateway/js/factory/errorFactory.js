'use strict';

// making a central factory for errors, easier to handle error messages
clickAppFactory.factory('errors', [function () {
    var errors = [
      
    ];

    errors.getErrorMessage = function (errorNumber) {
        var message = "";
        angular.forEach(errors, function (value, key) {
            if (errorNumber == value.errorCode)
                message = value.errorMessage;
        });
        return message;
    };

    return errors;

}]);
