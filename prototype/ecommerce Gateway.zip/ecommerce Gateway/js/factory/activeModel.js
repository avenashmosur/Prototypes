'use strict';

clickAppFactory.factory('activeModel', ['$filter', function($filter){
  var activeModel = {};
  activeModel = {
    billingAddressList      : [],      // list of addresses
	shippingList			: [],
	paymentInfoList			: [],
	addressList             : [],
    editAddressList         : [],
	cardDetailsList			: [],
    addressSelect : '',
    selectedADDRESS_BOOK_ID : '',
    selectedCC_LAST_4_DIGITS :'',
    cardSelect:'',
    editAddressFlag : false
  };
  return activeModel;
}]);