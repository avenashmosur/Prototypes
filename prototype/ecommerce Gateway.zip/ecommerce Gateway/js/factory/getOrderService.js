'use strict';

clickAppFactory.factory('getOrderService', ['$rootScope', '$resource', 'serviceFactory', 'xdrService', function ($rootScope, $resource, sf, xdrService) {

    var serviceUrl;
    var serviceType = 'dev', userAgent = 'DESKTOP', channelName = 'WEB', wfc = 'GR', xmlFormat = 'false';
   // var userAgentFASTValue = getUserAgent(navigator.userAgent);
    var userAgentFASTValue = "MOBILE";
    var appName = userAgent == 'DESKTOP' ? 'CMK_WEB' : 'CMK_APP';
    var fenv = 'https://sitservices.caremark.com:11460';
    var _fenv = 'demo';

    var _apiKey = "1008347202313004A50F01F33D27EAB1"; // default value must be the APIKEY and SECRET of MOBILE DEVICES
    var _apiSecret = "E228F4CF4BE33EA5A20FE5FF9D5573F8"; // default value must be the APIKEY and SECRET of MOBILE DEVICES
    // if desktop, APIKEY and Secret will be from portalJson and hence value must be the APIKEY and SECRET of PORTAL
  
   var url;
   
   function lowercase(string) {
       return string.toLowerCase();
   }
   
   var arr = (/msie (\d+)/.exec(lowercase(navigator.userAgent)));
   var msie = (arr || [])[1];


    function urlMaker(params, method, serviceName, serviceType) {
        url = {
            domain: fenv,
            domainId: params.domain,
            method: method,
            params: {
                appName: appName,
                deviceID: 'BLNK',
                lineOfBusiness: 'PBM',
                channelName: channelName,
                deviceType: userAgentFASTValue,
                apiKey: _apiKey,
                apiSecret: _apiSecret,
                serviceName: serviceName,
                serviceCORS: true
            },
            headers: {
                'Content-Type': 'text/plain'
            }
        };
        for (var key in params) {
            url.params[key] = params[key];
        }

        var finalURL = constructURL(url);
        return finalURL;

    }

    // Make URL
    function constructURL(url) {
        var finalURL;
        finalURL = url.domain + url.domainId + "/" + url.method;
        // buld params
        if (url.params) {
            var params = "?";

            if (!Object.keys) {
                Object.keys = function (obj) {
                    var keys = [];
                    for (var i in obj) {
                        if (obj.hasOwnProperty(i)) {
                            keys.push(i);
                        }
                    }
                    return keys;
                };
            }
            // building params
            for (var i = 0, keys = Object.keys(url.params); i < keys.length; i++) {
                if (keys[i] == 'domain')
                    continue;
                params += (keys[i] + "=" + url.params[keys[i]] + (( i < keys.length - 1) ? "&" : ""));
            }
            // final URL with params
            finalURL += params;
        }

        return finalURL;
    };

    if (_fenv == 'demo') {

        return $resource('https://' + fenv + '444/refill/:id',
            {
                version: '1.0',
                appName: appName,
                deviceID: 'device12345',
                lineOfBusiness: 'PBM',
                channelName: channelName,
                deviceType: userAgentFASTValue,
                // SIT
                apiKey: _apiKey,
                apiSecret: _apiSecret
            },
            {
                //Service Call Methods
                getOrder: {
                   // url: 'json/getOrder.json',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    params: {
                        id: 'getOrder',
                        serviceName: 'getOrder',
                        ORDER_ID:"323232"
                     }
                    // transformRequest : sf.requestTranform,
                   // transformResponse: sf.responseTransform
                },

                retrieveCheckOutDetails: {
                    url: 'json/retrieveCheckOutDetailsMock.json',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    params: {
                        id: 'RetrieveCheckOutDetails',
                        serviceName: 'RetrieveCheckOutDetails'

                    }
                },

                calcOrderShippingSummaryAndTotal: {
                    url: 'json/calcOrderShippingSummaryAndTotal.json',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    params: {
                        id: 'CalcOrderShippingSummaryAndTotal',
                        serviceName: 'CalcOrderShippingSummaryAndTotal'

                    }
                },

                    getProfilePayment: {
                        //url: 'json/profilePaymentInfo.json',
                        method: 'POST',
                        headers: {
                            'Content-Type': 'text/plain'
                        },
                        params: {
                            id: 'GetProfileAddressAndPaymentInfo',
                            serviceName: 'GetProfileAddressAndPaymentInfo'
                         }
                    }
               }
           
        );
    }
    else if (msie == 8) {
        return {
        	getOrder: function (params, data, success, error) {
                params.ORDER_ID = '323232';
                serviceUrl = urlMaker(params, 'getOrder', 'getOrder', serviceType);
                xdrService.makeRequest(serviceUrl, data, success, error,true);
            },
            getProfilePayment: function (params, data, success, error) {
                serviceUrl = urlMaker(params, 'GetProfileAddressAndPaymentInfo', 'GetProfileAddressAndPaymentInfo', serviceType);
                xdrService.makeRequest(serviceUrl, data, success, error,true);
            },
            calcOrderShippingSummaryAndTotal:function(params, data, success, error){
                serviceUrl = urlMaker(params, 'CalcOrderShippingSummaryAndTotal', 'CalcOrderShippingSummaryAndTotal', serviceType);
                xdrService.makeRequest(serviceUrl, data, success, error,true);
            }
        };//return {
    } // else if(msie == 8) {
    else {
        return $resource(fenv + ':domain/:id',
            {
                appName: appName,
                lineOfBusiness: 'PBM',
                deviceType: userAgentFASTValue,
                domain: 'refill',
                channelName: channelName,
                // SIT
                apiKey: _apiKey,
                apiSecret: _apiSecret
            },
            {
                //Service Call Methods
            	getOrder: {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    params: {
                        id: 'getOrder',
                        serviceName: 'getOrder',
                        serviceCORS: true,
                        deviceID: 'BLNK'
                    }
                    // transformRequest : sf.requestTranform,
                   // transformResponse: sf.responseTransform
                },
                getProfilePayment: {
                    url: 'json/profilePaymentInfo.json',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain'
                    },
                    params: {
                        id: 'GetProfileAddressAndPaymentInfo',
                        serviceName: 'GetProfileAddressAndPaymentInfo',
                        serviceCORS: true,
                        deviceID: 'BLNK'
                     }
                }
            }
            
        );
    }
   
}]);

